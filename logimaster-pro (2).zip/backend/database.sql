
-- LogiMaster Pro Enterprise Database Schema V4.2 (Final)

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+03:00";

-- 1. USERS & AUTH
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `permissions` json DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL UNIQUE,
  `password_hash` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
);

-- 2. LOCATIONS (Master Data)
CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `zone_code` varchar(10) DEFAULT 'A', -- Default Zone for pricing
  PRIMARY KEY (`id`),
  FOREIGN KEY (`country_id`) REFERENCES `countries`(`id`)
);

-- 3. WAREHOUSE & INVENTORY
CREATE TABLE `warehouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL UNIQUE,
  `name` varchar(100) NOT NULL,
  `city_id` int(11) NOT NULL,
  `capacity_sqm` decimal(10,2) DEFAULT 0.00,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`city_id`) REFERENCES `cities`(`id`)
);

CREATE TABLE `shelves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `warehouse_id` int(11) NOT NULL,
  `code` varchar(30) NOT NULL,
  `zone` varchar(10) NOT NULL,
  `type` enum('Bin','Pallet','Secure') DEFAULT 'Bin',
  PRIMARY KEY (`id`)
);

CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sku` varchar(50) NOT NULL UNIQUE,
  `name` varchar(150) NOT NULL,
  `category` varchar(50),
  `client_id` int(11) DEFAULT NULL,
  `weight_kg` decimal(10,3) DEFAULT 0.000,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
);

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `shelf_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`item_id`) REFERENCES `items`(`id`),
  FOREIGN KEY (`shelf_id`) REFERENCES `shelves`(`id`)
);

-- 4. LOGISTICS & SHIPMENTS
CREATE TABLE `couriers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` enum('Internal','3PL') DEFAULT 'Internal',
  `phone` varchar(20) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT 0.00,
  `contract_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_code` varchar(50) NOT NULL UNIQUE,
  `name` varchar(100) NOT NULL,
  `origin_hub` varchar(50),
  `target_zone` varchar(50),
  `default_driver_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `shipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `awb_number` varchar(50) NOT NULL UNIQUE,
  `order_ref` varchar(50) DEFAULT NULL,
  `sender_name` varchar(100),
  `receiver_name` varchar(100),
  `receiver_phone` varchar(20),
  `receiver_city` varchar(50),
  `receiver_address` text,
  `status` varchar(50) DEFAULT 'Created',
  `payment_mode` enum('COD','Prepaid') DEFAULT 'Prepaid',
  `cod_amount` decimal(10,2) DEFAULT 0.00,
  `courier_id` int(11) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
);

-- 5. OPERATIONS (Manifests, Pickups)
CREATE TABLE `pickup_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pickup_code` varchar(50) NOT NULL UNIQUE,
  `courier_id` int(11) NOT NULL,
  `status` enum('Pending','Collected','Failed') DEFAULT 'Pending',
  `scheduled_date` date,
  `city` varchar(50),
  PRIMARY KEY (`id`)
);

CREATE TABLE `manifests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `manifest_code` varchar(50) NOT NULL UNIQUE,
  `courier_id` int(11) NOT NULL,
  `driver_name` varchar(100),
  `status` enum('Draft','Dispatched','Completed') DEFAULT 'Draft',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
);

CREATE TABLE `manifest_items` (
  `manifest_id` int(11) NOT NULL,
  `shipment_id` int(11) NOT NULL,
  PRIMARY KEY (`manifest_id`, `shipment_id`),
  FOREIGN KEY (`manifest_id`) REFERENCES `manifests`(`id`),
  FOREIGN KEY (`shipment_id`) REFERENCES `shipments`(`id`)
);

CREATE TABLE `drs_sheets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drs_code` varchar(50) NOT NULL UNIQUE,
  `driver_id` int(11) NOT NULL,
  `route_id` int(11) DEFAULT NULL,
  `status` enum('Out','Completed') DEFAULT 'Out',
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
);

-- 6. SUPPORT & TICKETS
CREATE TABLE `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_no` varchar(20) NOT NULL UNIQUE,
  `subject` varchar(255) NOT NULL,
  `type` varchar(50), -- e.g. Shipment, System, Billing
  `priority` enum('Low','Medium','High') DEFAULT 'Medium',
  `status` enum('Open','InProgress','Closed') DEFAULT 'Open',
  `related_awb` varchar(50) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
);

-- 7. FINANCE & INVESTMENT
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(50) NOT NULL UNIQUE,
  `client_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `type` varchar(50) DEFAULT 'Service', 
  `status` enum('Unpaid','Paid') DEFAULT 'Unpaid',
  `due_date` date,
  PRIMARY KEY (`id`)
);

CREATE TABLE `investment_rounds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100),
  `target_amount` decimal(15,2),
  `raised_amount` decimal(15,2) DEFAULT 0.00,
  `status` enum('Active','Closed') DEFAULT 'Active',
  PRIMARY KEY (`id`)
);

CREATE TABLE `subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `round_id` int(11) NOT NULL,
  `investor_name` varchar(100),
  `amount` decimal(15,2),
  `shares` int(11),
  `status` enum('Pending','Approved') DEFAULT 'Pending',
  PRIMARY KEY (`id`)
);

-- 8. ASSETS (Vehicles & Drivers)
CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plate_number` varchar(20) NOT NULL,
  `type` varchar(50),
  `driver_id` int(11) DEFAULT NULL,
  `status` enum('Active','Maintenance') DEFAULT 'Active',
  PRIMARY KEY (`id`)
);

CREATE TABLE `drivers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL, 
  `iqama_id` varchar(50),
  `current_lat` decimal(10,8),
  `current_lng` decimal(11,8),
  `is_online` boolean DEFAULT FALSE,
  PRIMARY KEY (`id`)
);

-- 9. LOGS & COMMUNICATION (New)
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` text,
  `ip_address` varchar(45),
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
);

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) DEFAULT NULL, 
  `customer_name` varchar(100) DEFAULT NULL,
  `platform` varchar(50) DEFAULT 'Internal', -- WhatsApp, SMS, etc
  `content` text,
  `status` enum('Sent','Received','Read') DEFAULT 'Sent',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
);

CREATE TABLE `integrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL, -- Zid, Salla, etc
  `api_key` text,
  `secret_key` text,
  `status` enum('Active','Inactive') DEFAULT 'Inactive',
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
);

COMMIT;
