
const express = require('express');
const router = express.Router();

// Import Controllers
const authController = require('../controllers/authController');
const shipmentController = require('../controllers/shipmentController');
const inventoryController = require('../controllers/inventoryController');
const financeController = require('../controllers/financeController');
const investmentController = require('../controllers/investmentController');
const fleetController = require('../controllers/fleetController');
const warehouseController = require('../controllers/warehouseController');
const manifestController = require('../controllers/manifestController');
const userController = require('../controllers/userController');
const ticketController = require('../controllers/ticketController');
const routeController = require('../controllers/routeController');
const supplierController = require('../controllers/supplierController');
const locationController = require('../controllers/locationController');
const analyticsController = require('../controllers/analyticsController');
const logController = require('../controllers/logController');
const communicationController = require('../controllers/communicationController');
const settingsController = require('../controllers/settingsController');

// --- AUTH ---
router.post('/auth/login', authController.login);

// --- DASHBOARD ---
router.get('/dashboard/stats', analyticsController.getDashboardStats);

// --- SHIPMENTS ---
router.get('/shipments', shipmentController.getShipments);
router.post('/shipments', shipmentController.createShipment);
router.post('/shipments/bulk-update', shipmentController.bulkUpdateStatus);
router.post('/shipments/forward-3pl', shipmentController.forwardTo3PL);

// --- INVENTORY ---
router.get('/inventory', inventoryController.getInventory);
router.post('/items', inventoryController.addItem);
router.post('/shelves', inventoryController.addShelf);

// --- WAREHOUSE ---
router.get('/warehouses', warehouseController.getWarehouses);
router.post('/warehouses', warehouseController.addWarehouse);
router.post('/warehouses/generate-tods', warehouseController.generateTods);

// --- MANIFESTS ---
router.get('/manifests', manifestController.getManifests);
router.post('/manifests', manifestController.createManifest);

// --- FLEET & DRIVERS ---
router.get('/drivers', fleetController.getDrivers);
router.post('/drs', fleetController.createDRS);

// --- ROUTES & ZONES ---
router.get('/routes', routeController.getRoutes);
router.post('/routes', routeController.addRoute);

// --- SUPPLIERS (OUTSOURCE) ---
router.get('/suppliers', supplierController.getSuppliers);
router.post('/suppliers', supplierController.addSupplier);

// --- LOCATIONS ---
router.get('/locations', locationController.getLocations);
router.post('/cities', locationController.addCity);

// --- FINANCE ---
router.get('/invoices', financeController.getInvoices);
router.post('/invoices', financeController.createInvoice);

// --- INVESTMENT ---
router.get('/investment/rounds', investmentController.getRounds);
router.post('/investment/subscribe', investmentController.subscribe);

// --- USERS ---
router.get('/users', userController.getUsers);
router.post('/users', userController.createUser);

// --- TICKETS ---
router.get('/tickets', ticketController.getTickets);
router.post('/tickets', ticketController.createTicket);

// --- LOGS ---
router.get('/logs', logController.getLogs);

// --- COMMUNICATION ---
router.get('/messages', communicationController.getMessages);
router.post('/messages', communicationController.sendMessage);

// --- SETTINGS ---
router.get('/integrations', settingsController.getIntegrations);
router.post('/integrations', settingsController.updateIntegration);

module.exports = router;
