
const db = require('../config/db');

// Get Suppliers (3PL)
exports.getSuppliers = async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM couriers WHERE type = '3PL'");
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Add Supplier
exports.addSupplier = async (req, res) => {
    try {
        const { name, phone, city, rate, contract_date } = req.body;
        
        await db.query(
            "INSERT INTO couriers (name, type, phone, city, rate, contract_date) VALUES (?, '3PL', ?, ?, ?, ?)",
            [name, phone, city, rate, contract_date]
        );

        res.status(201).json({ message: 'Supplier registered successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
