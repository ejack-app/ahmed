
const db = require('../config/db');

exports.getDrivers = async (req, res) => {
    try {
        const sql = `
            SELECT d.id, u.full_name, d.is_online, d.current_lat, d.current_lng, v.plate_number 
            FROM drivers d
            JOIN users u ON d.user_id = u.id
            LEFT JOIN vehicles v ON v.driver_id = d.id
        `;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

exports.createDRS = async (req, res) => {
    try {
        const { driver_id, route_id, shipments } = req.body; // shipments is array of IDs
        const drsCode = 'DRS-' + Date.now();
        
        // Create DRS Header
        const [result] = await db.query('INSERT INTO drs_sheets (drs_code, driver_id, route_id, date) VALUES (?, ?, ?, NOW())', 
            [drsCode, driver_id, route_id]);
            
        // Update Shipments Status
        if(shipments && shipments.length > 0) {
            await db.query('UPDATE shipments SET status = "OutForDelivery" WHERE id IN (?)', [shipments]);
        }

        res.status(201).json({ message: 'DRS Created', drs_code: drsCode });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
