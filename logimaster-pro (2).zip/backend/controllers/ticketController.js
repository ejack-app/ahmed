
const db = require('../config/db');

// Get Tickets
exports.getTickets = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM tickets ORDER BY created_at DESC');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Create Ticket
exports.createTicket = async (req, res) => {
    try {
        const { subject, type, priority, related_awb } = req.body;
        const ticketNo = 'TCK-' + Math.floor(Math.random() * 10000);

        await db.query(
            'INSERT INTO tickets (ticket_no, subject, type, priority, related_awb) VALUES (?, ?, ?, ?, ?)',
            [ticketNo, subject, type, priority, related_awb]
        );

        res.status(201).json({ message: 'Ticket created', ticket_no: ticketNo });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
