
const db = require('../config/db');

// Get Dashboard Stats
exports.getDashboardStats = async (req, res) => {
    try {
        const [shipmentCounts] = await db.query(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'Delivered' THEN 1 ELSE 0 END) as delivered,
                SUM(CASE WHEN status = 'Returned' THEN 1 ELSE 0 END) as returned,
                SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending
            FROM shipments
        `);

        const [revenue] = await db.query(`
            SELECT SUM(amount) as total_revenue FROM invoices WHERE status = 'Paid'
        `);

        const [inventoryStats] = await db.query(`
            SELECT COUNT(*) as total_items, SUM(quantity) as total_stock FROM inventory
        `);

        res.json({
            shipments: shipmentCounts[0],
            revenue: revenue[0].total_revenue || 0,
            inventory: inventoryStats[0]
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
