
const db = require('../config/db');

// Get Inventory
exports.getInventory = async (req, res) => {
    try {
        const sql = `
            SELECT i.sku, i.name, i.category, w.name as warehouse, s.code as shelf, inv.quantity 
            FROM inventory inv
            JOIN items i ON inv.item_id = i.id
            JOIN shelves s ON inv.shelf_id = s.id
            JOIN warehouses w ON s.warehouse_id = w.id
        `;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Add Item
exports.addItem = async (req, res) => {
    try {
        const { sku, name, category, weight_kg } = req.body;
        const sql = 'INSERT INTO items (sku, name, category, weight_kg) VALUES (?, ?, ?, ?)';
        await db.query(sql, [sku, name, category, weight_kg]);
        res.status(201).json({ message: 'Item added to master catalog' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Add Shelf
exports.addShelf = async (req, res) => {
    try {
        const { warehouse_id, code, zone, type } = req.body;
        await db.query('INSERT INTO shelves (warehouse_id, code, zone, type) VALUES (?, ?, ?, ?)', [warehouse_id, code, zone, type]);
        res.status(201).json({ message: 'Shelf created' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
