
const db = require('../config/db');

// Get All Locations (Countries & Cities)
exports.getLocations = async (req, res) => {
    try {
        const sql = `
            SELECT ci.id, ci.name as city_name, ci.zone_code, co.name as country_name 
            FROM cities ci 
            JOIN countries co ON ci.country_id = co.id
        `;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Add City
exports.addCity = async (req, res) => {
    try {
        const { country_id, name, zone_code } = req.body;
        await db.query('INSERT INTO cities (country_id, name, zone_code) VALUES (?, ?, ?)', [country_id, name, zone_code]);
        res.status(201).json({ message: 'City added successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
