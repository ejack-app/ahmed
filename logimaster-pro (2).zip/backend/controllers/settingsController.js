
const db = require('../config/db');

// Get Integrations
exports.getIntegrations = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT id, name, status, updated_at FROM integrations');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Update Integration
exports.updateIntegration = async (req, res) => {
    try {
        const { name, api_key, secret_key, status } = req.body;
        
        // Check if exists
        const [existing] = await db.query('SELECT id FROM integrations WHERE name = ?', [name]);
        
        if (existing.length > 0) {
            await db.query('UPDATE integrations SET api_key = ?, secret_key = ?, status = ? WHERE name = ?', 
                [api_key, secret_key, status, name]);
        } else {
            await db.query('INSERT INTO integrations (name, api_key, secret_key, status) VALUES (?, ?, ?, ?)', 
                [name, api_key, secret_key, status]);
        }

        res.json({ message: 'Integration settings updated' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
