
const db = require('../config/db');

exports.getRounds = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM investment_rounds');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

exports.subscribe = async (req, res) => {
    try {
        const { round_id, investor_name, amount, shares } = req.body;
        
        // Update round raised amount
        await db.query('UPDATE investment_rounds SET raised_amount = raised_amount + ? WHERE id = ?', [amount, round_id]);
        
        // Create subscription
        await db.query('INSERT INTO subscriptions (round_id, investor_name, amount, shares) VALUES (?, ?, ?, ?)', 
            [round_id, investor_name, amount, shares]);
            
        res.status(201).json({ message: 'Subscription successful' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
