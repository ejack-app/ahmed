
const db = require('../config/db');
const bcrypt = require('bcryptjs');

// Get All Users
exports.getUsers = async (req, res) => {
    try {
        const sql = `
            SELECT u.id, u.full_name, u.email, u.phone, u.status, r.name as role 
            FROM users u 
            JOIN roles r ON u.role_id = r.id
        `;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Create User
exports.createUser = async (req, res) => {
    try {
        const { full_name, email, password, phone, role_id, branch_id } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);

        await db.query(
            'INSERT INTO users (full_name, email, password_hash, phone, role_id, branch_id) VALUES (?, ?, ?, ?, ?, ?)',
            [full_name, email, hashedPassword, phone, role_id, branch_id]
        );

        res.status(201).json({ message: 'User created successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
