
const db = require('../config/db');

// Get All Shipments with filtering
exports.getShipments = async (req, res) => {
    try {
        const { status, awb, city } = req.query;
        let query = 'SELECT * FROM shipments WHERE 1=1';
        const params = [];

        if (status) {
            query += ' AND status = ?';
            params.push(status);
        }
        if (awb) {
            query += ' AND awb_number LIKE ?';
            params.push(`%${awb}%`);
        }
        if (city) {
            query += ' AND receiver_city = ?';
            params.push(city);
        }

        query += ' ORDER BY created_at DESC LIMIT 100';
        const [rows] = await db.query(query, params);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Create Shipment
exports.createShipment = async (req, res) => {
    try {
        const { awb_number, sender_name, receiver_name, receiver_city, receiver_address, payment_mode, cod_amount } = req.body;
        
        const sql = `INSERT INTO shipments (awb_number, sender_name, receiver_name, receiver_city, receiver_address, payment_mode, cod_amount, status) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, 'Created')`;
        
        await db.query(sql, [awb_number, sender_name, receiver_name, receiver_city, receiver_address, payment_mode, cod_amount]);
        
        res.status(201).json({ message: 'Shipment created successfully', awb: awb_number });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Update Status (Bulk)
exports.bulkUpdateStatus = async (req, res) => {
    try {
        const { awb_numbers, new_status, comment } = req.body; // awb_numbers is array
        
        const sql = `UPDATE shipments SET status = ? WHERE awb_number IN (?)`;
        await db.query(sql, [new_status, awb_numbers]);

        // Optional: Log history here
        
        res.json({ message: `Updated ${awb_numbers.length} shipments to ${new_status}` });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Assign to 3PL
exports.forwardTo3PL = async (req, res) => {
    try {
        const { awb_number, courier_id } = req.body;
        await db.query('UPDATE shipments SET courier_id = ?, status = "Forwarded" WHERE awb_number = ?', [courier_id, awb_number]);
        res.json({ message: 'Shipment forwarded to 3PL' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
