
const db = require('../config/db');

// Get Messages
exports.getMessages = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM messages ORDER BY created_at DESC LIMIT 50');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Send Message (Simulated)
exports.sendMessage = async (req, res) => {
    try {
        const { sender_id, customer_name, platform, content } = req.body;
        
        await db.query('INSERT INTO messages (sender_id, customer_name, platform, content, status) VALUES (?, ?, ?, ?, "Sent")', 
            [sender_id, customer_name, platform, content]);
            
        res.status(201).json({ message: 'Message sent successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
