
const db = require('../config/db');

// Get All Routes
exports.getRoutes = async (req, res) => {
    try {
        const sql = `
            SELECT r.id, r.route_code, r.name, r.origin_hub, r.target_zone, 
            u.full_name as default_driver
            FROM routes r
            LEFT JOIN users u ON r.default_driver_id = u.id
        `;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Add New Route
exports.addRoute = async (req, res) => {
    try {
        const { route_code, name, origin_hub, target_zone, default_driver_id } = req.body;
        
        await db.query(
            'INSERT INTO routes (route_code, name, origin_hub, target_zone, default_driver_id) VALUES (?, ?, ?, ?, ?)',
            [route_code, name, origin_hub, target_zone, default_driver_id]
        );

        res.status(201).json({ message: 'Route created successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
