
const db = require('../config/db');

// Get all warehouses
exports.getWarehouses = async (req, res) => {
    try {
        const sql = `
            SELECT w.id, w.code, w.name, c.name as city, w.capacity_sqm 
            FROM warehouses w
            JOIN cities c ON w.city_id = c.id
        `;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Add new warehouse
exports.addWarehouse = async (req, res) => {
    try {
        const { code, name, city_id, capacity_sqm } = req.body;
        await db.query('INSERT INTO warehouses (code, name, city_id, capacity_sqm) VALUES (?, ?, ?, ?)', 
            [code, name, city_id, capacity_sqm]);
        res.status(201).json({ message: 'Warehouse created successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Generate Tods (Totes)
exports.generateTods = async (req, res) => {
    try {
        const { prefix, quantity, start } = req.body;
        // Logic to generate IDs and potentially store them if there is a 'tods' table
        // For now, we just return the generated codes
        const tods = [];
        for(let i=0; i<quantity; i++) {
            tods.push(`${prefix}-${parseInt(start)+i}`);
        }
        res.json({ message: `${quantity} TODs generated`, codes: tods });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
