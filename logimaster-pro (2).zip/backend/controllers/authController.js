
const db = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;
        
        // 1. Check User
        const [users] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
        if (users.length === 0) return res.status(401).json({ message: 'Invalid credentials' });

        const user = users[0];

        // 2. Check Password
        const isMatch = await bcrypt.compare(password, user.password_hash);
        if (!isMatch) return res.status(401).json({ message: 'Invalid credentials' });

        // 3. Generate Token
        const token = jwt.sign(
            { id: user.id, role_id: user.role_id, branch_id: user.branch_id }, 
            process.env.JWT_SECRET || 'secret', 
            { expiresIn: '8h' }
        );

        res.json({ 
            token, 
            user: { id: user.id, name: user.full_name, email: user.email } 
        });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
