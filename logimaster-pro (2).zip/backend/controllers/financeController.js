
const db = require('../config/db');

exports.getInvoices = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM invoices ORDER BY due_date DESC');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

exports.createInvoice = async (req, res) => {
    try {
        const { client_id, amount, type, due_date } = req.body;
        const invoiceNo = 'INV-' + Date.now();
        
        await db.query('INSERT INTO invoices (invoice_no, client_id, amount, type, due_date) VALUES (?, ?, ?, ?, ?)', 
            [invoiceNo, client_id, amount, type, due_date]);
            
        res.status(201).json({ message: 'Invoice generated', invoice_no: invoiceNo });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
