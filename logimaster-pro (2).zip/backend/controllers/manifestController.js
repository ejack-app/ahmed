
const db = require('../config/db');

// Get all manifests
exports.getManifests = async (req, res) => {
    try {
        const sql = `
            SELECT m.id, m.manifest_code, c.name as courier, m.driver_name, m.status, m.created_at,
            (SELECT COUNT(*) FROM manifest_items mi WHERE mi.manifest_id = m.id) as orders_count
            FROM manifests m
            JOIN couriers c ON m.courier_id = c.id
            ORDER BY m.created_at DESC
        `;
        const [rows] = await db.query(sql);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Create new manifest
exports.createManifest = async (req, res) => {
    try {
        const { courier_id, driver_name, shipments } = req.body; // shipments = array of IDs
        const code = 'MAN-' + Date.now();

        // 1. Create Manifest Header
        const [result] = await db.query('INSERT INTO manifests (manifest_code, courier_id, driver_name) VALUES (?, ?, ?)', 
            [code, courier_id, driver_name]);
        const manifestId = result.insertId;

        // 2. Link Items
        if (shipments && shipments.length > 0) {
            const values = shipments.map(id => [manifestId, id]);
            await db.query('INSERT INTO manifest_items (manifest_id, shipment_id) VALUES ?', [values]);
            
            // 3. Update Shipment Status
            await db.query('UPDATE shipments SET status = "Manifested" WHERE id IN (?)', [shipments]);
        }

        res.status(201).json({ message: 'Manifest created', code });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
