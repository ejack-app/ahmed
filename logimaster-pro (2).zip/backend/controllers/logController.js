
const db = require('../config/db');

// Get Logs
exports.getLogs = async (req, res) => {
    try {
        const { type, limit } = req.query;
        let query = `
            SELECT l.id, l.action, l.details, l.created_at, u.full_name as user 
            FROM audit_logs l
            LEFT JOIN users u ON l.user_id = u.id
            WHERE 1=1
        `;
        const params = [];

        if (type) {
            query += ' AND l.action LIKE ?';
            params.push(`%${type}%`);
        }

        query += ' ORDER BY l.created_at DESC LIMIT ?';
        params.push(parseInt(limit) || 100);

        const [rows] = await db.query(query, params);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Create Log (Helper function mostly used internally, but exposed if needed)
exports.createLog = async (userId, action, details) => {
    try {
        await db.query('INSERT INTO audit_logs (user_id, action, details) VALUES (?, ?, ?)', 
            [userId, action, details]);
    } catch (err) {
        console.error('Logging Error:', err.message);
    }
};
