
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const apiRoutes = require('./routes/apiRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// API Routes
app.use('/api', apiRoutes);

// --- Serving Frontend (Robust Path Handling for cPanel) ---
// Checks multiple possible locations for the 'dist' folder
const possibleDistPaths = [
    path.join(__dirname, '../dist'),       // Standard dev: root/dist, server in root/backend
    path.join(process.cwd(), 'dist'),      // If running from root
    path.join(__dirname, 'dist')           // If dist is moved inside backend
];

let distPath = null;
for (const p of possibleDistPaths) {
    if (fs.existsSync(p)) {
        distPath = p;
        break;
    }
}

if (distPath) {
    console.log(`✅ Serving frontend from: ${distPath}`);
    // Serve static files
    app.use(express.static(distPath));

    // Handle React Routing (SPA) - redirect all non-API requests to index.html
    app.get('*', (req, res) => {
        if (req.path.startsWith('/api')) {
            return res.status(404).json({ error: 'API route not found' });
        }
        res.sendFile(path.join(distPath, 'index.html'));
    });
} else {
    console.warn('⚠️  Frontend build directory "dist" not found.');
    app.get('/', (req, res) => {
        res.send(`
            <div style="font-family: sans-serif; text-align: center; padding: 50px;">
                <h1>LogiMaster Backend Running</h1>
                <p>Status: <strong>Active</strong></p>
                <p style="color: red;">Frontend "dist" folder not found.</p>
                <p>Please run <code>npm run build</code> locally and upload the "dist" folder.</p>
            </div>
        `);
    });
}

// Start Server
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});
