
const mysql = require('mysql2/promise');
require('dotenv').config();

// Configuration for Production (cPanel)
const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'rootejack_log',
    password: process.env.DB_PASSWORD || 'Ahmad2202114',
    database: process.env.DB_NAME || 'rootejack_log',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    timezone: '+03:00' // KSA Time
});

// Helper to check connection logs
const checkConnection = async () => {
    try {
        const connection = await pool.getConnection();
        console.log('✅ MySQL Database Connected Successfully');
        connection.release();
    } catch (error) {
        console.error('❌ Database Connection Failed:', error.message);
    }
};

checkConnection();

module.exports = pool;
