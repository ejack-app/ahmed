
import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Login } from './views/Login';
import { Sidebar } from './components/Sidebar';
import { DashboardStats } from './components/DashboardStats';
import { ShipmentManager } from './views/ShipmentManager';
import { InventoryManager } from './views/InventoryManager';
import { SimpleLineChart, SimpleBarChart } from './components/Charts';
// ... imports
import { 
  ZidConfiguration, SallaConfiguration, CitcConfiguration, 
  SmsConfiguration, SallaAppConfig, ZidAppConfig 
} from './views/IntegrationViews';
import { 
  BulkForward3PL, ManualForward3PL, ReverseOrders, CreateReverseOrder, 
  CancelOrders3PL, BulkPrint, ForwardRemove, DeletedOrders, CancelledOrders,
  SallaPendingOrders, ShipmentMapping, ZidOrderListing, BulkOrderCreate, BulkUpdateDate
} from './views/ShipmentOperations';
import { AddShipment } from './views/AddShipment';
import { BulkUpdate } from './views/BulkUpdate';
import {
  AddItemInventory, AddShelf, ViewShelf, UpdateShelf, 
  MergeStock, InventoryPerClient, UploadInventory
} from './views/InventoryOperations';
import {
  GenerateStockLocation, AllStockLocation, BulkPrintStockLocation,
  AssignedStockLocation, UnassignedStockLocation
} from './views/StockLocationOperations';
import {
  AddItem, ViewAllItems, BulkSkuPrint, BulkItemUpdate, ImportItems
} from './views/ItemOperations';
import {
  AddVehicle, VehicleList
} from './views/VehicleOperations';
import {
  AddBox, BoxList
} from './views/BoxOperations';
import {
  ShowDamageItem, ReturnOrderList
} from './views/ReturnManifestOperations';
import {
  GenerateTods, ShowTodd, AddWarehouse, ViewWarehouse,
  ScanInBoundShipment, ScanOnHold, InventoryReportView, 
  ScanShelveShipment, ScanScheduleShipment, SecurityCheckView
} from './views/WarehouseOperations';
import {
  WarehouseLayoutDesigner
} from './views/WarehouseLayoutOperations';
import {
  CommunicationHub
} from './views/CommunicationHub';
import {
  AppMarketplace
} from './views/AppMarketplace';
import {
  NewManifest, PickupList, ManifestList, AssignedList,
  NewManifestBeta, PickupListBeta, ManifestListBeta, AssignedListBeta
} from './views/ManifestOperations';
import {
  BulkPickupUpdate, AddPickupSheet, PickupList as PickupListOperation, ScanNewPickup, ShowPickupDetail
} from './views/PickupOperations';
import {
  AddSupplier, SupplierList, GenerateOutsourceInvoice, OutsourcePaymentInfo
} from './views/OutsourceOperations';
import {
  AddBranch, ShowBranch
} from './views/BranchOperations';
import {
  AddDRS, ShowDRS, ScanNewDRS, DRSDetails, DeliveredDetails, NotDeliveredDetails
} from './views/DRSOperations';
import {
  AddCourier, CourierList, CourierDetails, AssignRoute, OdoMeterHistory
} from './views/CourierManagementOperations';
import {
  ShowPendingRTO, ShowRTOList, RTODetails, UpdateRTO
} from './views/RTOOperations';
import {
  BlindScheduleView, BulkOnHoldView, BulkRescheduleView, CSScheduleView, BulkScheduleRemoveView
} from './views/ScheduleOperations';
import {
  AddZoneList, SetCityZone, SetCountryZone
} from './views/ZoneOperations';
import {
  DriverTrackingView, ShipmentPathView
} from './views/TrackingMapOperations';
import {
  AllTicketList, ManifestTicketList
} from './views/TicketOperations';
import {
  BundleOffersList, AddBundle, BundleOrdersList
} from './views/OfferOperations';
import {
  SinglePickupList, BatchPickupList, PickupCompletedList, PickerSettings
} from './views/PickingOperations';
import {
  PackagingView, PackagingWithToddView
} from './views/PackagingOperations';
import {
  DispatchingView, DispatchingBetaView, DispatchToDeliveredView
} from './views/DispatchingOperations';
import {
  AddSeller, ViewAllSellers, SellerRates, SellerFinance
} from './views/SellerOperations';
import {
  AddUser, ViewAllUsers
} from './views/UserOperations';
import {
  SetFixedRateCharges, SetDynamicRateCharges, AllCategory, StorageChargesInvoices,
  TransactionReport, FixRateInvoice, DynamicInvoice, AllStorageTypes,
  CancelOrderFinance, CreateLMInvoice, ViewLMInvoice,
  CreateBulkInvoice, BulkCODInvoices, PayableInvoices
} from './views/FinanceOperations';
import {
  AddRoute, AddRouteBulk, ShowRoute
} from './views/RouteOperations';
import {
  ViewCourierCompany, AddZone, ViewZone, ShipmentLog, TrackingLog
} from './views/CourierServiceOperations';
import {
  LocationList, ImportLocation, ImportDeliveryCity, DeliveryCompanyList, AddCountry, AddFromMaster
} from './views/LocationOperations';
import { AddFAQ, ShowFAQ } from './views/FAQOperations';
import { 
  ShelveReport, TopProductDispatch, OFDReport, StaffPerformance, DispatchingReport, 
  Report3PL, PackagingReport, ItemInventoryTotal, InboundRecord, InventoryHistory, 
  DamageInventoryHistory, StorageReport, BulkShipmentReport 
} from './views/ReportOperations';
import { NewTemplate, ShowTemplate } from './views/AccessManagementOperations';
import { 
  InvestmentDashboard, InvestmentOpportunities, InvestmentSubscriptions 
} from './views/InvestmentOperations';
import { CityListView } from './views/CityListOperations';
import { LogViewer } from './views/LogOperations';
import { CompanyDetails } from './views/CompanyDetails';
import { CourierCompanyDetails } from './views/CourierCompanyDetails';
import { LegalDocumentEditor } from './views/LegalDocumentEditor';
import { Assistant } from './components/Assistant';
import { ViewState } from './types';
import { Bell, Search, User, LogOut } from 'lucide-react';

const AppContent: React.FC = () => {
  const { user, isAuthenticated, logout } = useAuth();
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.DASHBOARD);

  // Default content for legal docs
  const privacyContent = `## Privacy Policy\n\n1. Introduction\nWelcome to LogiMaster Pro...`;
  const termsContent = `## Terms & Conditions\n\n1. Acceptance of Terms...`;

  if (!isAuthenticated) {
    return <Login />;
  }

  const renderContent = () => {
    switch (currentView) {
      case ViewState.DASHBOARD:
        return (
          <>
            <DashboardStats />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 min-h-[300px]">
                    <h3 className="text-gray-800 font-bold mb-4">Weekly Order Volume</h3>
                    <SimpleBarChart data={[150, 230, 180, 320, 290, 450, 410]} labels={['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']} color="bg-blue-600" />
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 min-h-[300px]">
                    <h3 className="text-gray-800 font-bold mb-4">Performance Trends</h3>
                    <SimpleLineChart data={[85, 88, 84, 92, 90, 95, 96]} color="#10b981" />
                    <p className="text-center text-xs text-gray-500 mt-2">Delivery Success Rate (%)</p>
                </div>
            </div>
            <div className="mt-8">
                <ShipmentManager />
            </div>
          </>
        );
      case ViewState.COMPANY_DETAILS: return <CompanyDetails />;
      case ViewState.COMPANY_COURIER_DETAILS: return <CourierCompanyDetails />;
      case ViewState.COMPANY_PRIVACY: return <LegalDocumentEditor title="Privacy Policy" defaultContent={privacyContent} lastUpdated="October 24, 2024" />;
      case ViewState.COMPANY_TERMS: return <LegalDocumentEditor title="Terms & Conditions" defaultContent={termsContent} lastUpdated="January 15, 2025" />;
      case ViewState.COMMUNICATION_HUB: return <CommunicationHub />;
      case ViewState.APP_MARKETPLACE: return <AppMarketplace />;
      case ViewState.INTEGRATION_ZID: return <ZidConfiguration />;
      case ViewState.INTEGRATION_SALLA: return <SallaConfiguration />;
      case ViewState.INTEGRATION_CITC: return <CitcConfiguration />;
      case ViewState.INTEGRATION_SMS: return <SmsConfiguration />;
      case ViewState.INTEGRATION_SALLA_APP: return <SallaAppConfig />;
      case ViewState.INTEGRATION_ZID_APP: return <ZidAppConfig />;
      case ViewState.INTEGRATIONS: return <ZidConfiguration />;
      case ViewState.SHIPMENT_ADD: return <AddShipment />;
      case ViewState.SHIPMENT_BULK_UPDATE: return <BulkUpdate />;
      case ViewState.SHIPMENTS_ALL: return <ShipmentManager />;
      case ViewState.SHIPMENT_BULK_FORWARD_3PL: return <BulkForward3PL />;
      case ViewState.SHIPMENT_MANUAL_FORWARD_3PL: return <ManualForward3PL />;
      case ViewState.SHIPMENTS_REVERSE: return <ReverseOrders />;
      case ViewState.SHIPMENT_CREATE_REVERSE: return <CreateReverseOrder />;
      case ViewState.SHIPMENT_CANCEL_3PL: return <CancelOrders3PL />;
      case ViewState.SHIPMENT_BULK_PRINT: return <BulkPrint />;
      case ViewState.SHIPMENT_FORWARD_REMOVE: return <ForwardRemove />;
      case ViewState.SHIPMENT_DELETED: return <DeletedOrders />;
      case ViewState.SHIPMENT_CANCELLED: return <CancelledOrders />;
      case ViewState.SHIPMENT_SALLA_PENDING: return <SallaPendingOrders />;
      case ViewState.SHIPMENT_MAPPING: return <ShipmentMapping />;
      case ViewState.SHIPMENT_ZID_LISTING: return <ZidOrderListing />;
      case ViewState.SHIPMENT_BULK_CREATE: return <BulkOrderCreate />;
      case ViewState.SHIPMENT_BULK_UPDATE_DATE: return <BulkUpdateDate />;
      case ViewState.INVENTORY_ITEMS: return <InventoryManager />; 
      case ViewState.INVENTORY_ADD_ITEM: return <AddItemInventory />;
      case ViewState.INVENTORY_ADD_SHELF: return <AddShelf />;
      case ViewState.INVENTORY_SHELVES: return <ViewShelf />;
      case ViewState.INVENTORY_UPDATE_SHELF: return <UpdateShelf />;
      case ViewState.INVENTORY_MERGE_STOCK: return <MergeStock />;
      case ViewState.INVENTORY_PER_CLIENT: return <InventoryPerClient />;
      case ViewState.INVENTORY_UPLOAD: return <UploadInventory />;
      case ViewState.STOCK_LOCATION_GENERATE: return <GenerateStockLocation />;
      case ViewState.STOCK_LOCATION_ALL: return <AllStockLocation />;
      case ViewState.STOCK_LOCATION_BULK_PRINT: return <BulkPrintStockLocation />;
      case ViewState.STOCK_LOCATION_ASSIGNED: return <AssignedStockLocation />;
      case ViewState.STOCK_LOCATION_UNASSIGNED: return <UnassignedStockLocation />;
      case ViewState.ITEM_ADD: return <AddItem />;
      case ViewState.ITEM_ALL: return <ViewAllItems />;
      case ViewState.ITEM_BULK_PRINT: return <BulkSkuPrint />;
      case ViewState.ITEM_BULK_UPDATE: return <BulkItemUpdate />;
      case ViewState.ITEM_IMPORT: return <ImportItems />;
      case ViewState.VEHICLE_ADD: return <AddVehicle />;
      case ViewState.VEHICLE_LIST: return <VehicleList />;
      case ViewState.BOX_ADD: return <AddBox />;
      case ViewState.BOX_LIST: return <BoxList />;
      case ViewState.RETURN_DAMAGE_ITEM: return <ShowDamageItem />;
      case ViewState.RETURN_ORDER_LIST: return <ReturnOrderList />;
      case ViewState.WAREHOUSE_GENERATE_TODS: return <GenerateTods />;
      case ViewState.WAREHOUSE_SHOW_TODD: return <ShowTodd />;
      case ViewState.WAREHOUSE_ADD: return <AddWarehouse />;
      case ViewState.WAREHOUSE_VIEW: return <ViewWarehouse />;
      case ViewState.WAREHOUSE_LAYOUT: return <WarehouseLayoutDesigner />;
      case ViewState.WAREHOUSE_SCAN_INBOUND: return <ScanInBoundShipment />;
      case ViewState.WAREHOUSE_SCAN_ONHOLD: return <ScanOnHold />;
      case ViewState.WAREHOUSE_INVENTORY_REPORT: return <InventoryReportView />;
      case ViewState.WAREHOUSE_SCAN_SHELVE: return <ScanShelveShipment />;
      case ViewState.WAREHOUSE_SCAN_SCHEDULE: return <ScanScheduleShipment />;
      case ViewState.WAREHOUSE_SECURITY_CHECK: return <SecurityCheckView />;
      case ViewState.MANIFEST_NEW: return <NewManifest />;
      case ViewState.MANIFEST_PICKUP_LIST: return <PickupList />;
      case ViewState.MANIFEST_LIST: return <ManifestList />;
      case ViewState.MANIFEST_ASSIGNED_LIST: return <AssignedList />;
      case ViewState.MANIFEST_BETA_NEW: return <NewManifestBeta />;
      case ViewState.MANIFEST_BETA_PICKUP_LIST: return <PickupListBeta />;
      case ViewState.MANIFEST_BETA_LIST: return <ManifestListBeta />;
      case ViewState.MANIFEST_BETA_ASSIGNED_LIST: return <AssignedListBeta />;
      case ViewState.PICKUP_BULK_UPDATE: return <BulkPickupUpdate />;
      case ViewState.PICKUP_ADD_SHEET: return <AddPickupSheet />;
      case ViewState.PICKUP_LIST: return <PickupListOperation />;
      case ViewState.PICKUP_SCAN_NEW: return <ScanNewPickup />;
      case ViewState.PICKUP_DETAILS: return <ShowPickupDetail />;
      case ViewState.OUTSOURCE_ADD_SUPPLIER: return <AddSupplier />;
      case ViewState.OUTSOURCE_SUPPLIER_LIST: return <SupplierList />;
      case ViewState.OUTSOURCE_GENERATE_INVOICE: return <GenerateOutsourceInvoice />;
      case ViewState.OUTSOURCE_PAYMENT_INFO: return <OutsourcePaymentInfo />;
      case ViewState.BRANCH_ADD: return <AddBranch />;
      case ViewState.BRANCH_LIST: return <ShowBranch />;
      case ViewState.DRS_ADD: return <AddDRS />;
      case ViewState.DRS_LIST: return <ShowDRS />;
      case ViewState.DRS_SCAN_NEW: return <ScanNewDRS />;
      case ViewState.DRS_DETAILS: return <DRSDetails />;
      case ViewState.DRS_DELIVERED_DETAILS: return <DeliveredDetails />;
      case ViewState.DRS_NOT_DELIVERED_DETAILS: return <NotDeliveredDetails />;
      case ViewState.COURIER_MANAGEMENT_ADD: return <AddCourier />;
      case ViewState.COURIER_MANAGEMENT_LIST: return <CourierList onViewDetails={() => setCurrentView(ViewState.COURIER_MANAGEMENT_DETAILS)} onAssignRoute={() => setCurrentView(ViewState.COURIER_MANAGEMENT_ASSIGN_ROUTE)} />;
      case ViewState.COURIER_MANAGEMENT_DETAILS: return <CourierDetails />;
      case ViewState.COURIER_MANAGEMENT_ASSIGN_ROUTE: return <AssignRoute />;
      case ViewState.COURIER_MANAGEMENT_ODO_LIST: return <OdoMeterHistory />;
      case ViewState.RTO_PENDING_LIST: return <ShowPendingRTO onViewDetails={() => setCurrentView(ViewState.RTO_DETAILS)} onUpdate={() => setCurrentView(ViewState.RTO_UPDATE)} />;
      case ViewState.RTO_LIST: return <ShowRTOList onViewDetails={() => setCurrentView(ViewState.RTO_DETAILS)} onUpdate={() => setCurrentView(ViewState.RTO_UPDATE)} />;
      case ViewState.RTO_DETAILS: return <RTODetails />;
      case ViewState.RTO_UPDATE: return <UpdateRTO />;
      case ViewState.SCHEDULE_BLIND: return <BlindScheduleView />;
      case ViewState.SCHEDULE_BULK_ONHOLD: return <BulkOnHoldView />;
      case ViewState.SCHEDULE_BULK_RESCHEDULE: return <BulkRescheduleView />;
      case ViewState.SCHEDULE_CS: return <CSScheduleView />;
      case ViewState.SCHEDULE_BULK_REMOVE: return <BulkScheduleRemoveView />;
      case ViewState.ZONE_ADD_LIST: return <AddZoneList />;
      case ViewState.ZONE_SET_CITY: return <SetCityZone />;
      case ViewState.ZONE_SET_COUNTRY: return <SetCountryZone />;
      case ViewState.LIVE_DRIVER_MAP: return <DriverTrackingView />;
      case ViewState.SHIPMENT_PATH_MAP: return <ShipmentPathView />;
      case ViewState.TICKET_ALL: return <AllTicketList />;
      case ViewState.TICKET_MANIFEST: return <ManifestTicketList />;
      case ViewState.OFFER_BUNDLE_LIST: return <BundleOffersList />;
      case ViewState.OFFER_ADD_BUNDLE: return <AddBundle />;
      case ViewState.OFFER_BUNDLE_ORDERS: return <BundleOrdersList />;
      case ViewState.PICKING_SINGLE_LIST: return <SinglePickupList />;
      case ViewState.PICKING_BATCH_LIST: return <BatchPickupList />;
      case ViewState.PICKING_COMPLETED: return <PickupCompletedList />;
      case ViewState.PICKING_SETTINGS: return <PickerSettings />;
      case ViewState.PACKAGING_NORMAL: return <PackagingView />;
      case ViewState.PACKAGING_TODD: return <PackagingWithToddView />;
      case ViewState.DISPATCHING_NORMAL: return <DispatchingView />;
      case ViewState.DISPATCHING_BETA: return <DispatchingBetaView />;
      case ViewState.DISPATCHING_DELIVERED: return <DispatchToDeliveredView />;
      case ViewState.SELLER_ADD: return <AddSeller />;
      case ViewState.SELLER_ALL: return <ViewAllSellers />;
      case ViewState.SELLER_RATES: return <SellerRates />;
      case ViewState.SELLER_FINANCE: return <SellerFinance />;
      case ViewState.USER_ADD: return <AddUser />;
      case ViewState.USER_ALL: return <ViewAllUsers />;
      case ViewState.FINANCE_SET_FIXED: return <SetFixedRateCharges />;
      case ViewState.FINANCE_SET_DYNAMIC: return <SetDynamicRateCharges />;
      case ViewState.FINANCE_ALL_CATEGORIES: return <AllCategory />;
      case ViewState.FINANCE_STORAGE_INVOICES: return <StorageChargesInvoices />;
      case ViewState.FINANCE_TRANSACTION_REPORT: return <TransactionReport />;
      case ViewState.FINANCE_FIX_RATE_INVOICE: return <FixRateInvoice />;
      case ViewState.FINANCE_DYNAMIC_INVOICE: return <DynamicInvoice />;
      case ViewState.FINANCE_ALL_STORAGE_TYPES: return <AllStorageTypes />;
      case ViewState.FINANCE_CANCEL_ORDER: return <CancelOrderFinance />;
      case ViewState.FINANCE_CREATE_LM_INVOICE: return <CreateLMInvoice />;
      case ViewState.FINANCE_VIEW_LM_INVOICE: return <ViewLMInvoice />;
      case ViewState.FINANCE_BULK_CREATE: return <CreateBulkInvoice />;
      case ViewState.FINANCE_BULK_COD: return <BulkCODInvoices />;
      case ViewState.FINANCE_BULK_PAYABLE: return <PayableInvoices />;
      case ViewState.ROUTE_ADD: return <AddRoute />;
      case ViewState.ROUTE_ADD_BULK: return <AddRouteBulk />;
      case ViewState.ROUTE_SHOW: return <ShowRoute />;
      case ViewState.COURIER_VIEW_COMPANY: return <ViewCourierCompany />;
      case ViewState.COURIER_ADD_ZONE: return <AddZone />;
      case ViewState.COURIER_VIEW_ZONE: return <ViewZone />;
      case ViewState.COURIER_SHIPMENT_LOG: return <ShipmentLog />;
      case ViewState.COURIER_TRACKING_LOG: return <TrackingLog />;
      case ViewState.LOCATION_LIST: return <LocationList />;
      case ViewState.LOCATION_IMPORT: return <ImportLocation />;
      case ViewState.LOCATION_IMPORT_CITY: return <ImportDeliveryCity />;
      case ViewState.LOCATION_DELIVERY_COMPANY: return <DeliveryCompanyList />;
      case ViewState.LOCATION_ADD_COUNTRY: return <AddCountry />;
      case ViewState.LOCATION_ADD_MASTER: return <AddFromMaster />;
      case ViewState.FAQ_ADD: return <AddFAQ />;
      case ViewState.FAQ_SHOW: return <ShowFAQ />;
      case ViewState.REPORT_SHELVE: return <ShelveReport />;
      case ViewState.REPORT_TOP_PRODUCT: return <TopProductDispatch />;
      case ViewState.REPORT_OFD: return <OFDReport />;
      case ViewState.REPORT_STAFF_PERFORMANCE: return <StaffPerformance />;
      case ViewState.REPORT_DISPATCHING: return <DispatchingReport />;
      case ViewState.REPORT_3PL: return <Report3PL />;
      case ViewState.REPORT_PACKAGING: return <PackagingReport />;
      case ViewState.REPORT_ITEM_INVENTORY: return <ItemInventoryTotal />;
      case ViewState.REPORT_INBOUND: return <InboundRecord />;
      case ViewState.REPORT_INVENTORY_HISTORY: return <InventoryHistory />;
      case ViewState.REPORT_DAMAGE_HISTORY: return <DamageInventoryHistory />;
      case ViewState.REPORT_STORAGE: return <StorageReport />;
      case ViewState.REPORT_BULK_SHIPMENT: return <BulkShipmentReport />;
      case ViewState.ACCESS_NEW_TEMPLATE: return <NewTemplate />;
      case ViewState.ACCESS_SHOW_TEMPLATE: return <ShowTemplate />;
      case ViewState.INVESTMENT_DASHBOARD: return <InvestmentDashboard />;
      case ViewState.INVESTMENT_OPPORTUNITIES: return <InvestmentOpportunities />;
      case ViewState.INVESTMENT_SUBSCRIPTIONS: return <InvestmentSubscriptions />;
      case ViewState.CITY_LIST_VIEW: return <CityListView />;
      case ViewState.LOG_ORDER_GENERATED: return <LogViewer type="Order Generated" />;
      case ViewState.LOG_ORDER_CREATED: return <LogViewer type="Order Created" />;
      case ViewState.LOG_PICK_LIST: return <LogViewer type="Pick List" />;
      case ViewState.LOG_PACKED: return <LogViewer type="Packed" />;
      case ViewState.LOG_DISPATCHED: return <LogViewer type="Dispatched" />;
      case ViewState.LOG_DELIVERY: return <LogViewer type="Delivery" />;
      case ViewState.LOG_MANIFEST: return <LogViewer type="Manifest" />;
      case ViewState.LOG_DELIVERED: return <LogViewer type="Delivered" />;
      case ViewState.LOG_RETURNED: return <LogViewer type="Returned" />;
      case ViewState.LOGS: return <LogViewer type="System" />;
      default: return <div className="p-8 text-center text-gray-500">Select a module from the sidebar.</div>;
    }
  };

  return (
    <div className="flex bg-gray-50 min-h-screen">
      <Sidebar currentView={currentView} onChangeView={setCurrentView} />
      
      <div className="flex-1 ml-64">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 h-16 px-8 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-4 w-96">
            <h2 className="text-lg font-semibold text-gray-700 capitalize">
                {currentView.replace(/_/g, ' ').toLowerCase()}
            </h2>
          </div>

          <div className="flex items-center gap-6">
             <div className="relative hidden md:block">
                 <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                 <input 
                    type="text" 
                    placeholder="Global Search..." 
                    className="pl-10 pr-4 py-1.5 border border-gray-300 rounded-full text-sm w-64 focus:ring-2 focus:ring-blue-500 outline-none"
                 />
             </div>
             
             <button className="relative text-gray-500 hover:text-gray-700">
                <Bell size={20} />
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full"></span>
             </button>
             
             <div className="flex items-center gap-3 cursor-pointer border-l pl-6 border-gray-200 group relative">
                <div className="text-right hidden md:block">
                    <p className="text-sm font-medium text-gray-800">{user?.name || 'User'}</p>
                    <p className="text-xs text-gray-500">{user?.role || 'Staff'}</p>
                </div>
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold">
                    <User size={16} />
                </div>
                
                {/* User Dropdown */}
                <div className="absolute top-full right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-100 hidden group-hover:block py-1">
                    <button 
                        onClick={logout}
                        className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
                    >
                        <LogOut size={16} /> Sign Out
                    </button>
                </div>
             </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="p-8">
          {renderContent()}
        </main>
      </div>

      <Assistant />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
