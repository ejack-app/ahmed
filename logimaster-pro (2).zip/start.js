
import { execSync, spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('🚀 Starting LogiMaster Pro Deployment Script...');

try {
    // 1. Install Root Dependencies (Frontend)
    console.log('📦 Installing Frontend Dependencies...');
    if (!fs.existsSync(path.join(__dirname, 'node_modules'))) {
        execSync('npm install --legacy-peer-deps', { stdio: 'inherit' });
    } else {
        console.log('   -> Dependencies already exist. Skipping npm install.');
    }

    // 2. Install Backend Dependencies
    console.log('📦 Checking Backend Dependencies...');
    const backendPath = path.join(__dirname, 'backend');
    if (fs.existsSync(backendPath)) {
        if (!fs.existsSync(path.join(backendPath, 'node_modules'))) {
             console.log('   -> Installing backend modules...');
             execSync('npm install --legacy-peer-deps', { cwd: backendPath, stdio: 'inherit' });
        }
    } else {
        console.warn('⚠️  Backend folder not found. Skipping backend install.');
    }

    // 3. Build Frontend
    console.log('🏗️  Building Frontend Assets (Vite)...');
    try {
        execSync('npm run build', { stdio: 'inherit' });
        console.log('✅ Build successful. "dist" folder ready.');
    } catch (e) {
        console.error('❌ Build failed. Please check the error logs above.');
        process.exit(1);
    }

    // 4. Start Server
    console.log('✅ Setup complete. Starting Node.js Server...');
    const serverPath = path.join(__dirname, 'backend', 'server.js');
    
    if (!fs.existsSync(serverPath)) {
        console.error('❌ Error: backend/server.js not found!');
        console.log('   Please ensure the backend folder exists.');
        process.exit(1);
    }

    const server = spawn('node', [serverPath], { stdio: 'inherit' });

    server.on('close', (code) => {
        console.log(`Server process exited with code ${code}`);
    });

} catch (error) {
    console.error('❌ An unexpected error occurred:', error);
}
