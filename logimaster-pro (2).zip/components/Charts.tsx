
import React from 'react';

export const SimpleBarChart: React.FC<{ data: number[], labels: string[], color?: string, height?: string }> = ({ data, labels, color = 'bg-blue-500', height = '200px' }) => {
    const max = Math.max(...data, 1);
    return (
        <div className="w-full flex flex-col justify-end pt-10 pb-2">
            <div className="flex items-end justify-between gap-2" style={{ height }}>
                {data.map((val, i) => (
                    <div key={i} className="flex flex-col items-center flex-1 group relative">
                        <div className="relative w-full flex justify-center h-full items-end">
                            <div 
                                className={`w-3/4 rounded-t-md transition-all duration-700 ${color} opacity-80 group-hover:opacity-100`} 
                                style={{ height: `${(val / max) * 100}%` }}
                            ></div>
                            <div className="absolute -top-8 bg-gray-800 text-white text-[10px] py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                                {val.toLocaleString()}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            <div className="flex justify-between mt-2 border-t border-gray-200 pt-2">
                {labels.map((lbl, i) => (
                    <span key={i} className="text-[10px] text-gray-500 text-center flex-1 truncate px-1" title={lbl}>{lbl}</span>
                ))}
            </div>
        </div>
    );
};

export const SimpleLineChart: React.FC<{ data: number[], color?: string }> = ({ data, color = '#3b82f6' }) => {
    const max = Math.max(...data, 1);
    const min = Math.min(...data);
    const points = data.map((val, i) => {
        const x = (i / (data.length - 1)) * 100;
        const y = 100 - ((val - min) / (max - min || 1)) * 80 - 10; // Normalized Y
        return `${x},${y}`;
    }).join(' ');

    return (
        <div className="w-full h-full relative pt-4 min-h-[150px]">
            <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full overflow-visible">
                {/* Grid Lines */}
                <line x1="0" y1="25" x2="100" y2="25" stroke="#e5e7eb" strokeWidth="0.5" strokeDasharray="2" />
                <line x1="0" y1="50" x2="100" y2="50" stroke="#e5e7eb" strokeWidth="0.5" strokeDasharray="2" />
                <line x1="0" y1="75" x2="100" y2="75" stroke="#e5e7eb" strokeWidth="0.5" strokeDasharray="2" />
                
                {/* Line */}
                <polyline 
                    fill="none" 
                    stroke={color} 
                    strokeWidth="2" 
                    points={points} 
                    strokeLinecap="round" 
                    strokeLinejoin="round"
                    className="drop-shadow-sm"
                />
                
                {/* Points */}
                {data.map((val, i) => {
                    const x = (i / (data.length - 1)) * 100;
                    const y = 100 - ((val - min) / (max - min || 1)) * 80 - 10;
                    return (
                        <circle key={i} cx={x} cy={y} r="1.5" fill="white" stroke={color} strokeWidth="1" className="hover:r-2 transition-all" />
                    );
                })}
            </svg>
        </div>
    );
};
