
import React, { useEffect, useState } from 'react';
import { TrendingUp, Package, Truck, AlertCircle, Loader } from 'lucide-react';
import { api } from '../utils/api';

export const DashboardStats: React.FC = () => {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const data = await api.get('/dashboard/stats');
        setStats(data);
      } catch (error) {
        console.error("Failed to load stats", error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) {
    return <div className="p-6 text-center text-gray-500"><Loader className="animate-spin inline mr-2"/> Loading Dashboard...</div>;
  }

  // Fallback if API fails or returns empty
  const data = stats || {
    shipments: { total: 0, delivered: 0, pending: 0 },
    revenue: 0,
    inventory: { total_stock: 0 }
  };

  const statCards = [
    { 
      title: 'Total Shipments', 
      value: data.shipments.total.toLocaleString(), 
      change: `+${data.shipments.pending} Pending`, 
      icon: <Package className="text-blue-600" />, 
      color: 'bg-blue-50' 
    },
    { 
      title: 'Delivered', 
      value: data.shipments.delivered.toLocaleString(), 
      change: `${((data.shipments.delivered / (data.shipments.total || 1)) * 100).toFixed(1)}% Rate`, 
      icon: <Truck className="text-green-600" />, 
      color: 'bg-green-50' 
    },
    { 
      title: 'Stock Level', 
      value: data.inventory.total_stock?.toLocaleString() || '0', 
      change: 'Units in Warehouse', 
      icon: <AlertCircle className="text-orange-600" />, 
      color: 'bg-orange-50' 
    },
    { 
      title: 'Revenue (Invoiced)', 
      value: `SAR ${data.revenue.toLocaleString()}`, 
      change: 'Total Paid', 
      icon: <TrendingUp className="text-purple-600" />, 
      color: 'bg-purple-50' 
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statCards.map((stat, idx) => (
        <div key={idx} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-500">{stat.title}</p>
              <h3 className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</h3>
            </div>
            <div className={`p-3 rounded-lg ${stat.color}`}>
              {stat.icon}
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <span className={`text-xs font-medium px-2 py-1 rounded-full ${stat.change.includes('Pending') ? 'text-orange-700 bg-orange-100' : 'text-green-700 bg-green-100'}`}>
              {stat.change}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
};
