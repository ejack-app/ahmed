import React, { useState } from 'react';
import { 
  Settings, Layers, Truck, Package, Map, Box, Car, Undo2, Warehouse,
  ClipboardList, Ticket, Tags, UserCheck, Gift, Send, Store, Users,
  DollarSign, Route, MapPin, HelpCircle, BarChart, Shield, Building,
  ScrollText, ChevronDown, ChevronRight, FileText, ArrowDownCircle, Briefcase, GitBranch, FileSpreadsheet, UserPlus, RotateCcw, CalendarClock, Globe, MapPinned, LayoutGrid, MessageSquare, AppWindow, TrendingUp
} from 'lucide-react';
import { ViewState, MenuItem } from '../types';

interface SidebarProps {
  currentView: ViewState;
  onChangeView: (view: ViewState) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView }) => {
  // Initialize with some expanded menus to show structure
  const [expandedMenus, setExpandedMenus] = useState<string[]>(['Shipment Management', 'Inventory Management', 'Reports Management', 'Finance Management', 'Warehouse Management', 'Live Tracking', 'Investment Department']);

  const toggleMenu = (label: string) => {
    setExpandedMenus(prev => 
      prev.includes(label) ? prev.filter(l => l !== label) : [...prev, label]
    );
  };

  const menuStructure: MenuItem[] = [
    {
      label: 'Company Details',
      icon: <Settings size={18} />,
      children: [
        { label: 'Default', view: ViewState.COMPANY_DETAILS },
        { label: 'Courier Company', view: ViewState.COMPANY_COURIER_DETAILS },
        { label: 'Privacy Policy', view: ViewState.COMPANY_PRIVACY },
        { label: 'Terms & Conditions', view: ViewState.COMPANY_TERMS },
      ]
    },
    {
      label: 'Applications',
      icon: <AppWindow size={18} />,
      view: ViewState.APP_MARKETPLACE
    },
    {
      label: 'Communication',
      icon: <MessageSquare size={18} />,
      view: ViewState.COMMUNICATION_HUB
    },
    {
      label: 'Integration',
      icon: <Layers size={18} />,
      children: [
        { label: 'Zid Configuration', view: ViewState.INTEGRATION_ZID },
        { label: 'Salla Configuration', view: ViewState.INTEGRATION_SALLA },
        { label: 'CITC Configuration', view: ViewState.INTEGRATION_CITC },
        { label: 'SMS Configuration', view: ViewState.INTEGRATION_SMS },
        { label: 'Salla App Config', view: ViewState.INTEGRATION_SALLA_APP },
        { label: 'Zid App Config', view: ViewState.INTEGRATION_ZID_APP },
      ]
    },
    {
      label: 'Shipment Management',
      icon: <Truck size={18} />,
      children: [
        { label: 'Add Shipment', view: ViewState.SHIPMENT_ADD },
        { label: 'All Orders', view: ViewState.SHIPMENTS_ALL },
        { label: 'Bulk Update', view: ViewState.SHIPMENT_BULK_UPDATE },
        { label: 'Bulk Forward - 3PL', view: ViewState.SHIPMENT_BULK_FORWARD_3PL },
        { label: 'Manual Forward - 3PL', view: ViewState.SHIPMENT_MANUAL_FORWARD_3PL },
        { label: 'Reverse Orders', view: ViewState.SHIPMENTS_REVERSE },
        { label: 'Create Reverse Order', view: ViewState.SHIPMENT_CREATE_REVERSE },
        { label: 'Cancel Orders - 3PL', view: ViewState.SHIPMENT_CANCEL_3PL },
        { label: 'Bulk Print', view: ViewState.SHIPMENT_BULK_PRINT },
        { label: 'Forward Remove', view: ViewState.SHIPMENT_FORWARD_REMOVE },
        { label: 'Deleted Orders', view: ViewState.SHIPMENT_DELETED },
        { label: 'Cancelled Orders', view: ViewState.SHIPMENT_CANCELLED },
        { label: 'Salla Pending Orders', view: ViewState.SHIPMENT_SALLA_PENDING },
        { label: 'Shipment Mapping', view: ViewState.SHIPMENT_MAPPING },
        { label: 'Zid Order Listing', view: ViewState.SHIPMENT_ZID_LISTING },
        { label: 'Bulk Order Create (BETA)', view: ViewState.SHIPMENT_BULK_CREATE },
        { label: 'Bulk Update Date', view: ViewState.SHIPMENT_BULK_UPDATE_DATE },
      ]
    },
    {
      label: 'Couriers Management',
      icon: <UserPlus size={18} />,
      children: [
        { label: 'Add Couriers', view: ViewState.COURIER_MANAGEMENT_ADD },
        { label: 'Show Couriers', view: ViewState.COURIER_MANAGEMENT_LIST },
        { label: 'Odo Meter Detail', view: ViewState.COURIER_MANAGEMENT_ODO_LIST },
      ]
    },
    {
      label: 'Delivery Run Sheet',
      icon: <FileSpreadsheet size={18} />,
      children: [
        { label: 'Add DRS', view: ViewState.DRS_ADD },
        { label: 'Show DRS', view: ViewState.DRS_LIST },
        { label: 'Scan New DRS', view: ViewState.DRS_SCAN_NEW },
      ]
    },
    {
      label: 'Pickup Management',
      icon: <ArrowDownCircle size={18} />,
      children: [
        { label: 'Bulk Pickup Update', view: ViewState.PICKUP_BULK_UPDATE },
        { label: 'Add Pickup Sheet', view: ViewState.PICKUP_ADD_SHEET },
        { label: 'Pickup List', view: ViewState.PICKUP_LIST },
        { label: 'Scan New Pickup', view: ViewState.PICKUP_SCAN_NEW },
        { label: 'Show Pickup Detail', view: ViewState.PICKUP_DETAILS },
      ]
    },
    {
      label: 'Schedule Management',
      icon: <CalendarClock size={18} />,
      children: [
        { label: 'Blind Schedule', view: ViewState.SCHEDULE_BLIND },
        { label: 'Bulk On Hold', view: ViewState.SCHEDULE_BULK_ONHOLD },
        { label: 'Bulk Reschedule', view: ViewState.SCHEDULE_BULK_RESCHEDULE },
        { label: 'CS Schedule', view: ViewState.SCHEDULE_CS },
        { label: 'Bulk Schedule Remove', view: ViewState.SCHEDULE_BULK_REMOVE },
      ]
    },
    {
      label: 'RTO Management',
      icon: <RotateCcw size={18} />,
      children: [
        { label: 'Show Pending', view: ViewState.RTO_PENDING_LIST },
        { label: 'Show RTO List', view: ViewState.RTO_LIST },
      ]
    },
    {
      label: 'Zone Management',
      icon: <Globe size={18} />,
      children: [
        { label: 'Add Zone List', view: ViewState.ZONE_ADD_LIST },
        { label: 'Set City Zone', view: ViewState.ZONE_SET_CITY },
        { label: 'Set Country Zone', view: ViewState.ZONE_SET_COUNTRY },
      ]
    },
    {
      label: 'Live Tracking',
      icon: <MapPinned size={18} />,
      children: [
        { label: 'Driver Map', view: ViewState.LIVE_DRIVER_MAP },
        { label: 'Shipment Path', view: ViewState.SHIPMENT_PATH_MAP },
      ]
    },
    {
      label: 'Out Source Management',
      icon: <Briefcase size={18} />,
      children: [
        { label: 'Add Supplier', view: ViewState.OUTSOURCE_ADD_SUPPLIER },
        { label: 'Show Supplier', view: ViewState.OUTSOURCE_SUPPLIER_LIST },
        { label: 'Generate Invoice', view: ViewState.OUTSOURCE_GENERATE_INVOICE },
        { label: 'Payment Information', view: ViewState.OUTSOURCE_PAYMENT_INFO },
      ]
    },
    {
      label: 'Branch Management',
      icon: <GitBranch size={18} />,
      children: [
        { label: 'Add Branch', view: ViewState.BRANCH_ADD },
        { label: 'Show Branch', view: ViewState.BRANCH_LIST },
      ]
    },
    {
      label: 'Inventory Management',
      icon: <Package size={18} />,
      children: [
        { label: 'Add Item Inventory', view: ViewState.INVENTORY_ADD_ITEM },
        { label: 'View Item Inventory', view: ViewState.INVENTORY_ITEMS },
        { label: 'Add Shelf', view: ViewState.INVENTORY_ADD_SHELF },
        { label: 'View Shelf', view: ViewState.INVENTORY_SHELVES },
        { label: 'Update Shelf', view: ViewState.INVENTORY_UPDATE_SHELF },
        { label: 'Merge Stock', view: ViewState.INVENTORY_MERGE_STOCK },
        { label: 'Inventory Per Client', view: ViewState.INVENTORY_PER_CLIENT },
        { label: 'Upload Inventory (ADD)', view: ViewState.INVENTORY_UPLOAD },
      ]
    },
    {
      label: 'Stock Location Management',
      icon: <Map size={18} />,
      children: [
        { label: 'Generate Stock Location', view: ViewState.STOCK_LOCATION_GENERATE },
        { label: 'All Stock Location', view: ViewState.STOCK_LOCATION_ALL },
        { label: 'Bulk Print Stock Location', view: ViewState.STOCK_LOCATION_BULK_PRINT },
        { label: 'Assigned Stock Location', view: ViewState.STOCK_LOCATION_ASSIGNED },
        { label: 'Unassigned Stock Location', view: ViewState.STOCK_LOCATION_UNASSIGNED },
      ]
    },
    {
      label: 'Item Management',
      icon: <Box size={18} />,
      children: [
        { label: 'Add Item', view: ViewState.ITEM_ADD },
        { label: 'View All Items', view: ViewState.ITEM_ALL },
        { label: 'Bulk SKU Print', view: ViewState.ITEM_BULK_PRINT },
        { label: 'Bulk Item Update', view: ViewState.ITEM_BULK_UPDATE },
        { label: 'Import Items (ADD)', view: ViewState.ITEM_IMPORT },
      ]
    },
    {
      label: 'Vehicle Management',
      icon: <Car size={18} />,
      children: [
        { label: 'Add Vehicle', view: ViewState.VEHICLE_ADD },
        { label: 'Vehicle List', view: ViewState.VEHICLE_LIST },
      ]
    },
    {
      label: 'Box Management',
      icon: <Box size={18} />,
      children: [
        { label: 'Add Box', view: ViewState.BOX_ADD },
        { label: 'Box List', view: ViewState.BOX_LIST },
      ]
    },
    {
      label: 'Return Manifest',
      icon: <Undo2 size={18} />,
      children: [
        { label: 'Show Damage Item', view: ViewState.RETURN_DAMAGE_ITEM },
        { label: 'Return Order List', view: ViewState.RETURN_ORDER_LIST },
      ]
    },
    {
      label: 'Warehouse Management',
      icon: <Warehouse size={18} />,
      children: [
        { label: 'Layout Planner (3D)', view: ViewState.WAREHOUSE_LAYOUT },
        { label: 'Generate Tods', view: ViewState.WAREHOUSE_GENERATE_TODS },
        { label: 'Show Todd', view: ViewState.WAREHOUSE_SHOW_TODD },
        { label: 'Add Warehouse', view: ViewState.WAREHOUSE_ADD },
        { label: 'View Warehouse', view: ViewState.WAREHOUSE_VIEW },
        { label: 'Scan InBound', view: ViewState.WAREHOUSE_SCAN_INBOUND },
        { label: 'Scan OnHold', view: ViewState.WAREHOUSE_SCAN_ONHOLD },
        { label: 'Inventory Report', view: ViewState.WAREHOUSE_INVENTORY_REPORT },
        { label: 'Scan Shelve', view: ViewState.WAREHOUSE_SCAN_SHELVE },
        { label: 'Scan Schedule', view: ViewState.WAREHOUSE_SCAN_SCHEDULE },
        { label: 'Security Check', view: ViewState.WAREHOUSE_SECURITY_CHECK },
      ]
    },
    {
      label: 'Manifest Management',
      icon: <ClipboardList size={18} />,
      children: [
        { label: 'New Manifest', view: ViewState.MANIFEST_NEW },
        { label: 'Pickup List', view: ViewState.MANIFEST_PICKUP_LIST },
        { label: 'Manifest List', view: ViewState.MANIFEST_LIST },
        { label: 'Show Assigned List', view: ViewState.MANIFEST_ASSIGNED_LIST },
      ]
    },
    {
      label: 'Manifest Management New (Beta)',
      icon: <ClipboardList size={18} />,
      children: [
        { label: 'New Manifest', view: ViewState.MANIFEST_BETA_NEW },
        { label: 'Pickup List', view: ViewState.MANIFEST_BETA_PICKUP_LIST },
        { label: 'Manifest List', view: ViewState.MANIFEST_BETA_LIST },
        { label: 'Show Assigned List', view: ViewState.MANIFEST_BETA_ASSIGNED_LIST },
      ]
    },
    {
      label: 'Ticket Management',
      icon: <Ticket size={18} />,
      children: [
        { label: 'All List', view: ViewState.TICKET_ALL },
        { label: 'Manifest Ticket', view: ViewState.TICKET_MANIFEST },
      ]
    },
    {
      label: 'Offer Management',
      icon: <Tags size={18} />,
      children: [
        { label: 'Bundle-Offers List', view: ViewState.OFFER_BUNDLE_LIST },
        { label: 'Add New Bundle Offers', view: ViewState.OFFER_ADD_BUNDLE },
        { label: 'Bundle - Orders List', view: ViewState.OFFER_BUNDLE_ORDERS },
      ]
    },
    {
      label: 'Pickers Management',
      icon: <UserCheck size={18} />,
      children: [
        { label: 'Single Pickup List', view: ViewState.PICKING_SINGLE_LIST },
        { label: 'Batch Pickup List', view: ViewState.PICKING_BATCH_LIST },
        { label: 'Pickup Completed List', view: ViewState.PICKING_COMPLETED },
        { label: 'Picker Settings', view: ViewState.PICKING_SETTINGS },
      ]
    },
    {
      label: 'Packaging Management',
      icon: <Gift size={18} />,
      children: [
        { label: 'Packaging', view: ViewState.PACKAGING_NORMAL },
        { label: 'Packaging With Todd', view: ViewState.PACKAGING_TODD },
      ]
    },
    {
      label: 'Dispatching Management',
      icon: <Send size={18} />,
      children: [
        { label: 'Dispatching', view: ViewState.DISPATCHING_NORMAL },
        { label: 'Dispatching (BETA)', view: ViewState.DISPATCHING_BETA },
        { label: 'Dispatch To Delivered', view: ViewState.DISPATCHING_DELIVERED },
      ]
    },
    {
      label: 'Seller Management',
      icon: <Store size={18} />,
      children: [
        { label: 'Add Seller', view: ViewState.SELLER_ADD },
        { label: 'View All Sellers', view: ViewState.SELLER_ALL },
        { label: 'Seller Rates', view: ViewState.SELLER_RATES },
        { label: 'Seller Finance', view: ViewState.SELLER_FINANCE },
      ]
    },
    {
      label: 'Users Management',
      icon: <Users size={18} />,
      children: [
        { label: 'View All Users', view: ViewState.USER_ALL },
        { label: 'Add User', view: ViewState.USER_ADD },
      ]
    },
    {
      label: 'Finance Management',
      icon: <DollarSign size={18} />,
      children: [
        { label: 'Set Fixed Rate Charges', view: ViewState.FINANCE_SET_FIXED },
        { label: 'Set Dynamic Rate Charges', view: ViewState.FINANCE_SET_DYNAMIC },
        { label: 'All Category', view: ViewState.FINANCE_ALL_CATEGORIES },
        { label: 'Storage Charges Invoices', view: ViewState.FINANCE_STORAGE_INVOICES },
        { label: 'Transaction Report', view: ViewState.FINANCE_TRANSACTION_REPORT },
        { label: 'Fix Rate Invoice', view: ViewState.FINANCE_FIX_RATE_INVOICE },
        { label: 'Dynamic Invoice', view: ViewState.FINANCE_DYNAMIC_INVOICE },
        { label: 'All Storage Types', view: ViewState.FINANCE_ALL_STORAGE_TYPES },
        { label: 'Cancel Order', view: ViewState.FINANCE_CANCEL_ORDER },
        { label: 'Create LM Invoice', view: ViewState.FINANCE_CREATE_LM_INVOICE },
        { label: 'View LM Invoice', view: ViewState.FINANCE_VIEW_LM_INVOICE },
        {
            label: 'Bulk Invoice Management',
            icon: <FileText size={18} />,
            children: [
                { label: 'Create Bulk Invoice', view: ViewState.FINANCE_BULK_CREATE },
                { label: 'Bulk COD Invoices', view: ViewState.FINANCE_BULK_COD },
                { label: 'Payable Invoices', view: ViewState.FINANCE_BULK_PAYABLE },
            ]
        }
      ]
    },
    {
      label: 'Route Management',
      icon: <Route size={18} />,
      children: [
        { label: 'Add Route', view: ViewState.ROUTE_ADD },
        { label: 'Add Route Bulk', view: ViewState.ROUTE_ADD_BULK },
        { label: 'Show Route', view: ViewState.ROUTE_SHOW },
      ]
    },
    {
      label: 'Courier Service Management',
      icon: <Truck size={18} />,
      children: [
        { label: 'View Courier Company', view: ViewState.COURIER_VIEW_COMPANY },
        { label: 'Add Zone', view: ViewState.COURIER_ADD_ZONE },
        { label: 'View Zone', view: ViewState.COURIER_VIEW_ZONE },
        { label: 'Shipment Log', view: ViewState.COURIER_SHIPMENT_LOG },
        { label: 'Tracking Log', view: ViewState.COURIER_TRACKING_LOG },
      ]
    },
    {
      label: 'Location',
      icon: <MapPin size={18} />,
      children: [
        { label: 'Location List', view: ViewState.LOCATION_LIST },
        { label: 'Import Location', view: ViewState.LOCATION_IMPORT },
        { label: 'Import Delivery City', view: ViewState.LOCATION_IMPORT_CITY },
        { label: 'Delivery Company List', view: ViewState.LOCATION_DELIVERY_COMPANY },
        { label: 'Add Country', view: ViewState.LOCATION_ADD_COUNTRY },
        { label: 'Add From Master', view: ViewState.LOCATION_ADD_MASTER },
      ]
    },
    {
      label: 'FAQ',
      icon: <HelpCircle size={18} />,
      children: [
        { label: 'Add FAQ', view: ViewState.FAQ_ADD },
        { label: 'Show FAQ', view: ViewState.FAQ_SHOW },
      ]
    },
    {
      label: 'Reports Management',
      icon: <BarChart size={18} />,
      children: [
        { label: 'Shelve Report', view: ViewState.REPORT_SHELVE },
        { label: 'Top Product Dispatch', view: ViewState.REPORT_TOP_PRODUCT },
        { label: 'OFD Report', view: ViewState.REPORT_OFD },
        { label: 'Staff Performance', view: ViewState.REPORT_STAFF_PERFORMANCE },
        { label: 'Dispatching Report', view: ViewState.REPORT_DISPATCHING },
        { label: '3PL Report', view: ViewState.REPORT_3PL },
        { label: 'Packaging Report', view: ViewState.REPORT_PACKAGING },
        { label: 'Item Inventory Total', view: ViewState.REPORT_ITEM_INVENTORY },
        { label: 'Inbound Record', view: ViewState.REPORT_INBOUND },
        { label: 'Inventory History', view: ViewState.REPORT_INVENTORY_HISTORY },
        { label: 'Damage Inventory History', view: ViewState.REPORT_DAMAGE_HISTORY },
        { label: 'Storage Report', view: ViewState.REPORT_STORAGE },
        { label: 'Bulk Shipment Report', view: ViewState.REPORT_BULK_SHIPMENT },
      ]
    },
    {
      label: 'Access Management',
      icon: <Shield size={18} />,
      children: [
        { label: 'New Template', view: ViewState.ACCESS_NEW_TEMPLATE },
        { label: 'Show Template', view: ViewState.ACCESS_SHOW_TEMPLATE },
      ]
    },
    {
      label: 'CityList',
      icon: <Building size={18} />,
      view: ViewState.CITY_LIST_VIEW
    },
    {
      label: 'Logs',
      icon: <ScrollText size={18} />,
      children: [
        { label: 'ORDER GENERATED', view: ViewState.LOG_ORDER_GENERATED },
        { label: 'ORDER CREATED', view: ViewState.LOG_ORDER_CREATED },
        { label: 'PICK LIST', view: ViewState.LOG_PICK_LIST },
        { label: 'PACKED', view: ViewState.LOG_PACKED },
        { label: 'DISPATCHED', view: ViewState.LOG_DISPATCHED },
        { label: 'DELIVERY', view: ViewState.LOG_DELIVERY },
        { label: 'MANIFEST', view: ViewState.LOG_MANIFEST },
        { label: 'DELIVERED', view: ViewState.LOG_DELIVERED },
        { label: 'RETURNED', view: ViewState.LOG_RETURNED },
      ]
    },
    {
      label: 'Investment Department',
      icon: <TrendingUp size={18} />,
      children: [
        { label: 'Dashboard', view: ViewState.INVESTMENT_DASHBOARD },
        { label: 'Opportunities (Rounds)', view: ViewState.INVESTMENT_OPPORTUNITIES },
        { label: 'Subscriptions', view: ViewState.INVESTMENT_SUBSCRIPTIONS },
      ]
    }
  ];

  const renderMenuItem = (item: MenuItem, depth = 0) => {
    const isExpanded = expandedMenus.includes(item.label);
    const hasChildren = item.children && item.children.length > 0;
    const isActive = item.view === currentView;

    return (
      <div key={item.label} className="w-full">
        <button
          onClick={() => {
            if (hasChildren) toggleMenu(item.label);
            else if (item.view) onChangeView(item.view);
          }}
          className={`
            w-full flex items-center justify-between px-4 py-2.5 text-xs font-medium transition-colors
            ${isActive ? 'bg-blue-800 text-white' : 'text-gray-300 hover:bg-slate-800 hover:text-white'}
            ${depth > 0 ? 'pl-10' : ''}
          `}
        >
          <div className="flex items-center gap-3">
            {item.icon}
            <span>{item.label}</span>
          </div>
          {hasChildren && (
            isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />
          )}
        </button>
        
        {hasChildren && isExpanded && (
          <div className="bg-slate-900 border-l border-slate-700 ml-4">
            {item.children!.map(child => renderMenuItem(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="h-screen w-64 bg-slate-900 flex flex-col fixed left-0 top-0 overflow-hidden shadow-xl z-20">
      <div className="p-5 border-b border-slate-700 bg-slate-900 z-10">
        <h1 className="text-xl font-bold text-white tracking-wider flex items-center gap-2">
          <Box className="text-blue-500" />
          LOGIMASTER
        </h1>
        <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-widest">Enterprise V3.0</p>
      </div>
      
      <div className="flex-1 overflow-y-auto scrollbar-hide py-2 pb-20">
        {menuStructure.map(item => renderMenuItem(item))}
      </div>

      <div className="absolute bottom-0 w-full p-4 border-t border-slate-700 bg-slate-900">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold text-xs">
            AD
          </div>
          <div className="overflow-hidden">
            <p className="text-sm text-white truncate">Admin User</p>
            <p className="text-xs text-green-400">● Online</p>
          </div>
        </div>
      </div>
    </div>
  );
};