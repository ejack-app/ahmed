import React from 'react';
import { AlertOctagon, Download, Search, Filter, Eye } from 'lucide-react';

// Reusable Header
const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Show Damage Item
export const ShowDamageItem: React.FC = () => {
    // Mock Data
    const items = [
        { sku: 'ELEC-001', name: 'Wireless Mouse', order: 'ORD-2024-1005', reason: 'Cracked Casing', date: '2024-02-15', status: 'Pending Inspection' },
        { sku: 'HOME-221', name: 'Glass Vase', order: 'ORD-2024-0992', reason: 'Shattered', date: '2024-02-14', status: 'Disposed' },
        { sku: 'FASH-991', name: 'Leather Bag', order: 'ORD-2024-1011', reason: 'Zipper Broken', date: '2024-02-16', status: 'Sent for Repair' },
    ];

    return (
        <div>
            <Header title="Damaged Items Registry" description="List of items returned due to damage or defects." />
            
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search SKU or Order ID..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                    <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 flex items-center gap-2">
                        <Filter size={16} /> Filter
                    </button>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Item SKU</th>
                            <th className="px-6 py-4">Product Name</th>
                            <th className="px-6 py-4">Original Order</th>
                            <th className="px-6 py-4">Damage Reason</th>
                            <th className="px-6 py-4">Report Date</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {items.map((item, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono font-medium text-red-600">{item.sku}</td>
                                <td className="px-6 py-4">{item.name}</td>
                                <td className="px-6 py-4 text-blue-600">{item.order}</td>
                                <td className="px-6 py-4">{item.reason}</td>
                                <td className="px-6 py-4">{item.date}</td>
                                <td className="px-6 py-4">
                                     <span className={`px-2 py-1 rounded-full text-xs font-medium 
                                        ${item.status === 'Disposed' ? 'bg-red-100 text-red-700' : 
                                          item.status === 'Sent for Repair' ? 'bg-yellow-100 text-yellow-700' : 
                                          'bg-gray-100 text-gray-700'}`}>
                                        {item.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-gray-400 hover:text-gray-600 flex items-center gap-1 justify-end w-full">
                                        <Eye size={16} /> View
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
             </div>
        </div>
    );
};

// 2. Return Order List
export const ReturnOrderList: React.FC = () => {
    // Mock Data
    const returns = [
        { id: 'RET-001', original: 'ORD-2024-1005', customer: 'Sarah Connor', date: '2024-02-15', status: 'Received at Hub' },
        { id: 'RET-002', original: 'ORD-2024-0992', customer: 'John Smith', date: '2024-02-14', status: 'Inspected' },
        { id: 'RET-003', original: 'ORD-2024-1011', customer: 'Kyle Reese', date: '2024-02-16', status: 'In Transit' },
    ];

    return (
        <div>
            <Header 
                title="Return Manifests" 
                description="Track ongoing return shipments from customers."
                action={
                    <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg flex items-center gap-2 hover:bg-gray-50">
                        <Download size={16} /> Export Manifest
                    </button>
                }
            />
            
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search Return ID..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Return ID</th>
                            <th className="px-6 py-4">Original Order</th>
                            <th className="px-6 py-4">Customer</th>
                            <th className="px-6 py-4">Return Date</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {returns.map((ret, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono font-medium text-orange-600">{ret.id}</td>
                                <td className="px-6 py-4 text-blue-600">{ret.original}</td>
                                <td className="px-6 py-4">{ret.customer}</td>
                                <td className="px-6 py-4">{ret.date}</td>
                                <td className="px-6 py-4">
                                     <span className={`px-2 py-1 rounded-full text-xs font-medium 
                                        ${ret.status === 'Received at Hub' ? 'bg-green-100 text-green-700' : 
                                          ret.status === 'Inspected' ? 'bg-blue-100 text-blue-700' : 
                                          'bg-yellow-100 text-yellow-700'}`}>
                                        {ret.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-gray-400 hover:text-gray-600">
                                        Details
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
             </div>
        </div>
    );
};