import React from 'react';
import { Car, Save, Search, Filter, Calendar, MapPin, User, MoreHorizontal } from 'lucide-react';

// Reusable Header
const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Add Vehicle
export const AddVehicle: React.FC = () => {
    return (
        <div className="max-w-3xl mx-auto pb-10">
            <Header title="Add New Vehicle" description="Register a new vehicle to the logistics fleet." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Vehicle Type</label>
                        <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                            <option>Delivery Van</option>
                            <option>Motorbike</option>
                            <option>Truck (3 Ton)</option>
                            <option>Truck (7 Ton)</option>
                        </select>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Registration Plate</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. 1234 ABC" />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Make</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. Toyota" />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Model Year</label>
                        <input type="number" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. 2023" />
                    </div>
                    
                    <div className="md:col-span-2 mt-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Assign Driver (Optional)</label>
                        <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                            <option>Unassigned</option>
                            <option>Ahmed Al-Rashid</option>
                            <option>John Doe</option>
                        </select>
                    </div>
                     <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Capacity (Max Load)</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. 500 KG" />
                    </div>
                </div>

                <div className="mt-8 flex justify-end gap-3">
                    <button className="px-5 py-2.5 text-gray-700 hover:bg-gray-100 rounded-lg font-medium">Cancel</button>
                    <button className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                        <Save size={18} /> Register Vehicle
                    </button>
                </div>
            </div>
        </div>
    );
};

// 2. Vehicle List
export const VehicleList: React.FC = () => {
    // Mock Data
    const vehicles = [
        { id: 'V-101', type: 'Delivery Van', plate: '8821 KSA', driver: 'Ahmed Ali', status: 'In Transit', location: 'Riyadh, Olaya' },
        { id: 'V-102', type: 'Motorbike', plate: '9921 BCD', driver: 'Mohammed S.', status: 'Idle', location: 'Warehouse A' },
        { id: 'V-103', type: 'Truck (3 Ton)', plate: '4452 JKL', driver: 'Fahad K.', status: 'Maintenance', location: 'Workshop' },
        { id: 'V-104', type: 'Delivery Van', plate: '1122 MNO', driver: 'Unassigned', status: 'Available', location: 'Warehouse B' },
        { id: 'V-105', type: 'Delivery Van', plate: '6633 PQR', driver: 'Omar F.', status: 'In Transit', location: 'Jeddah, Rawdah' },
    ];

    return (
        <div>
            <Header 
                title="Fleet Management" 
                description="Monitor and manage all logistics vehicles."
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Car size={16} /> Add Vehicle
                    </button>
                }
            />
            
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search Plate, Driver, or ID..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                    <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 flex items-center gap-2">
                        <Filter size={16} /> Filter Status
                    </button>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Vehicle ID</th>
                            <th className="px-6 py-4">Type</th>
                            <th className="px-6 py-4">Plate No.</th>
                            <th className="px-6 py-4">Driver</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4">Last Location</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {vehicles.map((v, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono font-medium text-blue-600">{v.id}</td>
                                <td className="px-6 py-4">{v.type}</td>
                                <td className="px-6 py-4 font-mono font-semibold text-gray-700 bg-gray-100 rounded px-2 w-fit">{v.plate}</td>
                                <td className="px-6 py-4 flex items-center gap-2">
                                    {v.driver !== 'Unassigned' && <User size={14} className="text-gray-400" />}
                                    <span className={v.driver === 'Unassigned' ? 'text-gray-400 italic' : ''}>{v.driver}</span>
                                </td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium 
                                        ${v.status === 'In Transit' ? 'bg-blue-100 text-blue-700' : 
                                          v.status === 'Idle' ? 'bg-yellow-100 text-yellow-700' : 
                                          v.status === 'Maintenance' ? 'bg-red-100 text-red-700' : 
                                          'bg-green-100 text-green-700'}`}>
                                        {v.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-gray-500 flex items-center gap-1">
                                    <MapPin size={14} /> {v.location}
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-gray-400 hover:text-gray-600">
                                        <MoreHorizontal size={20} />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
             </div>
        </div>
    );
};