import React from 'react';
import { Save, RefreshCw, CheckCircle, XCircle, MessageSquare, Globe, Server, Link as LinkIcon, Settings, ShieldCheck } from 'lucide-react';

const IntegrationHeader: React.FC<{ title: string; subtitle: string; icon: React.ReactNode }> = ({ title, subtitle, icon }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div className="flex items-center gap-3">
      <div className="w-12 h-12 bg-white border border-gray-200 rounded-lg flex items-center justify-center shadow-sm">
         {icon}
      </div>
      <div>
        <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
        <p className="text-sm text-gray-500">{subtitle}</p>
      </div>
    </div>
  </div>
);

// 1. Zid Configuration
export const ZidConfiguration: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto pb-10">
      <IntegrationHeader 
        title="Zid Store Integration" 
        subtitle="Connect your Zid merchant account to sync orders and inventory."
        icon={<span className="text-2xl font-bold text-purple-600">Z</span>}
      />

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="font-semibold text-gray-900">Connection Settings</h3>
          <span className="flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
            <CheckCircle size={14} /> Connected
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Manager Token</label>
            <input type="password" value="************************" className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500" readOnly />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Store ID</label>
            <input type="text" value="8829102" className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500" readOnly />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Webhook Secret</label>
            <input type="password" value="************************" className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500" readOnly />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Sync Frequency</label>
            <select className="w-full px-4 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500">
              <option>Real-time (Webhook)</option>
              <option>Every 15 Minutes</option>
              <option>Every Hour</option>
            </select>
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-3 border-t border-gray-100 pt-4">
          <button className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg flex items-center gap-2">
            <RefreshCw size={16} /> Test Connection
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2">
            <Save size={16} /> Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};

// 2. Salla Configuration
export const SallaConfiguration: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto pb-10">
      <IntegrationHeader 
        title="Salla Store Integration" 
        subtitle="Connect your Salla merchant account to manage shipments."
        icon={<span className="text-2xl font-bold text-green-600">S</span>}
      />

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-400">
            <LinkIcon size={32} />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Connect your Salla Store</h3>
        <p className="text-gray-500 max-w-md mx-auto mb-6">
            Authorize LogiMaster to access your Salla store orders and update shipment statuses automatically.
        </p>
        <button className="px-6 py-3 bg-[#b9f237] text-black font-semibold rounded-lg hover:brightness-95 flex items-center gap-2 mx-auto">
            Connect via Salla App Store
        </button>
      </div>
    </div>
  );
};

// 3. CITC Configuration
export const CitcConfiguration: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto pb-10">
      <IntegrationHeader 
        title="CITC Integration" 
        subtitle="Saudi Communication, Space and Technology Commission Reporting."
        icon={<ShieldCheck className="text-blue-600" size={28} />}
      />

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6 p-4 bg-yellow-50 rounded-lg border border-yellow-100">
            <div className="flex items-center gap-3">
                <Server className="text-yellow-600" />
                <div>
                    <h4 className="font-semibold text-yellow-900">Sandbox Environment</h4>
                    <p className="text-xs text-yellow-700">You are currently connected to the CITC testing environment.</p>
                </div>
            </div>
            <div className="flex items-center gap-2">
                <span className="text-sm text-gray-600 font-medium">Switch to Live</span>
                <div className="w-10 h-5 bg-gray-300 rounded-full relative cursor-pointer">
                    <div className="w-5 h-5 bg-white rounded-full shadow absolute left-0"></div>
                </div>
            </div>
        </div>

        <div className="grid grid-cols-1 gap-6">
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">License Number</label>
                <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. 10101010" />
            </div>
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">API Key (Client ID)</label>
                <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg font-mono text-sm" value="citc_test_882910_xx" readOnly />
            </div>
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Client Secret</label>
                <input type="password" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg font-mono text-sm" value="****************" />
            </div>
        </div>

        <div className="mt-8 flex justify-end gap-3">
             <button className="px-4 py-2.5 text-gray-700 hover:bg-gray-100 rounded-lg font-medium">Cancel</button>
             <button className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Update Credentials</button>
        </div>
      </div>
    </div>
  );
};

// 4. SMS Configuration
export const SmsConfiguration: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto pb-10">
      <IntegrationHeader 
        title="SMS Gateway" 
        subtitle="Configure automated SMS notifications for customers."
        icon={<MessageSquare className="text-indigo-600" size={28} />}
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="font-semibold text-gray-900 mb-4">Provider Settings</h3>
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">SMS Provider</label>
                        <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                            <option>Unifonic</option>
                            <option>Twilio</option>
                            <option>4Jawaly</option>
                            <option>Msegat</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Sender ID</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. LOGIMASTER" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">API Key</label>
                        <input type="password" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value="sk_live_..." />
                    </div>
                </div>
            </div>

             <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="font-semibold text-gray-900 mb-4">Notification Templates</h3>
                <div className="space-y-4">
                     <div className="p-3 bg-gray-50 rounded-lg border border-gray-100 cursor-pointer hover:bg-gray-100">
                         <div className="flex justify-between mb-1">
                             <span className="font-medium text-sm">Order Dispatched</span>
                             <span className="text-xs text-green-600">Active</span>
                         </div>
                         <p className="text-xs text-gray-500 truncate">Dear {`{customer_name}`}, your order {`{order_id}`} is now with our courier...</p>
                     </div>
                     <div className="p-3 bg-gray-50 rounded-lg border border-gray-100 cursor-pointer hover:bg-gray-100">
                         <div className="flex justify-between mb-1">
                             <span className="font-medium text-sm">Out for Delivery</span>
                             <span className="text-xs text-green-600">Active</span>
                         </div>
                         <p className="text-xs text-gray-500 truncate">Our captain {`{driver_name}`} is on the way with your order...</p>
                     </div>
                </div>
            </div>
        </div>

        <div className="md:col-span-1">
             <div className="bg-indigo-50 border border-indigo-100 p-5 rounded-xl">
                 <h4 className="font-semibold text-indigo-900 mb-2">SMS Balance</h4>
                 <div className="text-3xl font-bold text-indigo-700 mb-1">2,450</div>
                 <p className="text-xs text-indigo-600 mb-4">Credits remaining</p>
                 <button className="w-full py-2 bg-indigo-600 text-white rounded-lg text-sm hover:bg-indigo-700">Top Up Balance</button>
             </div>
        </div>
      </div>
    </div>
  );
};

// 5. Salla App Config
export const SallaAppConfig: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
             <IntegrationHeader 
                title="Salla App Configuration" 
                subtitle="Manage settings for the installed Salla App."
                icon={<Settings className="text-gray-600" size={28} />}
            />

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="font-semibold text-gray-900 mb-6 pb-2 border-b border-gray-100">Status Mapping</h3>
                <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 items-center">
                        <label className="text-sm font-medium text-gray-600">Salla: "Ready for Shipping"</label>
                        <select className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-gray-50">
                            <option>System: Created</option>
                            <option>System: Pending</option>
                        </select>
                    </div>
                     <div className="grid grid-cols-2 gap-4 items-center">
                        <label className="text-sm font-medium text-gray-600">Salla: "Shipping"</label>
                        <select className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-gray-50">
                            <option>System: Dispatched</option>
                            <option>System: Out for Delivery</option>
                        </select>
                    </div>
                     <div className="grid grid-cols-2 gap-4 items-center">
                        <label className="text-sm font-medium text-gray-600">Salla: "Delivered"</label>
                        <select className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-gray-50">
                            <option>System: Delivered</option>
                        </select>
                    </div>
                </div>
                 <div className="mt-8 flex justify-end">
                    <button className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Save Mapping</button>
                 </div>
            </div>
        </div>
    );
}

// 6. Zid App Config
export const ZidAppConfig: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
             <IntegrationHeader 
                title="Zid App Configuration" 
                subtitle="Manage settings for the installed Zid App."
                icon={<Settings className="text-gray-600" size={28} />}
            />

             <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="font-semibold text-gray-900 mb-6 pb-2 border-b border-gray-100">Advanced Options</h3>
                <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                        <div>
                            <p className="text-sm font-medium text-gray-900">Auto-Import Orders</p>
                            <p className="text-xs text-gray-500">Automatically create orders in LogiMaster when placed in Zid.</p>
                        </div>
                         <div className="w-10 h-5 bg-green-500 rounded-full relative cursor-pointer">
                            <div className="w-5 h-5 bg-white rounded-full shadow absolute right-0"></div>
                        </div>
                    </div>
                     <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                        <div>
                            <p className="text-sm font-medium text-gray-900">Sync Inventory</p>
                            <p className="text-xs text-gray-500">Update Zid stock levels when inventory changes here.</p>
                        </div>
                         <div className="w-10 h-5 bg-gray-300 rounded-full relative cursor-pointer">
                            <div className="w-5 h-5 bg-white rounded-full shadow absolute left-0"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}