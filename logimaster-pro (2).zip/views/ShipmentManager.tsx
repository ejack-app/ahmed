
import React, { useEffect, useState } from 'react';
import { Search, Filter, Download, MoreHorizontal, Loader } from 'lucide-react';
import { Order } from '../types';
import { api } from '../utils/api';

export const ShipmentManager: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('');

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const data = await api.get(`/shipments${filterStatus ? `?status=${filterStatus}` : ''}`);
      // Map Backend DB columns to Frontend Order Interface
      const mappedOrders: Order[] = data.map((item: any) => ({
        id: item.awb_number,
        customer: item.receiver_name,
        date: new Date(item.created_at).toLocaleDateString(),
        status: item.status,
        integration: item.order_ref ? 'API' : 'Manual',
        amount: item.cod_amount,
        city: item.receiver_city
      }));
      setOrders(mappedOrders);
    } catch (error) {
      console.error("Failed to fetch shipments", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, [filterStatus]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Created': return 'bg-blue-100 text-blue-800';
      case 'Dispatched': return 'bg-yellow-100 text-yellow-800';
      case 'Delivered': return 'bg-green-100 text-green-800';
      case 'Returned': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Shipment Management</h2>
          <p className="text-sm text-gray-500">Manage, track, and process your orders.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 flex items-center gap-2">
            <Download size={16} /> Export
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 flex items-center gap-2">
            + New Order
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-4 border-b border-gray-200 bg-gray-50 flex flex-col sm:flex-row gap-4 justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search by AWB, Customer, or Phone..." 
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            />
          </div>
          <div className="flex gap-2">
            <select 
                className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 outline-none"
                onChange={(e) => setFilterStatus(e.target.value)}
            >
                <option value="">All Statuses</option>
                <option value="Created">Created</option>
                <option value="Dispatched">Dispatched</option>
                <option value="Delivered">Delivered</option>
            </select>
            <button 
                onClick={fetchOrders}
                className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50 flex items-center gap-2"
            >
              <Filter size={16} /> Refresh
            </button>
          </div>
        </div>

        {loading ? (
            <div className="p-10 text-center text-gray-500">
                <Loader className="animate-spin mx-auto mb-2" /> Loading Shipments...
            </div>
        ) : (
            <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-gray-600">
                <thead className="bg-gray-50 text-xs uppercase font-semibold text-gray-500">
                <tr>
                    <th className="px-6 py-4">AWB Number</th>
                    <th className="px-6 py-4">Source</th>
                    <th className="px-6 py-4">Customer</th>
                    <th className="px-6 py-4">City</th>
                    <th className="px-6 py-4">COD Amount</th>
                    <th className="px-6 py-4">Date</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                {orders.length > 0 ? orders.map((order) => (
                    <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 font-medium text-blue-600">{order.id}</td>
                    <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded text-xs font-bold ${order.integration === 'API' ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-700'}`}>
                        {order.integration}
                        </span>
                    </td>
                    <td className="px-6 py-4 font-medium text-gray-900">{order.customer}</td>
                    <td className="px-6 py-4">{order.city}</td>
                    <td className="px-6 py-4 font-medium">SAR {order.amount}</td>
                    <td className="px-6 py-4 text-gray-500">{order.date}</td>
                    <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                        {order.status}
                        </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                        <button className="text-gray-400 hover:text-gray-600">
                        <MoreHorizontal size={20} />
                        </button>
                    </td>
                    </tr>
                )) : (
                    <tr>
                        <td colSpan={8} className="px-6 py-8 text-center text-gray-400">
                            No shipments found.
                        </td>
                    </tr>
                )}
                </tbody>
            </table>
            </div>
        )}
        
        <div className="p-4 border-t border-gray-200 flex justify-between items-center bg-gray-50">
          <span className="text-sm text-gray-500">Showing recent 100 orders</span>
          <div className="flex gap-2">
            <button className="px-3 py-1 border border-gray-300 rounded bg-white disabled:opacity-50" disabled>Prev</button>
            <button className="px-3 py-1 border border-gray-300 rounded bg-white disabled:opacity-50" disabled>Next</button>
          </div>
        </div>
      </div>
    </div>
  );
};
