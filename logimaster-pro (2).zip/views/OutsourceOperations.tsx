
import React, { useState, useEffect } from 'react';
import { 
  Briefcase, Plus, Search, Upload, FileText, 
  MoreHorizontal, DollarSign, Calendar, Filter, Loader, Printer,
  CreditCard, Edit
} from 'lucide-react';
import { api } from '../utils/api';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Add Supplier
export const AddSupplier: React.FC = () => {
    const [formData, setFormData] = useState({ name: '', phone: '', city: '', rate: '', contract_date: '' });

    const handleSubmit = async () => {
        try {
            await api.post('/suppliers', formData);
            alert('Supplier Added Successfully');
            setFormData({ name: '', phone: '', city: '', rate: '', contract_date: '' });
        } catch (e: any) {
            alert(e.message);
        }
    };

    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Add Supplier" description="Register a new outsourced logistics provider." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Supplier Name</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                    </div>
                    
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">City</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value={formData.city} onChange={e => setFormData({...formData, city: e.target.value})} />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone Number</label>
                        <input type="tel" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Rate per Delivery (SAR)</label>
                        <input type="number" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value={formData.rate} onChange={e => setFormData({...formData, rate: e.target.value})} />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Contract Date</label>
                        <input type="date" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value={formData.contract_date} onChange={e => setFormData({...formData, contract_date: e.target.value})} />
                    </div>
                </div>

                <div className="mt-8 flex justify-end gap-3">
                    <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2" onClick={handleSubmit}>
                        <Plus size={18} /> Register Supplier
                    </button>
                </div>
            </div>
        </div>
    );
};

// 2. Supplier List
export const SupplierList: React.FC = () => {
    const [suppliers, setSuppliers] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchSuppliers = async () => {
            try {
                const data = await api.get('/suppliers');
                setSuppliers(data);
            } catch(e) { console.error(e); } 
            finally { setLoading(false); }
        };
        fetchSuppliers();
    }, []);

    return (
        <div>
            <Header 
                title="Suppliers" 
                description="Manage external delivery partners." 
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700 font-medium">
                        <Plus size={16} /> Add Supplier
                    </button>
                }
            />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">#</th>
                            <th className="px-6 py-4">Supplier Name</th>
                            <th className="px-6 py-4">Phone</th>
                            <th className="px-6 py-4">City</th>
                            <th className="px-6 py-4">Rate (SAR)</th>
                            <th className="px-6 py-4">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {loading ? (
                            <tr><td colSpan={6} className="text-center p-6"><Loader className="animate-spin mx-auto"/></td></tr>
                        ) : suppliers.length === 0 ? (
                            <tr><td colSpan={6} className="text-center p-6 text-gray-400">No suppliers registered.</td></tr>
                        ) : (
                            suppliers.map((s, i) => (
                                <tr key={i} className="hover:bg-gray-50">
                                    <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                    <td className="px-6 py-4 font-medium text-gray-900">{s.name}</td>
                                    <td className="px-6 py-4">{s.phone}</td>
                                    <td className="px-6 py-4">{s.city}</td>
                                    <td className="px-6 py-4">{s.rate}</td>
                                    <td className="px-6 py-4"><button className="text-blue-600">Edit</button></td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 3. Generate Invoice
export const GenerateOutsourceInvoice: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Generate Supplier Invoice" description="Create payment statements for 3PL partners." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Select Supplier</label>
                        <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                            <option>SMSA Express</option>
                            <option>Aramex</option>
                            <option>J&T Express</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Date Range</label>
                        <div className="flex gap-2">
                            <input type="date" className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" />
                            <input type="date" className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" />
                        </div>
                    </div>
                    <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center justify-center gap-2">
                        <FileText size={18} /> Generate Bill
                    </button>
                </div>
            </div>

            {/* Preview Section (Mock) */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
                <div className="mb-4 text-gray-300">
                    <Printer size={48} className="mx-auto" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">Invoice Preview</h3>
                <p className="text-gray-500 text-sm">Select a supplier and date range to view calculated totals.</p>
            </div>
        </div>
    );
};

// 4. Outsource Payment Info
export const OutsourcePaymentInfo: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Supplier Banking Details" description="Manage payment information for external providers." />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {['SMSA Express', 'Aramex', 'J&T Express'].map((supplier, i) => (
                    <div key={i} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                        <div className="flex justify-between items-start mb-4">
                            <h3 className="font-bold text-gray-900">{supplier}</h3>
                            <button className="text-gray-400 hover:text-blue-600"><Edit size={16} /></button>
                        </div>
                        
                        <div className="space-y-3 text-sm">
                            <div className="flex justify-between border-b border-gray-50 pb-2">
                                <span className="text-gray-500">Bank Name</span>
                                <span className="font-medium">Al Rajhi Bank</span>
                            </div>
                            <div className="flex justify-between border-b border-gray-50 pb-2">
                                <span className="text-gray-500">Account Name</span>
                                <span className="font-medium">{supplier} Ltd.</span>
                            </div>
                            <div className="flex justify-between border-b border-gray-50 pb-2">
                                <span className="text-gray-500">IBAN</span>
                                <span className="font-mono text-gray-700">SA00000000000000000000</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-gray-500">Swift Code</span>
                                <span className="font-mono text-gray-700">RJHI000</span>
                            </div>
                        </div>
                    </div>
                ))}
                
                {/* Add New Card */}
                <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-gray-50 transition-colors">
                    <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center mb-3 text-gray-500">
                        <Plus size={24} />
                    </div>
                    <h3 className="font-medium text-gray-900">Add Payment Info</h3>
                    <p className="text-xs text-gray-500 mt-1">Link bank details to a supplier</p>
                </div>
            </div>
        </div>
    );
};
