
import React, { useState, useEffect } from 'react';
import { MapPin, Upload, Globe, Building, Plus, Search, Loader, Trash2 } from 'lucide-react';
import { api } from '../utils/api';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Location List (Cities & Countries)
export const LocationList: React.FC = () => {
    const [locations, setLocations] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchLocations = async () => {
            try {
                const data = await api.get('/locations');
                setLocations(data);
            } catch (e) { console.error(e); }
            finally { setLoading(false); }
        };
        fetchLocations();
    }, []);

    return (
        <div>
            <Header title="Master Location List" description="All registered countries, cities, and zones." />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search City or Country..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">ID</th>
                            <th className="px-6 py-4">City Name</th>
                            <th className="px-6 py-4">Country</th>
                            <th className="px-6 py-4">Zone Code</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {loading ? (
                            <tr><td colSpan={5} className="p-6 text-center"><Loader className="animate-spin mx-auto"/></td></tr>
                        ) : locations.length === 0 ? (
                            <tr><td colSpan={5} className="p-6 text-center text-gray-400">No locations found.</td></tr>
                        ) : (
                            locations.map((loc, i) => (
                                <tr key={i} className="hover:bg-gray-50">
                                    <td className="px-6 py-4 text-gray-400">{loc.id}</td>
                                    <td className="px-6 py-4 font-medium text-gray-900">{loc.city_name}</td>
                                    <td className="px-6 py-4 flex items-center gap-2">
                                        <Globe size={14} className="text-gray-400" /> {loc.country_name}
                                    </td>
                                    <td className="px-6 py-4"><span className="bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs font-mono">{loc.zone_code}</span></td>
                                    <td className="px-6 py-4 text-right">
                                        <button className="text-red-400 hover:text-red-600"><Trash2 size={16}/></button>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export const ImportLocation: React.FC = () => {
    return (
        <div className="max-w-2xl mx-auto pb-10">
            <Header title="Import Locations" description="Bulk import master location data." />
            <div className="bg-white p-10 rounded-xl shadow-sm border border-dashed border-gray-300 flex flex-col items-center justify-center text-center">
                 <MapPin size={48} className="text-gray-300 mb-4" />
                 <h3 className="text-lg font-medium text-gray-900 mb-2">Upload Location CSV</h3>
                 <p className="text-sm text-gray-500 mb-6">Format: City, Country Code, Zone</p>
                 <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Select File</button>
            </div>
        </div>
    );
};

export const ImportDeliveryCity: React.FC = () => (
    <div className="max-w-2xl mx-auto pb-10">
        <Header title="Import Delivery Cities" description="Upload list of serviceable cities for couriers." />
        <div className="bg-white p-10 rounded-xl shadow-sm border border-dashed border-gray-300 flex flex-col items-center justify-center text-center">
                <Building size={48} className="text-gray-300 mb-4" />
                <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Upload Cities</button>
        </div>
    </div>
);

export const DeliveryCompanyList: React.FC = () => (
    <div>
        <Header title="Delivery Company List" description="List of connected delivery partners." />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {['SMSA', 'Aramex', 'J&T'].map(c => (
                <div key={c} className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                    <h3 className="font-bold text-lg">{c}</h3>
                    <p className="text-sm text-green-600">Active</p>
                </div>
            ))}
        </div>
    </div>
);

export const AddCountry: React.FC = () => (
    <div className="max-w-2xl mx-auto pb-10">
        <Header title="Add Country" description="Register a new country." />
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Country Name</label>
            <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg mb-4" placeholder="e.g. Bahrain" />
            <label className="block text-sm font-medium text-gray-700 mb-1.5">ISO Code</label>
            <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg mb-6" placeholder="e.g. BH" />
            <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg font-medium">Save Country</button>
        </div>
    </div>
);

export const AddFromMaster: React.FC = () => {
    const [city, setCity] = useState('');
    const [countryId, setCountryId] = useState('1');
    const [zone, setZone] = useState('A');

    const handleAdd = async () => {
        try {
            await api.post('/cities', { name: city, country_id: countryId, zone_code: zone });
            alert('City Added Successfully');
            setCity('');
        } catch(e: any) {
            alert(e.message);
        }
    };

    return (
        <div className="max-w-2xl mx-auto pb-10">
            <Header title="Add City (Master)" description="Manually register a city to the database." />
            <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Country</label>
                    <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value={countryId} onChange={e => setCountryId(e.target.value)}>
                        <option value="1">Saudi Arabia</option>
                        <option value="2">UAE</option>
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">City Name</label>
                    <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value={city} onChange={e => setCity(e.target.value)} />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Pricing Zone</label>
                    <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value={zone} onChange={e => setZone(e.target.value)} />
                </div>
                <div className="pt-4">
                    <button onClick={handleAdd} className="w-full px-6 py-2.5 bg-blue-600 text-white rounded-lg font-medium flex items-center justify-center gap-2">
                        <Plus size={18} /> Add City
                    </button>
                </div>
            </div>
        </div>
    );
};
