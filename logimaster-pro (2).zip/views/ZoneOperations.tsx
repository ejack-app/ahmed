import React, { useState } from 'react';
import { 
  Globe, Plus, Search, Filter, Edit, Trash2, Check, X, Map
} from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Add Zone List
export const AddZoneList: React.FC = () => {
    const [zoneName, setZoneName] = useState('');
    const [editingId, setEditingId] = useState<number | null>(null);

    // Mock Data
    const [zones, setZones] = useState([
        { id: 1, name: 'Zone A (Central)', status: 'Active' },
        { id: 2, name: 'Zone B (West)', status: 'Active' },
        { id: 3, name: 'Zone C (East)', status: 'Inactive' },
        { id: 4, name: 'Zone D (North)', status: 'Active' },
    ]);

    const handleSave = () => {
        if (zoneName.trim() === '') return;
        if (editingId) {
            setZones(zones.map(z => z.id === editingId ? { ...z, name: zoneName } : z));
            setEditingId(null);
        } else {
            setZones([...zones, { id: Date.now(), name: zoneName, status: 'Active' }]);
        }
        setZoneName('');
    };

    const handleEdit = (zone: { id: number; name: string }) => {
        setZoneName(zone.name);
        setEditingId(zone.id);
    };

    const handleDelete = (id: number) => {
        if (confirm('Are you sure you want to delete this zone?')) {
            setZones(zones.filter(z => z.id !== id));
        }
    };

    const toggleStatus = (id: number) => {
        setZones(zones.map(z => z.id === id ? { ...z, status: z.status === 'Active' ? 'Inactive' : 'Active' } : z));
    };

    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Manage Zones" description="Create and manage delivery zones." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                <div className="flex gap-4 items-end">
                    <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">{editingId ? 'Edit Zone' : 'Add New Zone'}</label>
                        <input 
                            type="text" 
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500" 
                            placeholder="Enter Zone Name" 
                            value={zoneName}
                            onChange={(e) => setZoneName(e.target.value)}
                        />
                    </div>
                    <button 
                        onClick={handleSave}
                        className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2"
                    >
                        {editingId ? <Check size={18} /> : <Plus size={18} />}
                        {editingId ? 'Update' : 'Add'}
                    </button>
                    {editingId && (
                        <button 
                            onClick={() => { setEditingId(null); setZoneName(''); }}
                            className="px-4 py-2.5 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200"
                        >
                            Cancel
                        </button>
                    )}
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">#</th>
                            <th className="px-6 py-4">Zone Name</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {zones.map((zone, index) => (
                            <tr key={zone.id} className="hover:bg-gray-50">
                                <td className="px-6 py-4 text-gray-400">{index + 1}</td>
                                <td className="px-6 py-4 font-medium text-gray-900">{zone.name}</td>
                                <td className="px-6 py-4">
                                    <span 
                                        onClick={() => toggleStatus(zone.id)}
                                        className={`cursor-pointer px-2 py-1 rounded-full text-xs font-bold 
                                        ${zone.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}
                                    >
                                        {zone.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <div className="flex justify-end gap-2">
                                        <button onClick={() => handleEdit(zone)} className="p-1 text-gray-400 hover:text-blue-600" title="Edit">
                                            <Edit size={16} />
                                        </button>
                                        <button onClick={() => handleDelete(zone.id)} className="p-1 text-gray-400 hover:text-red-600" title="Delete">
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 2. Set City Zone
export const SetCityZone: React.FC = () => {
    // Mock Data
    const cities = [
        { id: 1, name: 'Riyadh', zone: 'Zone A (Central)' },
        { id: 2, name: 'Jeddah', zone: 'Zone B (West)' },
        { id: 3, name: 'Dammam', zone: 'Zone C (East)' },
        { id: 4, name: 'Mecca', zone: 'Zone B (West)' },
        { id: 5, name: 'Medina', zone: 'Zone B (West)' },
        { id: 6, name: 'Abha', zone: 'Zone D (South)' },
    ];

    const alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split('');

    return (
        <div className="max-w-6xl mx-auto pb-10">
            <Header title="Set Default City Zone" description="Assign default zones to cities for automatic rate calculation." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                
                {/* Alphabet Filter */}
                <div className="flex flex-wrap justify-center gap-2 mb-6 text-sm text-blue-600 font-medium">
                    {alphabets.map(char => (
                        <button key={char} className="hover:text-blue-800 px-1">{char} |</button>
                    ))}
                </div>

                <div className="flex flex-col md:flex-row gap-4 items-end border-t border-gray-100 pt-6">
                    <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Search Country</label>
                        <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg bg-white">
                            <option>Saudi Arabia</option>
                            <option>UAE</option>
                        </select>
                    </div>
                    <div className="flex-[2]">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Search City</label>
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                            <input type="text" className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg outline-none" placeholder="Search city..." />
                        </div>
                    </div>
                    <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
                        Search
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {cities.map((city) => (
                    <div key={city.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-200 flex items-center justify-between">
                        <span className="font-medium text-gray-800">{city.name}</span>
                        <select 
                            className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm bg-gray-50 max-w-[150px]"
                            defaultValue={city.zone}
                        >
                            <option>Select Zone</option>
                            <option>Zone A (Central)</option>
                            <option>Zone B (West)</option>
                            <option>Zone C (East)</option>
                            <option>Zone D (South)</option>
                        </select>
                    </div>
                ))}
            </div>
        </div>
    );
};

// 3. Set Country Zone
export const SetCountryZone: React.FC = () => {
    // Mock Data
    const countries = [
        { id: 1, name: 'Saudi Arabia', zone: 'Zone A' },
        { id: 2, name: 'United Arab Emirates', zone: 'Zone B' },
        { id: 3, name: 'Bahrain', zone: 'Zone B' },
        { id: 4, name: 'Kuwait', zone: 'Zone C' },
        { id: 5, name: 'Oman', zone: 'Zone C' },
    ];

    const alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split('');

    return (
        <div className="max-w-6xl mx-auto pb-10">
            <Header title="Set Default Country Zone" description="Assign default zones to countries." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                
                {/* Alphabet Filter */}
                <div className="flex flex-wrap justify-center gap-2 mb-6 text-sm text-blue-600 font-medium">
                    {alphabets.map(char => (
                        <button key={char} className="hover:text-blue-800 px-1">{char} |</button>
                    ))}
                </div>

                <div className="flex flex-col md:flex-row gap-4 items-end border-t border-gray-100 pt-6">
                    <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Search Country</label>
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                            <input type="text" className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg outline-none" placeholder="Search country..." />
                        </div>
                    </div>
                    <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
                        Search
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {countries.map((country) => (
                    <div key={country.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-200 flex items-center justify-between">
                        <span className="font-medium text-gray-800 flex items-center gap-2">
                            <Globe size={16} className="text-gray-400" />
                            {country.name}
                        </span>
                        <select 
                            className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm bg-gray-50 max-w-[150px]"
                            defaultValue={country.zone}
                        >
                            <option>Select Zone</option>
                            <option>Zone A</option>
                            <option>Zone B</option>
                            <option>Zone C</option>
                        </select>
                    </div>
                ))}
            </div>
        </div>
    );
};