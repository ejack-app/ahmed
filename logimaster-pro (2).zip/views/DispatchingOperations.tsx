
import React, { useState } from 'react';
import { Send, Truck, CheckCircle, Search, Box, XCircle } from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Dispatching
export const DispatchingView: React.FC = () => {
    const [scannedItems, setScannedItems] = useState<string[]>([]);
    const [input, setInput] = useState('');

    const handleScan = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter' && input.trim()) {
            if (!scannedItems.includes(input)) {
                setScannedItems(prev => [...prev, input]);
            }
            setInput('');
        }
    };

    const handleRemove = (awb: string) => {
        setScannedItems(prev => prev.filter(item => item !== awb));
    };

    return (
        <div className="max-w-5xl mx-auto pb-10">
            <Header title="Dispatching (Handover)" description="Scan parcels to handover to courier drivers." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                <div className="flex flex-col md:flex-row gap-4 items-end">
                    <div className="flex-1 w-full">
                         <label className="block text-sm font-medium text-gray-700 mb-1.5">Select Courier / Driver</label>
                         <select className="w-full px-4 py-3 border border-gray-300 rounded-lg">
                             <option>SMSA Express</option>
                             <option>Aramex</option>
                             <option>Driver: Ahmed Ali (Internal)</option>
                         </select>
                    </div>
                     <div className="flex-[2] w-full">
                         <label className="block text-sm font-medium text-gray-700 mb-1.5">Scan AWB / Tracking No.</label>
                         <input 
                            type="text" 
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg font-mono focus:ring-2 focus:ring-blue-500 outline-none" 
                            placeholder="Scan here..." 
                            autoFocus 
                            value={input}
                            onChange={e => setInput(e.target.value)}
                            onKeyDown={handleScan}
                         />
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
                    <h3 className="font-semibold text-gray-800">Scanned in this session: {scannedItems.length}</h3>
                    {scannedItems.length > 0 && (
                        <button onClick={() => setScannedItems([])} className="text-sm text-red-600 hover:underline">Clear List</button>
                    )}
                </div>
                
                {scannedItems.length === 0 ? (
                    <div className="p-10 text-center text-gray-400">
                        <Truck size={48} className="mx-auto mb-3 opacity-30" />
                        <p>No parcels scanned yet.</p>
                    </div>
                ) : (
                    <div className="max-h-96 overflow-y-auto">
                        <table className="w-full text-left text-sm text-gray-600">
                            <thead className="bg-white border-b sticky top-0">
                                <tr>
                                    <th className="px-6 py-3">AWB No.</th>
                                    <th className="px-6 py-3">Status</th>
                                    <th className="px-6 py-3 text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                                {scannedItems.map((awb, i) => (
                                    <tr key={i} className="hover:bg-gray-50">
                                        <td className="px-6 py-3 font-mono text-blue-600 font-medium">{awb}</td>
                                        <td className="px-6 py-3 text-green-600 flex items-center gap-1"><CheckCircle size={14}/> Ready to Dispatch</td>
                                        <td className="px-6 py-3 text-right">
                                            <button onClick={() => handleRemove(awb)} className="text-red-400 hover:text-red-600"><XCircle size={18}/></button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}

                <div className="p-4 border-t border-gray-200 bg-gray-50 flex justify-end">
                     <button 
                        disabled={scannedItems.length === 0}
                        className="px-6 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                        onClick={() => { alert('Handover Manifest Generated!'); setScannedItems([]); }}
                     >
                         <CheckCircle size={18} /> Complete Handover
                     </button>
                </div>
            </div>
        </div>
    );
};

// 2. Dispatching (BETA)
export const DispatchingBetaView: React.FC = () => {
     return (
        <div>
            <Header title="Smart Dispatch (Beta)" description="Enhanced dispatching with real-time route validation." action={<span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-xs font-bold uppercase">Beta</span>} />
            <DispatchingView />
        </div>
    );
};

// 3. Dispatch To Delivered
export const DispatchToDeliveredView: React.FC = () => {
    return (
        <div className="max-w-3xl mx-auto pb-10">
            <Header title="Mark as Delivered" description="Update order status to 'Delivered' (Internal Fleet)." />
             
             <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200 text-center">
                 <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                     <CheckCircle size={32} />
                 </div>
                 <h3 className="text-xl font-bold text-gray-900 mb-2">Scan to Confirm Delivery</h3>
                 <p className="text-gray-500 mb-6">Scan the parcel label to instantly mark it as successfully delivered.</p>
                 
                 <input type="text" className="w-full max-w-md mx-auto px-4 py-3 border-2 border-green-500 rounded-lg font-mono text-center text-lg focus:outline-none" placeholder="Scan AWB..." autoFocus />
             </div>
        </div>
    );
};
