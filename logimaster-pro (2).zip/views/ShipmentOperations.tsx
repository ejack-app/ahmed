
import React, { useState, useEffect } from 'react';
import { 
  Search, Filter, Send, Download, Printer, Trash2, Calendar, 
  ArrowRight, RefreshCcw, FilePlus, Settings, AlertTriangle, Loader, CheckCircle, XCircle 
} from 'lucide-react';
import { Order } from '../types';
import { api } from '../utils/api';

// Reusable Components
const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

const SearchBar: React.FC<{ onSearch: (val: string) => void }> = ({ onSearch }) => (
    <div className="relative flex-1 max-w-md">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
        <input 
            type="text" 
            onChange={(e) => onSearch(e.target.value)}
            placeholder="Search Order ID, Name, or Phone..." 
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
        />
    </div>
);

const OrdersTable: React.FC<{ 
    data: Order[], 
    loading?: boolean, 
    showSelection?: boolean, 
    actions?: (order: Order) => React.ReactNode 
}> = ({ data, loading, showSelection = true, actions }) => (
  <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
    <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
        <div className="text-sm text-gray-500">{data.length} Records Found</div>
        <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50 flex items-center gap-2">
            <Filter size={16} /> Filter
        </button>
    </div>
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm text-gray-600">
        <thead className="bg-gray-50 text-xs uppercase font-semibold text-gray-500">
          <tr>
            {showSelection && <th className="px-6 py-4 w-10"><input type="checkbox" /></th>}
            <th className="px-6 py-4">Order ID</th>
            <th className="px-6 py-4">Customer</th>
            <th className="px-6 py-4">City</th>
            <th className="px-6 py-4">Date</th>
            <th className="px-6 py-4">Status</th>
            <th className="px-6 py-4">Amount</th>
            {actions && <th className="px-6 py-4 text-right">Actions</th>}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {loading ? (
              <tr><td colSpan={7} className="px-6 py-10 text-center"><Loader className="animate-spin mx-auto text-blue-600"/></td></tr>
          ) : data.length === 0 ? (
              <tr><td colSpan={7} className="px-6 py-10 text-center text-gray-400">No orders found.</td></tr>
          ) : (
              data.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50">
                  {showSelection && <td className="px-6 py-4"><input type="checkbox" /></td>}
                  <td className="px-6 py-4 font-medium text-blue-600">{order.id}</td>
                  <td className="px-6 py-4">{order.customer}</td>
                  <td className="px-6 py-4">{order.city}</td>
                  <td className="px-6 py-4 text-gray-500">{order.date}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded text-xs border ${
                        order.status === 'Created' ? 'bg-blue-50 text-blue-700 border-blue-200' : 
                        order.status === 'Dispatched' ? 'bg-yellow-50 text-yellow-700 border-yellow-200' :
                        order.status === 'Returned' ? 'bg-red-50 text-red-700 border-red-200' :
                        order.status === 'Deleted' ? 'bg-gray-100 text-gray-500 border-gray-300' :
                        'bg-gray-50 text-gray-700 border-gray-200'
                    }`}>
                        {order.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 font-medium">SAR {order.amount}</td>
                  {actions && <td className="px-6 py-4 text-right">{actions(order)}</td>}
                </tr>
              ))
          )}
        </tbody>
      </table>
    </div>
  </div>
);

// --- MOCK DATA ---
const mockReverseOrders: Order[] = [
    { id: 'RET-8821', customer: 'Mona Ahmed', date: '2024-02-25', status: 'Returned', city: 'Riyadh', amount: 150, integration: 'Manual' },
    { id: 'RET-8822', customer: 'Khalid O.', date: '2024-02-24', status: 'Returned', city: 'Jeddah', amount: 200, integration: 'API' },
];

const mockDeleted: Order[] = [
    { id: 'DEL-001', customer: 'Test User', date: '2024-01-01', status: 'Deleted', city: 'Riyadh', amount: 0, integration: 'Manual' },
    { id: 'DEL-002', customer: 'Fake Entry', date: '2024-01-02', status: 'Deleted', city: 'Dammam', amount: 0, integration: 'Manual' },
];

const mockCancelled: Order[] = [
    { id: 'ORD-9910', customer: 'Sarah Connor', date: '2024-02-28', status: 'Cancelled', city: 'Dammam', amount: 350, integration: 'API' },
    { id: 'ORD-9911', customer: 'John Wick', date: '2024-02-27', status: 'Cancelled', city: 'Riyadh', amount: 1000, integration: 'API' },
];

const mockSallaPending: Order[] = [
    { id: 'SALLA-1029', customer: 'Store Customer 1', date: 'Today', status: 'Pending', city: 'Mecca', amount: 120, integration: 'Salla' },
    { id: 'SALLA-1030', customer: 'Store Customer 2', date: 'Today', status: 'Pending', city: 'Medina', amount: 450, integration: 'Salla' },
];

const mockZidList: Order[] = [
    { id: 'ZID-5501', customer: 'Online Buyer A', date: 'Yesterday', status: 'Processing', city: 'Riyadh', amount: 99, integration: 'Zid' },
    { id: 'ZID-5502', customer: 'Online Buyer B', date: 'Yesterday', status: 'Ready', city: 'Tabuk', amount: 200, integration: 'Zid' },
];

// --- VIEWS ---

export const BulkForward3PL: React.FC = () => {
    const [orders, setOrders] = useState<Order[]>([]);
    const [loading, setLoading] = useState(true);
    const [courier, setCourier] = useState('');

    const fetchOrders = async () => {
        setLoading(true);
        try {
            const data = await api.get('/shipments?status=Created');
            setOrders(data.map((d:any) => ({
                id: d.awb_number,
                customer: d.receiver_name,
                date: new Date(d.created_at).toLocaleDateString(),
                status: d.status,
                city: d.receiver_city,
                amount: d.cod_amount,
                integration: 'Manual'
            })));
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { fetchOrders(); }, []);

    const handleForward = async () => {
        if(!courier) return alert("Select a courier first");
        alert(`Forwarding orders to ${courier}... (Simulation)`);
    }

    return (
        <div>
            <Header 
                title="Bulk Forward - 3PL" 
                description="Select multiple orders to forward to third-party logistics partners."
                action={
                    <button onClick={handleForward} className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Send size={16} /> Forward Selected
                    </button>
                }
            />
            <div className="mb-4 flex flex-col md:flex-row gap-4 items-end bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
                <div className="flex-1 w-full">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Select 3PL Provider</label>
                    <select 
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                        onChange={(e) => setCourier(e.target.value)}
                    >
                        <option value="">Select Provider...</option>
                        <option value="smsa">SMSA Express</option>
                        <option value="aramex">Aramex</option>
                        <option value="jt">J&T Express</option>
                    </select>
                </div>
                <div className="flex-1 w-full">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Service Level</label>
                    <select className="w-full px-4 py-2 border border-gray-300 rounded-lg">
                        <option>Standard Delivery</option>
                        <option>Express</option>
                    </select>
                </div>
                <div className="flex-1 w-full">
                     <SearchBar onSearch={(v) => console.log(v)} />
                </div>
            </div>
            <OrdersTable data={orders} loading={loading} />
        </div>
    );
};

export const ManualForward3PL: React.FC = () => {
    const [awb, setAwb] = useState('');
    const [courier, setCourier] = useState('');
    const [loading, setLoading] = useState(false);

    const handleSubmit = async () => {
        if (!awb || !courier) return;
        setLoading(true);
        try {
            await api.post('/shipments/forward-3pl', { awb_number: awb, courier_id: courier });
            alert('Order Forwarded Successfully');
            setAwb('');
        } catch (error: any) {
            alert(error.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="max-w-2xl mx-auto">
             <Header title="Manual Forward - 3PL" description="Manually assign a specific order to a courier." />
             <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Order ID / Tracking Number</label>
                    <div className="flex gap-2">
                        <input 
                            type="text" 
                            placeholder="Enter AWB..." 
                            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg"
                            value={awb}
                            onChange={(e) => setAwb(e.target.value)}
                        />
                    </div>
                </div>
                <div className="pt-4 border-t border-gray-100">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Assign to Courier</label>
                    <select 
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg mb-4"
                        onChange={(e) => setCourier(e.target.value)}
                    >
                        <option value="">Select Courier...</option>
                        <option value="1">SMSA Express</option>
                        <option value="2">Aramex</option>
                    </select>
                    <button 
                        onClick={handleSubmit}
                        disabled={loading}
                        className="w-full py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50"
                    >
                        {loading ? 'Processing...' : 'Forward Order'}
                    </button>
                </div>
             </div>
        </div>
    );
};

export const ReverseOrders: React.FC = () => {
    return (
        <div>
            <Header 
                title="Reverse Logistics" 
                description="Manage returned shipments and reverse pickups."
                action={
                     <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg flex items-center gap-2 hover:bg-gray-50">
                        <Download size={16} /> Export Report
                    </button>
                }
            />
            <OrdersTable data={mockReverseOrders} />
        </div>
    );
};

export const CreateReverseOrder: React.FC = () => {
    return (
         <div className="max-w-3xl mx-auto">
             <Header title="Create Reverse Order" description="Initiate a return request for a customer." />
             <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 space-y-6">
                <div className="grid grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Original Order ID</label>
                        <input type="text" className="w-full px-4 py-2 border border-gray-300 rounded-lg" />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Customer Phone</label>
                        <input type="text" className="w-full px-4 py-2 border border-gray-300 rounded-lg" />
                    </div>
                </div>
                <div>
                     <label className="block text-sm font-medium text-gray-700 mb-1">Pickup Address</label>
                     <textarea rows={3} className="w-full px-4 py-2 border border-gray-300 rounded-lg" placeholder="Full address details..."></textarea>
                </div>
                <div>
                     <label className="block text-sm font-medium text-gray-700 mb-1">Reason for Return</label>
                     <select className="w-full px-4 py-2 border border-gray-300 rounded-lg">
                         <option>Damaged Item</option>
                         <option>Wrong Item Sent</option>
                         <option>Customer Changed Mind</option>
                     </select>
                </div>
                <div className="flex justify-end gap-3 pt-4">
                    <button className="px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-lg">Cancel</button>
                    <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Create Return Label</button>
                </div>
             </div>
        </div>
    );
};

export const CancelOrders3PL: React.FC = () => {
    return (
         <div className="max-w-2xl mx-auto">
             <Header title="Cancel 3PL Orders" description="Cancel shipment requests sent to 3PL providers." />
             <div className="bg-red-50 border border-red-200 p-4 rounded-lg flex items-center gap-3 mb-6">
                 <AlertTriangle className="text-red-600" />
                 <p className="text-sm text-red-800">Warning: Cancellation is only possible before the courier picks up the item.</p>
             </div>
             <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <label className="block text-sm font-medium text-gray-700 mb-1">Airway Bill (AWB) Numbers</label>
                <textarea rows={5} className="w-full px-4 py-2 border border-gray-300 rounded-lg font-mono text-sm" placeholder="Paste AWB numbers here, one per line..."></textarea>
                <button className="w-full mt-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium">
                    Cancel Shipments
                </button>
             </div>
        </div>
    );
};

export const BulkPrint: React.FC = () => {
    return (
        <div>
            <Header 
                title="Bulk Print" 
                description="Print shipping labels, invoices, and manifests in bulk."
                action={
                     <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Printer size={16} /> Print Selected
                    </button>
                }
            />
            <div className="flex gap-4 mb-6">
                <button className="flex-1 py-3 border-2 border-blue-600 bg-blue-50 text-blue-700 rounded-xl font-semibold text-center">AWB Labels</button>
                <button className="flex-1 py-3 border border-gray-200 bg-white text-gray-600 rounded-xl font-medium text-center hover:bg-gray-50">Invoices</button>
                <button className="flex-1 py-3 border border-gray-200 bg-white text-gray-600 rounded-xl font-medium text-center hover:bg-gray-50">Manifest Lists</button>
            </div>
            <OrdersTable data={[]} />
        </div>
    );
};

export const ForwardRemove: React.FC = () => {
    return (
        <div className="max-w-2xl mx-auto">
             <Header title="Remove Forwarding" description="Unassign orders from 3PL and bring them back to internal processing." />
             <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <label className="block text-sm font-medium text-gray-700 mb-1">Scan / Enter Order IDs</label>
                <textarea rows={5} className="w-full px-4 py-2 border border-gray-300 rounded-lg font-mono text-sm" placeholder="Enter Order IDs..."></textarea>
                <button className="w-full mt-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 font-medium flex justify-center items-center gap-2">
                    <RefreshCcw size={18} /> Revert Status to Packed
                </button>
             </div>
        </div>
    );
};

export const DeletedOrders: React.FC = () => {
    return (
        <div>
            <Header title="Deleted Orders" description="Archive of deleted orders." />
            <OrdersTable data={mockDeleted} /> 
        </div>
    );
};

export const CancelledOrders: React.FC = () => {
     return (
        <div>
            <Header title="Cancelled Orders" description="List of orders cancelled by system or customer." />
            <OrdersTable data={mockCancelled} /> 
        </div>
    );
};

export const SallaPendingOrders: React.FC = () => {
    return (
        <div>
             <Header title="Salla Pending Orders" description="Orders from Salla that need attention before syncing." />
             <OrdersTable data={mockSallaPending} />
        </div>
    );
};

export const ShipmentMapping: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto">
            <Header title="Shipment Service Mapping" description="Map your store shipping methods to LogiMaster courier services." />
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm">
                    <thead className="bg-gray-50 border-b border-gray-200">
                        <tr>
                            <th className="px-6 py-4 font-semibold text-gray-700">Store Shipping Name</th>
                            <th className="px-6 py-4 font-semibold text-gray-700">LogiMaster Courier Service</th>
                            <th className="px-6 py-4 font-semibold text-gray-700">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        <tr>
                            <td className="px-6 py-4">Fast Shipping (SAR 25)</td>
                            <td className="px-6 py-4">
                                <select className="w-full border border-gray-300 rounded px-2 py-1">
                                    <option>LogiMaster Express</option>
                                    <option>SMSA Standard</option>
                                </select>
                            </td>
                            <td className="px-6 py-4"><button className="text-blue-600 font-medium">Save</button></td>
                        </tr>
                         <tr>
                            <td className="px-6 py-4">Free Delivery</td>
                            <td className="px-6 py-4">
                                <select className="w-full border border-gray-300 rounded px-2 py-1">
                                    <option>LogiMaster Economy</option>
                                </select>
                            </td>
                            <td className="px-6 py-4"><button className="text-blue-600 font-medium">Save</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export const ZidOrderListing: React.FC = () => {
     return (
        <div>
             <Header title="Zid Orders" description="Raw view of orders fetched from Zid API." />
             <OrdersTable data={mockZidList} />
        </div>
    );
};

export const BulkOrderCreate: React.FC = () => {
    return (
        <div className="max-w-3xl mx-auto">
             <Header title="Bulk Order Create (Beta)" description="Upload a CSV file to create multiple orders at once." />
             <div className="bg-white p-10 rounded-xl shadow-sm border border-dashed border-gray-300 flex flex-col items-center justify-center text-center">
                 <FilePlus size={48} className="text-gray-300 mb-4" />
                 <h3 className="text-lg font-medium text-gray-900 mb-2">Drag and drop your CSV file here</h3>
                 <p className="text-sm text-gray-500 mb-6">Supported columns: Customer Name, Phone, City, Address, Amount, Items</p>
                 <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                     Browse Files
                 </button>
                 <button className="mt-4 text-sm text-blue-600 hover:underline">Download Template</button>
             </div>
        </div>
    );
};

export const BulkUpdateDate: React.FC = () => {
    return (
        <div className="max-w-2xl mx-auto">
             <Header title="Bulk Update Date" description="Change the scheduled date for multiple orders." />
             <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                 <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">New Date</label>
                    <div className="relative">
                        <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="date" className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg" />
                    </div>
                 </div>
                 <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Order IDs</label>
                    <textarea rows={5} className="w-full px-4 py-2 border border-gray-300 rounded-lg font-mono text-sm" placeholder="Paste Order IDs..."></textarea>
                 </div>
                 <button className="w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
                     Update Orders
                 </button>
             </div>
        </div>
    );
};
