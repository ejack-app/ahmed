
import React, { useState, useEffect } from 'react';
import { 
  RotateCcw, Search, Filter, Printer, Eye, RefreshCw, MoreHorizontal, 
  MapPin, CheckSquare, Barcode, Trash2, FolderOpen, Loader
} from 'lucide-react';
import { api } from '../utils/api';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Show Pending RTO
export const ShowPendingRTO: React.FC<{ onViewDetails: () => void, onUpdate: () => void }> = ({ onViewDetails, onUpdate }) => {
    // In real implementation, this would fetch from /shipments?status=RTO_Pending
    const [rtoData, setRtoData] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Mock API call simulation for RTO
        setTimeout(() => {
            setRtoData([
                { id: 'DRS-9021', date: '2024-02-28', city: 'Riyadh', route: 'RUH-101', driver: 'Ahmed Ali', supplier: 'Internal', processed: 2, total: 5 },
                { id: 'DRS-9022', date: '2024-02-27', city: 'Jeddah', route: 'JED-202', driver: 'Mohammed S.', supplier: 'Agency A', processed: 0, total: 3 },
            ]);
            setLoading(false);
        }, 600);
    }, []);

    return (
        <div>
            <Header title="Pending RTO List" description="Track DRS with pending returns." />
            
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200 mb-6 flex flex-wrap gap-4 items-end">
                <div className="flex-1 min-w-[200px]">
                    <label className="block text-xs font-medium text-gray-500 mb-1">Search Unique ID</label>
                    <input type="text" placeholder="DRS Unique ID..." className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
                </div>
                <div className="w-40">
                    <label className="block text-xs font-medium text-gray-500 mb-1">City</label>
                    <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                        <option>Select City</option>
                        <option>Riyadh</option>
                        <option>Jeddah</option>
                    </select>
                </div>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700">Search</button>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">#</th>
                            <th className="px-6 py-4">Unique ID</th>
                            <th className="px-6 py-4">Date</th>
                            <th className="px-6 py-4">City</th>
                            <th className="px-6 py-4">Route Code</th>
                            <th className="px-6 py-4">Driver</th>
                            <th className="px-6 py-4">Supplier</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {loading ? (
                            <tr><td colSpan={9} className="p-6 text-center"><Loader className="animate-spin mx-auto"/></td></tr>
                        ) : rtoData.map((rto, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                <td className="px-6 py-4 font-mono font-medium text-blue-600 flex flex-col">
                                    <Barcode size={20} className="mb-1 opacity-50" />
                                    {rto.id}
                                </td>
                                <td className="px-6 py-4">{rto.date}</td>
                                <td className="px-6 py-4">{rto.city}</td>
                                <td className="px-6 py-4"><span className="bg-gray-100 px-2 py-1 rounded text-xs">{rto.route}</span></td>
                                <td className="px-6 py-4">{rto.driver}</td>
                                <td className="px-6 py-4">{rto.supplier}</td>
                                <td className="px-6 py-4">
                                    <span className="bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs font-bold">
                                        RTO PENDING {rto.processed}/{rto.total}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <div className="flex justify-end gap-2">
                                        <button className="p-1 text-gray-400 hover:text-blue-600" title="Print"><Printer size={16}/></button>
                                        <button onClick={onViewDetails} className="p-1 text-gray-400 hover:text-blue-600" title="View"><Eye size={16}/></button>
                                        <button onClick={onUpdate} className="p-1 text-gray-400 hover:text-blue-600" title="Update Status"><RefreshCw size={16}/></button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 2. Show RTO List (All)
export const ShowRTOList: React.FC<{ onViewDetails: () => void, onUpdate: () => void }> = ({ onViewDetails, onUpdate }) => {
    // Mock Data
    const allRTOs = [
        { id: 'DRS-9020', date: '2024-02-26', city: 'Riyadh', route: 'RUH-101', driver: 'Ahmed Ali', supplier: 'Internal', processed: 4, total: 4, status: 'Done' },
        { id: 'DRS-9021', date: '2024-02-28', city: 'Riyadh', route: 'RUH-101', driver: 'Ahmed Ali', supplier: 'Internal', processed: 2, total: 5, status: 'Running' },
    ];

    return (
        <div>
            <Header title="All RTO Lists" description="Comprehensive list of all RTO activities." />
            
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200 mb-6 flex flex-wrap gap-4 items-end">
                {/* Same filters as Pending */}
                <div className="flex-1 min-w-[200px]">
                    <label className="block text-xs font-medium text-gray-500 mb-1">Search Unique ID</label>
                    <input type="text" placeholder="DRS Unique ID..." className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
                </div>
                {/* ... other filters ... */}
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700">Search</button>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">#</th>
                            <th className="px-6 py-4">Unique ID</th>
                            <th className="px-6 py-4">Date</th>
                            <th className="px-6 py-4">City</th>
                            <th className="px-6 py-4">Route Code</th>
                            <th className="px-6 py-4">Driver</th>
                            <th className="px-6 py-4">Supplier</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {allRTOs.map((rto, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                <td className="px-6 py-4 font-mono font-medium text-blue-600 flex flex-col">
                                    <Barcode size={20} className="mb-1 opacity-50" />
                                    {rto.id}
                                </td>
                                <td className="px-6 py-4">{rto.date}</td>
                                <td className="px-6 py-4">{rto.city}</td>
                                <td className="px-6 py-4"><span className="bg-gray-100 px-2 py-1 rounded text-xs">{rto.route}</span></td>
                                <td className="px-6 py-4">{rto.driver}</td>
                                <td className="px-6 py-4">{rto.supplier}</td>
                                <td className="px-6 py-4">
                                    {rto.status === 'Done' ? (
                                        <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-bold">
                                            DONE {rto.processed}/{rto.total}
                                        </span>
                                    ) : (
                                        <span className="bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs font-bold">
                                            RUNNING {rto.processed}/{rto.total}
                                        </span>
                                    )}
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <div className="flex justify-end gap-2">
                                        <button className="p-1 text-gray-400 hover:text-blue-600" title="Print"><Printer size={16}/></button>
                                        <button onClick={onViewDetails} className="p-1 text-gray-400 hover:text-blue-600" title="View"><Eye size={16}/></button>
                                        <button onClick={onUpdate} className="p-1 text-gray-400 hover:text-blue-600" title="Update Status"><RefreshCw size={16}/></button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 3. RTO Details
export const RTODetails: React.FC = () => {
    // Mock Shipments
    const shipments = [
        { id: 1, awb: 'AWB-1001', type: 'Parcel', address: 'King Fahd Rd, Riyadh', driver: 'Ahmed Ali', code: 'RT-01', delivered: 'Y' },
        { id: 2, awb: 'AWB-1002', type: 'Document', address: 'Olaya St, Riyadh', driver: 'Ahmed Ali', code: 'RT-02', delivered: 'N' },
    ];

    return (
        <div>
            <Header 
                title="RTO Details" 
                description="Detailed view of returned shipments in DRS-9021."
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700 font-medium">
                        <Printer size={16} /> Print
                    </button>
                }
            />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">#</th>
                            <th className="px-6 py-4">AWB No.</th>
                            <th className="px-6 py-4">Product Type</th>
                            <th className="px-6 py-4">Address</th>
                            <th className="px-6 py-4">Driver Name</th>
                            <th className="px-6 py-4">Reason Code</th>
                            <th className="px-6 py-4">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {shipments.map((s, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                <td className="px-6 py-4 font-mono text-blue-600">{s.awb}</td>
                                <td className="px-6 py-4">{s.type}</td>
                                <td className="px-6 py-4">{s.address}</td>
                                <td className="px-6 py-4">{s.driver}</td>
                                <td className="px-6 py-4"><span className="bg-orange-100 text-orange-800 px-2 rounded text-xs">{s.code}</span></td>
                                <td className="px-6 py-4">
                                    <div className="flex gap-2">
                                        {s.delivered === 'Y' && (
                                            <button className="text-gray-500 hover:text-blue-600 flex items-center gap-1" title="Open Shipment">
                                                <FolderOpen size={16} /> Open
                                            </button>
                                        )}
                                        <button className="text-gray-500 hover:text-red-600 flex items-center gap-1" title="Delete">
                                            <Trash2 size={16} /> Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 4. Update RTO
export const UpdateRTO: React.FC = () => {
    // Mock Data for Update
    const rtoData = [
        { id: 1, awb: 'AWB-1001', attempt: 1, address: 'King Fahd Rd, Riyadh', driver: 'Ahmed Ali', date: '2024-03-01', reason: 'Customer Unavailable' },
        { id: 2, awb: 'AWB-1005', attempt: 2, address: 'Malaz, Riyadh', driver: 'Ahmed Ali', date: '2024-03-01', reason: 'Refused' },
    ];

    return (
        <div className="max-w-5xl mx-auto pb-10">
            <Header title="Update RTW (Return to Warehouse)" description="Confirm return status for shipments." />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-6">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4 w-10">
                                <div className="flex flex-col items-center gap-1">
                                    <input type="checkbox" />
                                    <span className="text-[10px]">Select All</span>
                                </div>
                            </th>
                            <th className="px-6 py-4">#</th>
                            <th className="px-6 py-4">AWB No.</th>
                            <th className="px-6 py-4">Delivery Attempt</th>
                            <th className="px-6 py-4">Address</th>
                            <th className="px-6 py-4">Courier Name</th>
                            <th className="px-6 py-4">Schedule Date</th>
                            <th className="px-6 py-4">Reasons</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {rtoData.map((data, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 text-center"><input type="checkbox" /></td>
                                <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                <td className="px-6 py-4 font-mono text-blue-600">{data.awb}</td>
                                <td className="px-6 py-4 text-center">{data.attempt}</td>
                                <td className="px-6 py-4">{data.address}</td>
                                <td className="px-6 py-4">{data.driver}</td>
                                <td className="px-6 py-4">{data.date}</td>
                                <td className="px-6 py-4"><span className="text-red-600 text-xs font-medium bg-red-50 px-2 py-1 rounded">{data.reason}</span></td>
                            </tr>
                        ))}
                        {rtoData.length === 0 && (
                            <tr><td colSpan={8} className="px-6 py-8 text-center text-gray-400">No Records Found</td></tr>
                        )}
                    </tbody>
                </table>
            </div>
            
            <div className="flex justify-end">
                <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                    <CheckSquare size={18} /> Confirm Update
                </button>
            </div>
        </div>
    );
};
