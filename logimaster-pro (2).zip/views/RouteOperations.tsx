
import React, { useState, useEffect } from 'react';
import { Route, Plus, Search, Map, List, Loader } from 'lucide-react';
import { api } from '../utils/api';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Add Route
export const AddRoute: React.FC = () => {
    const [formData, setFormData] = useState({ route_code: '', name: '', origin_hub: '', target_zone: '', default_driver_id: '' });

    const handleSubmit = async () => {
        try {
            await api.post('/routes', formData);
            alert('Route Created Successfully');
            setFormData({ route_code: '', name: '', origin_hub: '', target_zone: '', default_driver_id: '' });
        } catch(e: any) {
            alert(e.message);
        }
    };

    return (
        <div className="max-w-3xl mx-auto pb-10">
            <Header title="Create New Route" description="Define a standard delivery route." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Route Code</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. RUH-101" value={formData.route_code} onChange={e => setFormData({...formData, route_code: e.target.value})} />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Route Name</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. Riyadh North - Morning" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Origin Hub</label>
                            <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="Hub Name" value={formData.origin_hub} onChange={e => setFormData({...formData, origin_hub: e.target.value})} />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Target Zone</label>
                            <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="Zone" value={formData.target_zone} onChange={e => setFormData({...formData, target_zone: e.target.value})} />
                        </div>
                    </div>
                </div>
                <div className="mt-8 flex justify-end">
                    <button onClick={handleSubmit} className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                        <Plus size={18} /> Save Route
                    </button>
                </div>
            </div>
        </div>
    );
};

// 2. Add Route Bulk
export const AddRouteBulk: React.FC = () => {
    return (
        <div className="max-w-3xl mx-auto pb-10">
            <Header title="Bulk Route Import" description="Upload routes via CSV." />
            <div className="bg-white p-10 rounded-xl shadow-sm border border-dashed border-gray-300 flex flex-col items-center justify-center text-center">
                 <Route size={48} className="text-gray-300 mb-4" />
                 <h3 className="text-lg font-medium text-gray-900 mb-2">Upload Route CSV</h3>
                 <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Browse Files</button>
            </div>
        </div>
    );
};

// 3. Show Route
export const ShowRoute: React.FC = () => {
    const [routes, setRoutes] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchRoutes = async () => {
            try {
                const data = await api.get('/routes');
                setRoutes(data);
            } catch(e) { console.error(e); }
            finally { setLoading(false); }
        };
        fetchRoutes();
    }, []);

    return (
        <div>
            <Header title="Route List" description="Manage active delivery routes." />
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Route ID</th>
                            <th className="px-6 py-4">Code</th>
                            <th className="px-6 py-4">Name</th>
                            <th className="px-6 py-4">Origin</th>
                            <th className="px-6 py-4">Target Zone</th>
                            <th className="px-6 py-4">Default Driver</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {loading ? (
                            <tr><td colSpan={7} className="p-6 text-center"><Loader className="animate-spin mx-auto"/></td></tr>
                        ) : routes.length === 0 ? (
                            <tr><td colSpan={7} className="p-6 text-center text-gray-400">No routes found.</td></tr>
                        ) : (
                            routes.map((r, i) => (
                                <tr key={i} className="hover:bg-gray-50">
                                    <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                    <td className="px-6 py-4 font-mono text-blue-600">{r.route_code}</td>
                                    <td className="px-6 py-4 font-medium text-gray-900">{r.name}</td>
                                    <td className="px-6 py-4">{r.origin_hub}</td>
                                    <td className="px-6 py-4">{r.target_zone}</td>
                                    <td className="px-6 py-4">{r.default_driver || '-'}</td>
                                    <td className="px-6 py-4 text-right"><button className="text-gray-400 hover:text-gray-600">View</button></td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
