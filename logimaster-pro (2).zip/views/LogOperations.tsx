
import React, { useState, useEffect } from 'react';
import { ScrollText, Search, Filter, Clock, Loader, User } from 'lucide-react';
import { api } from '../utils/api';

const Header: React.FC<{ title: string; description: string }> = ({ title, description }) => (
  <div className="mb-6">
    <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
    <p className="text-sm text-gray-500">{description}</p>
  </div>
);

const LogTable: React.FC<{ filter: string }> = ({ filter }) => {
    const [logs, setLogs] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchLogs = async () => {
            setLoading(true);
            try {
                // In a real scenario, map the UI filter string to backend types
                // e.g. "Order Created" -> "ORDER_CREATE"
                const data = await api.get(`/logs?type=${filter === 'System' ? '' : filter}&limit=50`);
                setLogs(data);
            } catch (e) {
                console.error(e);
            } finally {
                setLoading(false);
            }
        };
        fetchLogs();
    }, [filter]);

    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                    <input type="text" placeholder={`Search ${filter} logs...`} className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                </div>
                <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 flex items-center gap-2">
                    <Filter size={16} /> Filter Date
                </button>
            </div>
            <table className="w-full text-left text-sm text-gray-600">
                <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                    <tr>
                        <th className="px-6 py-4">Log ID</th>
                        <th className="px-6 py-4">Timestamp</th>
                        <th className="px-6 py-4">User / System</th>
                        <th className="px-6 py-4">Action</th>
                        <th className="px-6 py-4">Details</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                    {loading ? (
                        <tr><td colSpan={5} className="p-6 text-center"><Loader className="animate-spin mx-auto"/></td></tr>
                    ) : logs.length === 0 ? (
                        <tr><td colSpan={5} className="p-6 text-center text-gray-400">No logs found for this category.</td></tr>
                    ) : (
                        logs.map((log, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono text-gray-500">#{log.id}</td>
                                <td className="px-6 py-4 flex items-center gap-2">
                                    <Clock size={14} className="text-gray-400" /> 
                                    {new Date(log.created_at).toLocaleString()}
                                </td>
                                <td className="px-6 py-4 font-medium text-gray-900 flex items-center gap-2">
                                    <User size={14} className="text-gray-400"/> {log.user || 'System'}
                                </td>
                                <td className="px-6 py-4 font-semibold text-blue-600">{log.action}</td>
                                <td className="px-6 py-4 text-gray-500 truncate max-w-xs" title={log.details}>
                                    {log.details}
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
        </div>
    );
};

export const LogViewer: React.FC<{ type: string }> = ({ type }) => {
    return (
        <div>
            <Header title={`${type} Logs`} description={`Audit trail for ${type} events.`} />
            <LogTable filter={type} />
        </div>
    );
};
