import React from 'react';
import { 
  Package, Save, Upload, Plus, Grid, ArrowRight, Layers, 
  Search, Filter, FileText, Download 
} from 'lucide-react';

// Reusable Header
const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Add Item Inventory
export const AddItemInventory: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto pb-10">
      <Header title="Add Inventory Item" description="Create a new SKU or add stock to an existing item." />
      
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           <div className="md:col-span-2">
               <h3 className="text-md font-semibold text-gray-800 mb-4 border-b pb-2">Product Details</h3>
           </div>
           
           <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">SKU (Stock Keeping Unit)</label>
              <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. ELEC-001-BLK" />
           </div>
           <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Product Name</label>
              <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. Wireless Mouse" />
           </div>
           <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Category</label>
              <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                  <option>Electronics</option>
                  <option>Clothing</option>
                  <option>Home & Garden</option>
                  <option>Other</option>
              </select>
           </div>
           <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Client / Owner</label>
              <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                  <option>Internal Stock</option>
                  <option>Client: TechStore</option>
                  <option>Client: MobileWorld</option>
              </select>
           </div>

           <div className="md:col-span-2 mt-4">
               <h3 className="text-md font-semibold text-gray-800 mb-4 border-b pb-2">Stock & Location</h3>
           </div>

           <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Initial Quantity</label>
              <input type="number" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="0" />
           </div>
           <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Shelf Location</label>
              <div className="flex gap-2">
                 <input type="text" className="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="Scan or enter Shelf ID" />
                 <button className="px-3 bg-gray-100 border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-200">
                     Scan
                 </button>
              </div>
           </div>
        </div>

        <div className="mt-8 flex justify-end gap-3">
            <button className="px-5 py-2.5 text-gray-700 hover:bg-gray-100 rounded-lg font-medium">Cancel</button>
            <button className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                <Save size={18} /> Save Item
            </button>
        </div>
      </div>
    </div>
  );
};

// 2. Add Shelf
export const AddShelf: React.FC = () => {
    return (
      <div className="max-w-2xl mx-auto pb-10">
        <Header title="Add New Shelf" description="Register a new storage location in the warehouse." />
        
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 space-y-4">
             <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Shelf Code / ID</label>
                <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. A-01-01" />
                <p className="text-xs text-gray-400 mt-1">Format: Aisle - Rack - Level</p>
             </div>
             <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Zone</label>
                <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                    <option>Zone A (Electronics)</option>
                    <option>Zone B (Bulk)</option>
                    <option>Zone C (Returns)</option>
                </select>
             </div>
             <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Shelf Type</label>
                <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                    <option>Standard Bin</option>
                    <option>Pallet Rack</option>
                    <option>Secure Cage</option>
                    <option>Cold Storage</option>
                </select>
             </div>
             <div>
                 <label className="block text-sm font-medium text-gray-700 mb-1.5">Dimensions (LxWxH cm) - Optional</label>
                 <div className="flex gap-2">
                     <input type="number" className="w-full px-3 py-2 border border-gray-300 rounded-lg" placeholder="L" />
                     <input type="number" className="w-full px-3 py-2 border border-gray-300 rounded-lg" placeholder="W" />
                     <input type="number" className="w-full px-3 py-2 border border-gray-300 rounded-lg" placeholder="H" />
                 </div>
             </div>

             <div className="pt-4">
                 <button className="w-full py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center justify-center gap-2">
                    <Plus size={18} /> Create Shelf
                 </button>
             </div>
        </div>
      </div>
    );
};

// 3. View Shelf
export const ViewShelf: React.FC = () => {
    // Mock Data
    const shelves = [
        { id: 'A-01-01', zone: 'A', type: 'Bin', occupancy: '80%', items: 12 },
        { id: 'A-01-02', zone: 'A', type: 'Bin', occupancy: '45%', items: 5 },
        { id: 'B-05-01', zone: 'B', type: 'Pallet', occupancy: '100%', items: 1 },
        { id: 'C-02-04', zone: 'C', type: 'Secure', occupancy: '0%', items: 0 },
        { id: 'A-02-01', zone: 'A', type: 'Bin', occupancy: '20%', items: 3 },
    ];

    return (
        <div>
            <Header 
                title="Shelf Management" 
                description="Overview of warehouse storage locations." 
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Download size={16} /> Print Labels
                    </button>
                }
            />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search Shelf ID..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                    <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 flex items-center gap-2">
                        <Filter size={16} /> Filter by Zone
                    </button>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Shelf ID</th>
                            <th className="px-6 py-4">Zone</th>
                            <th className="px-6 py-4">Type</th>
                            <th className="px-6 py-4">Occupancy</th>
                            <th className="px-6 py-4">Items Stored</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {shelves.map((shelf) => (
                            <tr key={shelf.id} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono font-medium text-blue-600">{shelf.id}</td>
                                <td className="px-6 py-4">{shelf.zone}</td>
                                <td className="px-6 py-4">{shelf.type}</td>
                                <td className="px-6 py-4">
                                    <div className="flex items-center gap-2">
                                        <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                                            <div 
                                                className={`h-full ${shelf.occupancy === '100%' ? 'bg-red-500' : 'bg-green-500'}`} 
                                                style={{ width: shelf.occupancy }}
                                            ></div>
                                        </div>
                                        <span className="text-xs">{shelf.occupancy}</span>
                                    </div>
                                </td>
                                <td className="px-6 py-4">{shelf.items} SKUs</td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-blue-600 hover:text-blue-800 text-xs font-medium">View Items</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 4. Update Shelf
export const UpdateShelf: React.FC = () => {
    return (
        <div className="max-w-3xl mx-auto pb-10">
            <Header title="Update Shelf" description="Modify shelf details or clear contents." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Search Shelf to Update</label>
                    <div className="flex gap-2">
                        <input type="text" className="flex-1 px-4 py-2 border border-gray-300 rounded-lg" placeholder="Enter Shelf ID (e.g. A-01-01)" />
                        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg">Find</button>
                    </div>
                </div>

                <div className="border-t border-gray-100 pt-6">
                    <h3 className="font-semibold text-gray-800 mb-4">Edit Details: <span className="text-blue-600">A-01-01</span></h3>
                     <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Shelf Type</label>
                            <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                                <option>Standard Bin</option>
                                <option>Pallet Rack</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Status</label>
                            <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                                <option>Active</option>
                                <option>Under Maintenance</option>
                                <option>Inactive</option>
                            </select>
                        </div>
                     </div>
                     <div className="mt-6 flex justify-between items-center">
                         <button className="text-red-600 text-sm font-medium hover:underline">Clear All Items from Shelf</button>
                         <button className="px-5 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Update Shelf</button>
                     </div>
                </div>
            </div>
        </div>
    );
};

// 5. Merge Stock
export const MergeStock: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Merge Stock" description="Consolidate inventory from multiple shelves into one." />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-6 grid grid-cols-1 md:grid-cols-7 gap-4 items-center">
                    
                    {/* Source */}
                    <div className="md:col-span-3 space-y-4">
                        <h3 className="font-semibold text-gray-800 border-b pb-2">Source Location</h3>
                        <div>
                            <label className="block text-xs font-medium text-gray-500 mb-1">Select Item</label>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="SKU..." />
                        </div>
                        <div>
                            <label className="block text-xs font-medium text-gray-500 mb-1">From Shelf</label>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="Shelf ID..." />
                        </div>
                        <div className="p-3 bg-gray-50 rounded text-xs text-gray-600">
                            Available Stock: <span className="font-bold">0</span>
                        </div>
                    </div>

                    {/* Arrow */}
                    <div className="md:col-span-1 flex justify-center py-4 md:py-0">
                        <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center">
                            <ArrowRight size={20} />
                        </div>
                    </div>

                    {/* Destination */}
                    <div className="md:col-span-3 space-y-4">
                         <h3 className="font-semibold text-gray-800 border-b pb-2">Destination Location</h3>
                        <div>
                            <label className="block text-xs font-medium text-gray-500 mb-1">To Shelf</label>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="Target Shelf ID..." />
                        </div>
                         <div>
                            <label className="block text-xs font-medium text-gray-500 mb-1">Quantity to Move</label>
                            <input type="number" className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="0" />
                        </div>
                    </div>

                </div>
                
                <div className="bg-gray-50 p-4 flex justify-end">
                     <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
                         Confirm Merge
                     </button>
                </div>
            </div>
        </div>
    );
};

// 6. Inventory Per Client
export const InventoryPerClient: React.FC = () => {
    const clientStock = [
        { client: 'TechStore', skuCount: 450, totalItems: 12000, value: 'SAR 850,000' },
        { client: 'MobileWorld', skuCount: 120, totalItems: 5400, value: 'SAR 320,000' },
        { client: 'GamersHub', skuCount: 85, totalItems: 1200, value: 'SAR 150,000' },
    ];

    return (
        <div>
            <Header title="Inventory Per Client" description="Breakdown of stock ownership for 3PL clients." />
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                {clientStock.map((c, i) => (
                    <div key={i} className="bg-white p-5 rounded-xl shadow-sm border border-gray-200">
                        <h3 className="font-bold text-gray-900 text-lg mb-1">{c.client}</h3>
                        <div className="space-y-2 mt-4">
                            <div className="flex justify-between text-sm">
                                <span className="text-gray-500">Unique SKUs</span>
                                <span className="font-medium">{c.skuCount}</span>
                            </div>
                             <div className="flex justify-between text-sm">
                                <span className="text-gray-500">Total Units</span>
                                <span className="font-medium">{c.totalItems}</span>
                            </div>
                             <div className="flex justify-between text-sm">
                                <span className="text-gray-500">Est. Value</span>
                                <span className="font-medium text-green-600">{c.value}</span>
                            </div>
                        </div>
                        <button className="w-full mt-4 py-2 border border-blue-600 text-blue-600 rounded-lg text-sm hover:bg-blue-50">View Details</button>
                    </div>
                ))}
            </div>
        </div>
    );
};

// 7. Upload Inventory
export const UploadInventory: React.FC = () => {
    return (
        <div className="max-w-3xl mx-auto pb-10">
             <Header title="Upload Inventory" description="Bulk import inventory items via CSV or Excel." />
             
             <div className="bg-white p-10 rounded-xl shadow-sm border border-dashed border-gray-300 flex flex-col items-center justify-center text-center">
                 <Upload size={48} className="text-gray-300 mb-4" />
                 <h3 className="text-lg font-medium text-gray-900 mb-2">Drag and drop your Inventory file</h3>
                 <p className="text-sm text-gray-500 mb-6 max-w-md">
                     Supported formats: .CSV, .XLSX. Please ensure your file matches the template structure to avoid errors.
                 </p>
                 <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                     Select File
                 </button>
                 <div className="mt-8 flex gap-4 text-sm">
                     <button className="text-blue-600 hover:underline flex items-center gap-1">
                         <FileText size={14} /> Download CSV Template
                     </button>
                     <button className="text-blue-600 hover:underline flex items-center gap-1">
                          <FileText size={14} /> Download Excel Template
                     </button>
                 </div>
             </div>

             <div className="mt-8">
                 <h4 className="font-semibold text-gray-900 mb-3">Import History</h4>
                 <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                     <div className="p-3 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                         <span className="text-sm font-medium">inventory_nov_2024.csv</span>
                         <span className="text-xs text-green-600 bg-green-100 px-2 py-0.5 rounded">Completed</span>
                     </div>
                     <div className="p-3 flex justify-between items-center">
                         <span className="text-sm font-medium">bulk_stock_update.xlsx</span>
                         <span className="text-xs text-red-600 bg-red-100 px-2 py-0.5 rounded">Failed (Line 42)</span>
                     </div>
                 </div>
             </div>
        </div>
    );
};