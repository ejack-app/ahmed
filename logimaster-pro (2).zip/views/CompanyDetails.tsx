import React, { useState } from 'react';
import { Building, Mail, Phone, MapPin, Save, Globe, Upload, FileText } from 'lucide-react';

export const CompanyDetails: React.FC = () => {
  const [formData, setFormData] = useState({
    companyName: 'LogiMaster Logistics Co.',
    crNumber: '1010552211',
    vatNumber: '310123456700003',
    email: 'admin@logimaster.sa',
    phone: '+966 55 123 4567',
    website: 'https://logimaster.sa',
    address: 'King Fahd Road, Olaya District',
    city: 'Riyadh',
    country: 'Saudi Arabia',
    zipCode: '12211',
    description: 'Leading logistics partner for e-commerce in Saudi Arabia.'
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="max-w-5xl mx-auto pb-10">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Company Profile</h2>
          <p className="text-sm text-gray-500">Manage your organization's legal and contact information.</p>
        </div>
        <button className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2 font-medium shadow-sm transition-colors">
          <Save size={18} /> Save Changes
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Branding */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <h3 className="font-semibold text-gray-900 mb-4">Company Logo</h3>
            <div className="flex flex-col items-center justify-center space-y-4">
               <div className="relative group">
                  <div className="w-40 h-40 rounded-full bg-gray-50 border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden">
                      <Building size={48} className="text-gray-300" />
                  </div>
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 rounded-full transition-all flex items-center justify-center">
                     {/* Overlay for hover effect */}
                  </div>
               </div>
               <p className="text-xs text-center text-gray-500 max-w-[200px]">
                 Upload your company logo. Recommended size: 512x512px (PNG, JPG)
               </p>
               <button className="w-full py-2.5 px-4 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 flex items-center justify-center gap-2 transition-colors">
                  <Upload size={16} /> Upload New Logo
               </button>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
             <h3 className="font-semibold text-gray-900 mb-4">Documents</h3>
             <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-100">
                   <div className="flex items-center gap-3">
                      <FileText size={18} className="text-blue-500" />
                      <div className="text-sm">
                         <p className="font-medium text-gray-700">CR_Certificate.pdf</p>
                         <p className="text-xs text-gray-400">Exp: 2025-12-31</p>
                      </div>
                   </div>
                   <button className="text-xs text-blue-600 hover:underline">View</button>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-100">
                   <div className="flex items-center gap-3">
                      <FileText size={18} className="text-blue-500" />
                      <div className="text-sm">
                         <p className="font-medium text-gray-700">VAT_Cert.pdf</p>
                         <p className="text-xs text-gray-400">Verified</p>
                      </div>
                   </div>
                   <button className="text-xs text-blue-600 hover:underline">View</button>
                </div>
                <button className="w-full mt-2 py-2 text-sm text-blue-600 border border-dashed border-blue-200 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                   + Add Document
                </button>
             </div>
          </div>
        </div>

        {/* Right Column: Details Forms */}
        <div className="lg:col-span-2 space-y-6">
            
            {/* General Info */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2 pb-4 border-b border-gray-100">
                    <Building size={20} className="text-blue-600" /> General Information
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Company Name (English)</label>
                        <input 
                            type="text" 
                            name="companyName"
                            value={formData.companyName}
                            onChange={handleChange}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all" 
                        />
                    </div>
                     <div className="col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Description</label>
                        <textarea 
                            name="description"
                            rows={3}
                            value={formData.description}
                            onChange={handleChange}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all resize-none" 
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">CR Number</label>
                        <input 
                            type="text" 
                            name="crNumber"
                            value={formData.crNumber}
                            onChange={handleChange}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all" 
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">VAT Number</label>
                        <input 
                            type="text" 
                            name="vatNumber"
                            value={formData.vatNumber}
                            onChange={handleChange}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all" 
                        />
                    </div>
                </div>
            </div>

            {/* Contact Info */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2 pb-4 border-b border-gray-100">
                    <Mail size={20} className="text-blue-600" /> Contact Details
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
                        <input 
                            type="email" 
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all" 
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone Number</label>
                        <input 
                            type="text" 
                            name="phone"
                            value={formData.phone}
                            onChange={handleChange}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all" 
                        />
                    </div>
                    <div className="col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Website</label>
                        <div className="relative">
                            <Globe size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                            <input 
                                type="text" 
                                name="website"
                                value={formData.website}
                                onChange={handleChange}
                                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all" 
                            />
                        </div>
                    </div>
                </div>
            </div>

            {/* Address */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2 pb-4 border-b border-gray-100">
                    <MapPin size={20} className="text-blue-600" /> HQ Address
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Street Address</label>
                        <input 
                            type="text" 
                            name="address"
                            value={formData.address}
                            onChange={handleChange}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all" 
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">City</label>
                        <input 
                            type="text" 
                            name="city"
                            value={formData.city}
                            onChange={handleChange}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all" 
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Zip Code</label>
                        <input 
                            type="text" 
                            name="zipCode"
                            value={formData.zipCode}
                            onChange={handleChange}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all" 
                        />
                    </div>
                </div>
            </div>

        </div>
      </div>
    </div>
  );
};