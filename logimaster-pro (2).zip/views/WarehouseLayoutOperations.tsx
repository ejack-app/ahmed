import React, { useState } from 'react';
import { 
  Box, Grid, Layout, Maximize, MousePointer, 
  Trash2, Save, ZoomIn, ZoomOut, RotateCw, Layers
} from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

type GridItemType = 'rack' | 'wall' | 'zone' | 'door';

interface GridItem {
  id: number;
  x: number;
  y: number;
  type: GridItemType;
  color: string;
  height?: number; // for 3D extrusion
}

export const WarehouseLayoutDesigner: React.FC = () => {
  const [viewMode, setViewMode] = useState<'2D' | '3D'>('2D');
  const [selectedTool, setSelectedTool] = useState<GridItemType>('rack');
  const [gridSize] = useState(20);
  const [items, setItems] = useState<GridItem[]>([
    { id: 1, x: 2, y: 2, type: 'wall', color: '#64748b', height: 3 },
    { id: 2, x: 2, y: 3, type: 'wall', color: '#64748b', height: 3 },
    { id: 3, x: 2, y: 4, type: 'wall', color: '#64748b', height: 3 },
    { id: 4, x: 5, y: 5, type: 'rack', color: '#f97316', height: 2 },
    { id: 5, x: 6, y: 5, type: 'rack', color: '#f97316', height: 2 },
    { id: 6, x: 7, y: 5, type: 'rack', color: '#f97316', height: 2 },
  ]);

  const handleGridClick = (x: number, y: number) => {
    // Check if item exists
    const existingIndex = items.findIndex(i => i.x === x && i.y === y);
    
    if (existingIndex >= 0) {
      // Remove item
      const newItems = [...items];
      newItems.splice(existingIndex, 1);
      setItems(newItems);
    } else {
      // Add item
      const newItem: GridItem = {
        id: Date.now(),
        x,
        y,
        type: selectedTool,
        color: selectedTool === 'rack' ? '#f97316' : 
               selectedTool === 'wall' ? '#64748b' : 
               selectedTool === 'zone' ? '#22c55e' : '#3b82f6',
        height: selectedTool === 'rack' ? 2 : selectedTool === 'wall' ? 3 : 0.1
      };
      setItems([...items, newItem]);
    }
  };

  const getToolIcon = (type: GridItemType) => {
    switch(type) {
      case 'rack': return <Grid size={18} />;
      case 'wall': return <Box size={18} />;
      case 'zone': return <Layout size={18} />;
      case 'door': return <Maximize size={18} />;
    }
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col">
      <Header 
        title="Warehouse Layout Planner" 
        description="Design your warehouse structure and visualize in 3D." 
        action={
          <div className="flex bg-gray-100 p-1 rounded-lg">
            <button 
              onClick={() => setViewMode('2D')}
              className={`px-4 py-1.5 text-sm font-medium rounded-md transition-all ${viewMode === '2D' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              2D Plan
            </button>
            <button 
              onClick={() => setViewMode('3D')}
              className={`px-4 py-1.5 text-sm font-medium rounded-md transition-all ${viewMode === '3D' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              3D View
            </button>
          </div>
        }
      />

      <div className="flex-1 flex gap-6 overflow-hidden">
        {/* Tools Panel */}
        <div className="w-64 bg-white rounded-xl shadow-sm border border-gray-200 p-4 flex flex-col gap-4">
          <div>
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Tools</h3>
            <div className="grid grid-cols-2 gap-2">
              {(['rack', 'wall', 'zone', 'door'] as GridItemType[]).map(tool => (
                <button
                  key={tool}
                  onClick={() => setSelectedTool(tool)}
                  className={`flex flex-col items-center justify-center p-3 rounded-lg border transition-all ${selectedTool === tool ? 'border-blue-500 bg-blue-50 text-blue-600' : 'border-gray-200 hover:bg-gray-50 text-gray-600'}`}
                >
                  {getToolIcon(tool)}
                  <span className="text-xs mt-1 capitalize">{tool}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Legend</h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2"><div className="w-3 h-3 bg-orange-500 rounded-sm"></div> Storage Rack</div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 bg-slate-500 rounded-sm"></div> Wall / Structure</div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 bg-green-500 rounded-sm"></div> Packing Zone</div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 bg-blue-500 rounded-sm"></div> Entry / Exit</div>
            </div>
          </div>

          <button className="w-full py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center justify-center gap-2">
            <Save size={18} /> Save Layout
          </button>
        </div>

        {/* Canvas Area */}
        <div className="flex-1 bg-gray-100 rounded-xl border border-gray-300 relative overflow-hidden flex items-center justify-center perspective-container">
          
          {viewMode === '2D' ? (
            /* 2D Grid */
            <div 
              className="grid gap-px bg-gray-300 p-px shadow-xl bg-white"
              style={{ 
                gridTemplateColumns: `repeat(${gridSize}, 2rem)`,
                width: 'fit-content' 
              }}
            >
              {Array.from({ length: gridSize * gridSize }).map((_, i) => {
                const x = i % gridSize;
                const y = Math.floor(i / gridSize);
                const item = items.find(it => it.x === x && it.y === y);

                return (
                  <div 
                    key={i}
                    onClick={() => handleGridClick(x, y)}
                    className="w-8 h-8 bg-gray-50 hover:bg-blue-50 cursor-pointer transition-colors relative"
                  >
                    {item && (
                      <div 
                        className="absolute inset-0.5 rounded-sm shadow-sm"
                        style={{ backgroundColor: item.color }}
                      ></div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            /* 3D Isometric View (CSS Only) */
            <div className="relative w-full h-full bg-slate-900 flex items-center justify-center overflow-hidden">
               <div 
                  className="relative transform-gpu transition-transform duration-500"
                  style={{
                    transform: 'rotateX(60deg) rotateZ(-45deg)',
                    width: `${gridSize * 40}px`,
                    height: `${gridSize * 40}px`,
                    transformStyle: 'preserve-3d'
                  }}
               >
                  {/* Floor */}
                  <div className="absolute inset-0 bg-slate-800/50 border-4 border-slate-700 shadow-2xl"></div>
                  
                  {/* Grid Lines (Visual) */}
                  <div 
                    className="absolute inset-0 opacity-20 pointer-events-none"
                    style={{
                        backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)',
                        backgroundSize: '40px 40px'
                    }}
                  ></div>

                  {/* 3D Items */}
                  {items.map(item => (
                    <div
                      key={item.id}
                      className="absolute"
                      style={{
                        left: `${item.x * 40}px`,
                        top: `${item.y * 40}px`,
                        width: '40px',
                        height: '40px',
                        transformStyle: 'preserve-3d',
                        transform: 'translateZ(0px)'
                      }}
                    >
                        {/* Base */}
                        <div 
                            className="absolute inset-0" 
                            style={{ backgroundColor: item.color }}
                        ></div>
                        
                        {/* Extrusion (Front) */}
                        <div 
                            className="absolute bottom-0 left-0 w-full origin-bottom"
                            style={{ 
                                height: `${(item.height || 1) * 20}px`,
                                backgroundColor: item.color,
                                filter: 'brightness(0.8)',
                                transform: 'rotateX(-90deg)'
                            }}
                        ></div>

                        {/* Extrusion (Side) */}
                        <div 
                            className="absolute top-0 right-0 h-full origin-right"
                            style={{ 
                                width: `${(item.height || 1) * 20}px`,
                                backgroundColor: item.color,
                                filter: 'brightness(0.6)',
                                transform: 'rotateY(90deg)'
                            }}
                        ></div>

                        {/* Top Cap */}
                        <div 
                            className="absolute inset-0"
                            style={{ 
                                backgroundColor: item.color,
                                filter: 'brightness(1.1)',
                                transform: `translateZ(${(item.height || 1) * 20}px)`
                            }}
                        >
                            {item.type === 'rack' && (
                                <div className="w-full h-full flex items-center justify-center opacity-30 text-[8px] text-white font-bold">
                                    R
                                </div>
                            )}
                        </div>
                    </div>
                  ))}
               </div>
               
               <div className="absolute bottom-8 right-8 bg-slate-800/90 text-white p-4 rounded-xl border border-slate-700 backdrop-blur">
                   <h4 className="text-sm font-bold mb-2 flex items-center gap-2"><Layers size={16}/> 3D View Controls</h4>
                   <p className="text-xs text-slate-400">This is a simulated isometric projection.</p>
                   <div className="mt-3 flex gap-2">
                       <button className="p-2 bg-slate-700 rounded hover:bg-slate-600"><ZoomIn size={16}/></button>
                       <button className="p-2 bg-slate-700 rounded hover:bg-slate-600"><ZoomOut size={16}/></button>
                       <button className="p-2 bg-slate-700 rounded hover:bg-slate-600"><RotateCw size={16}/></button>
                   </div>
               </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};