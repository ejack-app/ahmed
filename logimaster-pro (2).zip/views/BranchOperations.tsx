import React from 'react';
import { 
  Building2, Plus, Search, Filter, Edit, Trash2, MapPin, 
  Phone, User, Globe
} from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Add Branch
export const AddBranch: React.FC = () => {
    return (
        <div className="max-w-3xl mx-auto pb-10">
            <Header title="Add New Branch" description="Register a new operating branch location." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Country</label>
                        <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                            <option value="">Select Country</option>
                            <option value="SA">Saudi Arabia</option>
                            <option value="AE">UAE</option>
                            <option value="BH">Bahrain</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">City</label>
                        <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                            <option value="">Select City</option>
                            <option value="Riyadh">Riyadh</option>
                            <option value="Jeddah">Jeddah</option>
                            <option value="Dammam">Dammam</option>
                        </select>
                    </div>
                    
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Branch Name</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. Riyadh Main Office" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Branch Manager</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="Full Name" />
                    </div>

                    <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Branch Address</label>
                        <textarea rows={3} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg resize-none" placeholder="Detailed Address..."></textarea>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Contact Number</label>
                        <input type="tel" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="+966..." />
                    </div>
                </div>

                <div className="mt-8 flex justify-end gap-3">
                    <button className="px-5 py-2.5 text-gray-700 hover:bg-gray-100 rounded-lg font-medium">Cancel</button>
                    <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                        <Plus size={18} /> Add Branch
                    </button>
                </div>
            </div>
        </div>
    );
};

// 2. Show Branch (List)
export const ShowBranch: React.FC = () => {
    // Mock Data
    const branches = [
        { id: 1, name: 'Riyadh Main Office', city: 'Riyadh', manager: 'Abdulrahman Al-Saud', address: 'Olaya District, King Fahd Rd', contact: '011-222-3333', status: 'Active' },
        { id: 2, name: 'Jeddah Hub', city: 'Jeddah', manager: 'Fatima Ahmed', address: 'Al-Rawdah Dist', contact: '012-444-5555', status: 'Active' },
        { id: 3, name: 'Dammam Warehouse', city: 'Dammam', manager: 'Khalid Omar', address: 'Industrial Area 2', contact: '013-666-7777', status: 'Inactive' },
    ];

    return (
        <div>
            <Header 
                title="All Branches" 
                description="Manage your organization's physical locations."
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700 font-medium">
                        <Plus size={16} /> Add Branch
                    </button>
                }
            />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search by Name, City or Manager..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                    <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 flex items-center gap-2">
                        <Filter size={16} /> Filter
                    </button>
                </div>
                
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">#</th>
                            <th className="px-6 py-4">Branch Name</th>
                            <th className="px-6 py-4">City</th>
                            <th className="px-6 py-4">Manager</th>
                            <th className="px-6 py-4">Address</th>
                            <th className="px-6 py-4">Contact</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {branches.map((branch, i) => (
                            <tr key={branch.id} className="hover:bg-gray-50">
                                <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                <td className="px-6 py-4 font-medium text-gray-900 flex items-center gap-2">
                                    <Building2 size={16} className="text-blue-500" />
                                    {branch.name}
                                </td>
                                <td className="px-6 py-4">{branch.city}</td>
                                <td className="px-6 py-4 flex items-center gap-1">
                                    <User size={14} className="text-gray-400" />
                                    {branch.manager}
                                </td>
                                <td className="px-6 py-4 text-gray-500 truncate max-w-xs" title={branch.address}>
                                    {branch.address}
                                </td>
                                <td className="px-6 py-4">{branch.contact}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium 
                                        ${branch.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                        {branch.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right flex justify-end gap-2">
                                    <button className="p-1 hover:text-blue-600 text-gray-400" title="Edit">
                                        <Edit size={16} />
                                    </button>
                                    <button className="p-1 hover:text-red-600 text-gray-400" title="Delete">
                                        <Trash2 size={16} />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};