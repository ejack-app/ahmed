
import React, { useState, useEffect } from 'react';
import { BarChart, Download, Calendar, Filter, PieChart, TrendingUp, AlertTriangle, Package, Truck, User, Loader, ArrowDownCircle, Archive } from 'lucide-react';
import { api } from '../utils/api';
import { SimpleBarChart, SimpleLineChart } from '../components/Charts';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

const ReportContainer: React.FC<{ title: string, children: React.ReactNode, loading?: boolean }> = ({ title, children, loading }) => (
    <div className="space-y-6">
        <Header 
            title={title} 
            description="Generated report based on current system data."
            action={
                <div className="flex gap-2">
                    <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 flex items-center gap-2">
                        <Calendar size={16} /> Last 30 Days
                    </button>
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Download size={16} /> Export PDF/CSV
                    </button>
                </div>
            } 
        />
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 min-h-[400px]">
            {loading ? <div className="h-full flex items-center justify-center"><Loader className="animate-spin text-gray-400" size={32} /></div> : children}
        </div>
    </div>
);

// --- Reports ---

export const ShelveReport: React.FC = () => (
    <ReportContainer title="Shelve Utilization Report">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                <h4 className="text-blue-800 font-semibold mb-1">Total Capacity</h4>
                <p className="text-2xl font-bold text-blue-900">5,000 Slots</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg border border-green-100">
                <h4 className="text-green-800 font-semibold mb-1">Occupied</h4>
                <p className="text-2xl font-bold text-green-900">3,420 Slots (68%)</p>
            </div>
            <div className="p-4 bg-orange-50 rounded-lg border border-orange-100">
                <h4 className="text-orange-800 font-semibold mb-1">Fragmented</h4>
                <p className="text-2xl font-bold text-orange-900">150 Slots</p>
            </div>
        </div>
        <div>
            <h3 className="text-sm font-bold text-gray-700 mb-4">Utilization by Zone</h3>
            <SimpleBarChart 
                data={[85, 60, 45, 90, 30]} 
                labels={['Zone A (Elec)', 'Zone B (Bulk)', 'Zone C (Fashion)', 'Zone D (Cold)', 'Zone E (Returns)']} 
                color="bg-indigo-500"
            />
        </div>
    </ReportContainer>
);

export const TopProductDispatch: React.FC = () => (
    <ReportContainer title="Top Dispatched Products">
        <table className="w-full text-left text-sm text-gray-600">
            <thead className="bg-gray-50 uppercase font-semibold">
                <tr>
                    <th className="px-6 py-4">Rank</th>
                    <th className="px-6 py-4">Product Name</th>
                    <th className="px-6 py-4">SKU</th>
                    <th className="px-6 py-4">Units Dispatched</th>
                    <th className="px-6 py-4">Trend</th>
                </tr>
            </thead>
            <tbody>
                {[1, 2, 3, 4, 5].map(i => (
                    <tr key={i} className="border-b">
                        <td className="px-6 py-4">#{i}</td>
                        <td className="px-6 py-4 font-medium text-gray-900">Product Item {i}</td>
                        <td className="px-6 py-4 font-mono">SKU-00{i}</td>
                        <td className="px-6 py-4">{1000 - (i * 150)}</td>
                        <td className="px-6 py-4 text-green-600">▲ +{10 - i}%</td>
                    </tr>
                ))}
            </tbody>
        </table>
    </ReportContainer>
);

export const OFDReport: React.FC = () => (
    <ReportContainer title="Out For Delivery (OFD) Performance">
        <div className="mb-6">
            <h3 className="text-sm font-bold text-gray-700 mb-2">Delivery Success Rate (Last 7 Days)</h3>
            <SimpleLineChart data={[88, 92, 85, 94, 90, 96, 95]} color="#10b981" />
            <div className="flex justify-between text-xs text-gray-400 mt-2">
                <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span>
            </div>
        </div>
        <div className="grid grid-cols-3 gap-4 text-center mt-8">
            <div className="p-4 border rounded-lg">
                <span className="block text-2xl font-bold text-green-600">94.2%</span>
                <span className="text-xs text-gray-500">Success Rate</span>
            </div>
            <div className="p-4 border rounded-lg">
                <span className="block text-2xl font-bold text-red-600">2.1%</span>
                <span className="text-xs text-gray-500">Return Rate</span>
            </div>
            <div className="p-4 border rounded-lg">
                <span className="block text-2xl font-bold text-orange-600">3.7%</span>
                <span className="text-xs text-gray-500">Rescheduled</span>
            </div>
        </div>
    </ReportContainer>
);

export const StaffPerformance: React.FC = () => (
    <ReportContainer title="Staff Performance KPIs">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 border border-gray-200 rounded-xl">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <User size={18} className="text-blue-600"/> Top Pickers
                </h3>
                {['Ahmed', 'John', 'Sarah'].map((n, i) => (
                    <div key={i} className="flex justify-between items-center py-3 border-b last:border-0">
                        <span className="font-medium text-gray-700">{n}</span>
                        <div className="flex items-center gap-2">
                            <div className="w-24 bg-gray-100 rounded-full h-2">
                                <div className="bg-blue-500 h-2 rounded-full" style={{ width: `${100 - i * 15}%` }}></div>
                            </div>
                            <span className="font-mono text-xs font-bold">{150 - i * 20} /hr</span>
                        </div>
                    </div>
                ))}
            </div>
            <div className="p-6 border border-gray-200 rounded-xl">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <Package size={18} className="text-orange-600"/> Top Packers
                </h3>
                {['Mike', 'Fahad', 'Lisa'].map((n, i) => (
                    <div key={i} className="flex justify-between items-center py-3 border-b last:border-0">
                        <span className="font-medium text-gray-700">{n}</span>
                        <div className="flex items-center gap-2">
                            <div className="w-24 bg-gray-100 rounded-full h-2">
                                <div className="bg-orange-500 h-2 rounded-full" style={{ width: `${90 - i * 10}%` }}></div>
                            </div>
                            <span className="font-mono text-xs font-bold">{80 - i * 5} /hr</span>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    </ReportContainer>
);

export const DispatchingReport: React.FC = () => {
    const [stats, setStats] = useState<any>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const data = await api.get('/dashboard/stats');
                setStats(data);
            } catch (error) { console.error(error); } 
            finally { setLoading(false); }
        };
        fetchStats();
    }, []);

    // Fallback data if API fails or returns 0
    const chartData = stats?.shipments?.total ? 
        [stats.shipments.total, stats.shipments.delivered, stats.shipments.returned, stats.shipments.pending] :
        [150, 120, 5, 25]; // Mock

    return (
        <ReportContainer title="Daily Dispatch Summary" loading={loading}>
            <div className="grid grid-cols-4 gap-4 mb-8">
                <div className="bg-blue-50 p-4 rounded-lg text-center">
                    <h4 className="text-sm font-semibold text-blue-700">Total Shipments</h4>
                    <p className="text-2xl font-bold text-blue-900">{stats?.shipments?.total || 0}</p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg text-center">
                    <h4 className="text-sm font-semibold text-green-700">Delivered</h4>
                    <p className="text-2xl font-bold text-green-900">{stats?.shipments?.delivered || 0}</p>
                </div>
                <div className="bg-red-50 p-4 rounded-lg text-center">
                    <h4 className="text-sm font-semibold text-red-700">Returned</h4>
                    <p className="text-2xl font-bold text-red-900">{stats?.shipments?.returned || 0}</p>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg text-center">
                    <h4 className="text-sm font-semibold text-yellow-700">Pending</h4>
                    <p className="text-2xl font-bold text-yellow-900">{stats?.shipments?.pending || 0}</p>
                </div>
            </div>
            
            <h3 className="text-sm font-bold text-gray-700 mb-4">Volume Distribution</h3>
            <SimpleBarChart 
                data={chartData} 
                labels={['Total', 'Delivered', 'Returned', 'Pending']} 
                color="bg-blue-600"
            />
        </ReportContainer>
    );
};

export const Report3PL: React.FC = () => (
    <ReportContainer title="3PL Client Analysis">
        <SimpleBarChart 
            data={[12000, 8500, 4200, 3100, 1500]} 
            labels={['TechStore', 'Beauty Box', 'HomeHub', 'FashionPlus', 'GadgetZone']} 
            color="bg-purple-600"
        />
        <p className="text-center text-xs text-gray-500 mt-4">Revenue contribution by client (SAR)</p>
    </ReportContainer>
);

export const PackagingReport: React.FC = () => (
    <ReportContainer title="Packaging Material Usage">
        <SimpleLineChart data={[500, 480, 520, 600, 550, 700, 680]} color="#f97316" />
        <div className="flex justify-between text-xs text-gray-400 mt-2">
            <span>Day 1</span><span>Day 2</span><span>Day 3</span><span>Day 4</span><span>Day 5</span><span>Day 6</span><span>Day 7</span>
        </div>
        <p className="text-center text-sm text-gray-600 mt-4 font-medium">Box Consumption Trend (Last 7 Days)</p>
    </ReportContainer>
);

export const ItemInventoryTotal: React.FC = () => {
    const [stats, setStats] = useState<any>(null);
    useEffect(() => { api.get('/dashboard/stats').then(setStats).catch(console.error); }, []);
    
    return (
        <ReportContainer title="Total Inventory Valuation">
            <div className="p-6 bg-purple-50 rounded-lg mb-6 flex justify-between items-center">
                <div>
                    <h3 className="text-lg font-semibold text-purple-900">Total Stock Items</h3>
                    <p className="text-3xl font-bold text-purple-700">{stats?.inventory?.total_stock?.toLocaleString() || '12,450'} Units</p>
                </div>
                <Package size={48} className="text-purple-300" />
            </div>
            
            <h3 className="text-sm font-bold text-gray-700 mb-4">Value by Category (SAR)</h3>
            <SimpleBarChart 
                data={[450000, 320000, 150000, 80000]} 
                labels={['Electronics', 'Fashion', 'Home', 'Toys']} 
                color="bg-purple-500"
            />
        </ReportContainer>
    );
}

export const InboundRecord: React.FC = () => {
    const inboundData = [
        { id: 'PO-9001', supplier: 'Tech Distributor A', items: 1200, date: '2024-02-28', status: 'Completed' },
        { id: 'PO-9002', supplier: 'Fashion Import Co.', items: 500, date: '2024-02-27', status: 'Processing' },
        { id: 'PO-9003', supplier: 'Home Goods Ltd.', items: 300, date: '2024-02-26', status: 'Pending' },
    ];

    return (
        <ReportContainer title="Inbound Stock History">
            <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold">
                        <tr>
                            <th className="px-6 py-4">PO Number</th>
                            <th className="px-6 py-4">Supplier</th>
                            <th className="px-6 py-4">Items Received</th>
                            <th className="px-6 py-4">Date</th>
                            <th className="px-6 py-4">Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {inboundData.map((row, i) => (
                            <tr key={i}>
                                <td className="px-6 py-4 font-mono text-blue-600">{row.id}</td>
                                <td className="px-6 py-4">{row.supplier}</td>
                                <td className="px-6 py-4">{row.items}</td>
                                <td className="px-6 py-4">{row.date}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded text-xs ${row.status === 'Completed' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                                        {row.status}
                                    </span>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </ReportContainer>
    );
};

export const InventoryHistory: React.FC = () => <ReportContainer title="Stock Movement History"><SimpleLineChart data={[10, 45, 30, 60, 20, 55, 40]} color="#3b82f6" /><p className="text-center text-xs text-gray-500 mt-2">Daily Movement Volume</p></ReportContainer>;
export const DamageInventoryHistory: React.FC = () => <ReportContainer title="Damaged Inventory Log"><SimpleBarChart data={[2, 5, 1, 0, 3, 2, 4]} labels={['M','T','W','T','F','S','S']} color="bg-red-500" /><p className="text-center text-xs text-gray-500 mt-2">Damaged Items Reported (Weekly)</p></ReportContainer>;

export const StorageReport: React.FC = () => {
    return (
        <ReportContainer title="Storage Fee Calculation">
            <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="p-4 bg-gray-50 rounded-lg flex items-center justify-between">
                    <div>
                        <p className="text-xs text-gray-500">Total Pallets</p>
                        <p className="text-xl font-bold text-gray-800">120</p>
                    </div>
                    <Archive size={24} className="text-gray-400" />
                </div>
                <div className="p-4 bg-gray-50 rounded-lg flex items-center justify-between">
                    <div>
                        <p className="text-xs text-gray-500">Est. Monthly Fee</p>
                        <p className="text-xl font-bold text-blue-600">SAR 15,400</p>
                    </div>
                    <DollarSign size={24} className="text-blue-400" />
                </div>
            </div>
            
            <h4 className="font-semibold text-gray-700 mb-3">Client Breakdown</h4>
            <div className="space-y-3">
                {[
                    { client: 'TechStore', units: 50, cost: '6,000' },
                    { client: 'Beauty Box', units: 30, cost: '3,600' },
                    { client: 'Home Hub', units: 40, cost: '5,800' }
                ].map((c, i) => (
                    <div key={i} className="flex justify-between items-center p-3 border-b border-gray-100 last:border-0">
                        <span className="font-medium text-gray-800">{c.client}</span>
                        <div className="text-right">
                            <p className="text-sm font-bold">{c.cost} SAR</p>
                            <p className="text-xs text-gray-500">{c.units} Pallets</p>
                        </div>
                    </div>
                ))}
            </div>
        </ReportContainer>
    );
};

export const BulkShipmentReport: React.FC = () => <ReportContainer title="Bulk Shipment Performance"><SimpleLineChart data={[100, 200, 150, 300, 250]} color="#10b981" /><p className="text-center text-xs text-gray-500 mt-2">Batch Processing Speed (Orders/Hour)</p></ReportContainer>;

function DollarSign(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg> }
