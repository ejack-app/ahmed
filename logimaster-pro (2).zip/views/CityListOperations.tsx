import React from 'react';
import { Building, Search, MapPin, Edit } from 'lucide-react';

const Header: React.FC<{ title: string; description: string }> = ({ title, description }) => (
  <div className="mb-6">
    <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
    <p className="text-sm text-gray-500">{description}</p>
  </div>
);

export const CityListView: React.FC = () => {
    const cities = [
        { name: 'Riyadh', code: 'RUH', region: 'Central', status: 'Active' },
        { name: 'Jeddah', code: 'JED', region: 'Western', status: 'Active' },
        { name: 'Dammam', code: 'DMM', region: 'Eastern', status: 'Active' },
        { name: 'Abha', code: 'AHB', region: 'Southern', status: 'Inactive' },
    ];

    return (
        <div className="max-w-5xl mx-auto">
            <Header title="City Management" description="Supported cities for delivery operations." />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search cities..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm font-medium">
                        + Add City
                    </button>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">City Name</th>
                            <th className="px-6 py-4">Code</th>
                            <th className="px-6 py-4">Region</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {cities.map((city, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-medium text-gray-900 flex items-center gap-2">
                                    <Building size={16} className="text-gray-400" />
                                    {city.name}
                                </td>
                                <td className="px-6 py-4 font-mono">{city.code}</td>
                                <td className="px-6 py-4">{city.region}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${city.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                                        {city.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-blue-600 hover:text-blue-800"><Edit size={16} /></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};