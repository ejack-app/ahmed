import React, { useState } from 'react';
import { Truck, Save, FileCheck, Globe, Clock, ShieldCheck } from 'lucide-react';

export const CourierCompanyDetails: React.FC = () => {
  const [formData, setFormData] = useState({
    courierName: 'LogiMaster Express',
    licenseNumber: 'L-882190-XA',
    fleetSize: '150+',
    serviceLevel: 'Express Delivery (Same Day)',
    operatingCities: 'Riyadh, Jeddah, Dammam, Mecca, Medina',
    trackingUrlPrefix: 'https://track.logimaster.sa/order/',
    supportEmail: 'support@logimaster.sa',
    defaultCurrency: 'SAR',
    citcLicense: 'CITC-2024-001',
    insurancePolicy: 'Allianz - Full Coverage'
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="max-w-5xl mx-auto pb-10">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Courier Operation Details</h2>
          <p className="text-sm text-gray-500">Manage your courier fleet identity and operational parameters.</p>
        </div>
        <button className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2 font-medium shadow-sm transition-colors">
          <Save size={18} /> Save Settings
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Operational Info */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
           <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2 pb-4 border-b border-gray-100">
               <Truck size={20} className="text-blue-600" /> Operational Identity
           </h3>
           <div className="space-y-4">
              <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Courier Display Name</label>
                  <input 
                      type="text" 
                      name="courierName" 
                      value={formData.courierName}
                      onChange={handleChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                  />
                  <p className="text-xs text-gray-400 mt-1">This name appears on shipping labels and customer tracking pages.</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                  <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1.5">License Number</label>
                      <input 
                          type="text" 
                          name="licenseNumber"
                          value={formData.licenseNumber}
                          onChange={handleChange} 
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                  </div>
                   <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1.5">CITC License</label>
                      <input 
                          type="text" 
                          name="citcLicense"
                          value={formData.citcLicense}
                          onChange={handleChange} 
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                  </div>
              </div>

               <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Fleet Size</label>
                  <select 
                      name="fleetSize"
                      value={formData.fleetSize}
                      onChange={handleChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                      <option>1-10 Vehicles</option>
                      <option>11-50 Vehicles</option>
                      <option>51-150 Vehicles</option>
                      <option>150+ Vehicles</option>
                  </select>
              </div>
           </div>
        </div>

        {/* Service Configuration */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2 pb-4 border-b border-gray-100">
               <Clock size={20} className="text-blue-600" /> Service Configuration
           </h3>
           <div className="space-y-4">
               <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Default Service Level</label>
                   <input 
                      type="text" 
                      name="serviceLevel"
                      value={formData.serviceLevel}
                      onChange={handleChange} 
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  />
               </div>
               
               <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Operating Cities</label>
                  <textarea 
                      name="operatingCities"
                      rows={3}
                      value={formData.operatingCities}
                      onChange={handleChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                  />
               </div>

                <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg border border-blue-100">
                    <ShieldCheck className="text-blue-600 flex-shrink-0" size={24} />
                    <div>
                        <p className="text-sm font-semibold text-blue-900">Insurance Policy Active</p>
                        <p className="text-xs text-blue-700">{formData.insurancePolicy}</p>
                    </div>
                </div>
           </div>
        </div>

        {/* Technical Integration */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 md:col-span-2">
            <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2 pb-4 border-b border-gray-100">
               <Globe size={20} className="text-blue-600" /> Tracking & Integration
           </h3>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Tracking URL Prefix</label>
                  <div className="flex">
                      <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 text-sm">
                          https://
                      </span>
                      <input 
                          type="text" 
                          name="trackingUrlPrefix"
                          value={formData.trackingUrlPrefix.replace('https://', '')}
                          onChange={handleChange}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-r-lg focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                  </div>
               </div>
               <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Customer Support Email</label>
                  <input 
                      type="email" 
                      name="supportEmail"
                      value={formData.supportEmail}
                      onChange={handleChange}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  />
               </div>
           </div>
        </div>

      </div>
    </div>
  );
};