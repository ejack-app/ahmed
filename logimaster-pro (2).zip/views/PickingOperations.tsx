
import React, { useState } from 'react';
import { UserCheck, Search, Filter, PlayCircle, CheckSquare, Settings as SettingsIcon, CheckCircle } from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Single Pickup List
export const SinglePickupList: React.FC = () => {
    const [pickList, setPickList] = useState([
        { id: 'PICK-001', order: 'ORD-1029', items: 3, location: 'A-01-02', status: 'Pending' },
        { id: 'PICK-002', order: 'ORD-1030', items: 1, location: 'B-04-01', status: 'In Progress' },
        { id: 'PICK-003', order: 'ORD-1035', items: 5, location: 'A-02-05', status: 'Pending' },
    ]);

    const handleAction = (id: string, currentStatus: string) => {
        setPickList(prev => prev.map(p => {
            if(p.id === id) {
                return { ...p, status: currentStatus === 'Pending' ? 'In Progress' : 'Completed' };
            }
            return p;
        }));
    };

    return (
        <div>
            <Header title="Single Picking List" description="Individual order picking tasks." />
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                     <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search Pick ID or Order..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Pick ID</th>
                            <th className="px-6 py-4">Order ID</th>
                            <th className="px-6 py-4">Items</th>
                            <th className="px-6 py-4">Zone/Location</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {pickList.filter(p => p.status !== 'Completed').map((pick, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono font-medium text-blue-600">{pick.id}</td>
                                <td className="px-6 py-4">{pick.order}</td>
                                <td className="px-6 py-4">{pick.items}</td>
                                <td className="px-6 py-4">{pick.location}</td>
                                <td className="px-6 py-4">
                                     <span className={`px-2 py-1 rounded-full text-xs font-medium 
                                        ${pick.status === 'In Progress' ? 'bg-yellow-100 text-yellow-700' : 'bg-gray-100 text-gray-700'}`}>
                                        {pick.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button 
                                        onClick={() => handleAction(pick.id, pick.status)}
                                        className={`font-medium flex items-center justify-center gap-1 w-full px-3 py-1 rounded-lg border
                                            ${pick.status === 'In Progress' ? 'bg-green-50 text-green-700 border-green-200' : 'bg-blue-50 text-blue-700 border-blue-200'}`}
                                    >
                                        {pick.status === 'Pending' ? <PlayCircle size={16} /> : <CheckCircle size={16} />}
                                        {pick.status === 'Pending' ? 'Start' : 'Finish'}
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
             </div>
        </div>
    );
};

// 2. Batch Pickup List
export const BatchPickupList: React.FC = () => {
    return (
        <div>
            <Header title="Batch Picking" description="Grouped picking tasks for efficiency." />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[1, 2, 3].map(i => (
                    <div key={i} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:border-blue-500 transition-colors cursor-pointer group">
                        <div className="flex justify-between items-start mb-4">
                            <div>
                                <h3 className="font-bold text-gray-900 text-lg">Batch #{202400 + i}</h3>
                                <p className="text-sm text-gray-500">Zone A • 12 Orders</p>
                            </div>
                            <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs font-bold">Ready</span>
                        </div>
                        <div className="space-y-2 mb-6">
                            <div className="flex justify-between text-sm text-gray-600">
                                <span>Total Items:</span>
                                <span className="font-medium">45 Units</span>
                            </div>
                             <div className="flex justify-between text-sm text-gray-600">
                                <span>Stops:</span>
                                <span className="font-medium">8 Locations</span>
                            </div>
                        </div>
                        <button className="w-full py-2 bg-gray-100 text-gray-700 group-hover:bg-blue-600 group-hover:text-white rounded-lg font-medium transition-colors">
                            Assign to Me
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

// 3. Pickup Completed List
export const PickupCompletedList: React.FC = () => {
     return (
        <div>
            <Header title="Completed Picks" description="History of completed picking tasks." />
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Pick ID</th>
                            <th className="px-6 py-4">Type</th>
                            <th className="px-6 py-4">Picker</th>
                            <th className="px-6 py-4">Completion Time</th>
                            <th className="px-6 py-4">Items Picked</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        <tr className="hover:bg-gray-50">
                            <td className="px-6 py-4 font-mono text-green-600">PICK-001</td>
                            <td className="px-6 py-4">Single</td>
                            <td className="px-6 py-4">John Doe</td>
                            <td className="px-6 py-4">Today, 10:30 AM</td>
                            <td className="px-6 py-4">3/3</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 4. Picker Settings
export const PickerSettings: React.FC = () => {
    return (
        <div className="max-w-2xl mx-auto pb-10">
            <Header title="Picker Settings" description="Configure picking rules and assignments." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 space-y-6">
                <div>
                    <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                        <SettingsIcon size={18} /> General Preferences
                    </h3>
                    <div className="space-y-3">
                         <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                            <div>
                                <p className="text-sm font-medium text-gray-900">Auto-Assign Batches</p>
                                <p className="text-xs text-gray-500">Automatically assign next batch to idle pickers.</p>
                            </div>
                             <div className="w-10 h-5 bg-green-500 rounded-full relative cursor-pointer">
                                <div className="w-5 h-5 bg-white rounded-full shadow absolute right-0"></div>
                            </div>
                        </div>
                        <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                            <div>
                                <p className="text-sm font-medium text-gray-900">Scanning Requirement</p>
                                <p className="text-xs text-gray-500">Require scanning item barcode to confirm pick.</p>
                            </div>
                             <div className="w-10 h-5 bg-green-500 rounded-full relative cursor-pointer">
                                <div className="w-5 h-5 bg-white rounded-full shadow absolute right-0"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div>
                     <h3 className="font-semibold text-gray-900 mb-4">Batching Rules</h3>
                     <div className="grid grid-cols-2 gap-4">
                         <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Max Items per Batch</label>
                            <input type="number" className="w-full px-4 py-2 border border-gray-300 rounded-lg" defaultValue={50} />
                         </div>
                         <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Max Orders per Batch</label>
                            <input type="number" className="w-full px-4 py-2 border border-gray-300 rounded-lg" defaultValue={20} />
                         </div>
                     </div>
                </div>

                <div className="pt-4 border-t border-gray-100 flex justify-end">
                    <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Save Settings</button>
                </div>
            </div>
        </div>
    );
};
