
import React, { useState, useEffect } from 'react';
import { 
  ArrowDownCircle, Plus, Search, Filter, Printer, FileText, 
  MoreHorizontal, Eye, RefreshCw, Barcode, MapPin, Truck, Loader 
} from 'lucide-react';
import { api } from '../utils/api';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Bulk Pickup Update
export const BulkPickupUpdate: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Bulk Pickup Update" description="Update status for multiple pickup requests at once." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">AWB Numbers</label>
                        <textarea rows={6} className="w-full px-4 py-3 border border-gray-300 rounded-lg font-mono text-sm" placeholder="Enter AWB numbers, one per line..."></textarea>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">New Status</label>
                            <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                                <option>Pickup Collected</option>
                                <option>Rescheduled</option>
                                <option>Failed - Customer Unavailable</option>
                                <option>Failed - Shop Closed</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Comment</label>
                            <textarea rows={1} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg resize-none" placeholder="Internal note..."></textarea>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Proof of Pickup (Image)</label>
                            <div className="border border-dashed border-gray-300 rounded-lg p-4 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-gray-50">
                                <p className="text-sm text-blue-600 font-medium">Select File</p>
                                <p className="text-xs text-gray-400 mt-1">or drag and drop</p>
                            </div>
                        </div>
                    </div>

                    <div className="flex justify-end pt-4 border-t border-gray-100">
                        <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Update Pickups</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

// 2. Add Pickup Sheet
export const AddPickupSheet: React.FC = () => {
    return (
        <div className="max-w-5xl mx-auto pb-10">
            <Header title="Add Pickup Sheet" description="Generate a new manifest for collecting shipments." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
                        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                            <option value="">Select Country...</option>
                            <option value="SA">Saudi Arabia</option>
                            <option value="AE">UAE</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                            <option value="">Select City...</option>
                            <option value="Riyadh">Riyadh</option>
                            <option value="Jeddah">Jeddah</option>
                        </select>
                    </div>
                </div>
                <div className="flex justify-end mb-6">
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium">Get Shipments</button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-gray-100 pt-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Route Code</label>
                        <div className="flex gap-2">
                            <select className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm">
                                <option value="">Select Route...</option>
                                <option value="Riyadh North">Riyadh North</option>
                            </select>
                            <button className="px-3 py-2 bg-gray-100 text-gray-600 rounded-lg border border-gray-300 text-xs font-medium">+ New</button>
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Assign Courier</label>
                        <div className="flex gap-2">
                            <select className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm">
                                <option value="">Select Courier...</option>
                                <option value="Ahmed Ali (Driver)">Ahmed Ali (Driver)</option>
                            </select>
                            <button className="px-3 py-2 bg-gray-100 text-gray-600 rounded-lg border border-gray-300 text-xs font-medium">+ Add</button>
                        </div>
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
                    <h3 className="font-semibold text-gray-800">Available Shipments</h3>
                    <span className="text-xs text-gray-500">0 Selected</span>
                </div>
                <div className="p-8 text-center text-gray-400">
                    <Truck size={32} className="mx-auto mb-2 opacity-30" />
                    <p>No shipments available for the selected criteria.</p>
                </div>
            </div>
            
            <div className="mt-6 flex justify-end">
                <button className="px-6 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium">Create Pickup Sheet</button>
            </div>
        </div>
    );
};

// 3. Pickup List
export const PickupList: React.FC = () => {
    const [pickups, setPickups] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchPickups = async () => {
            try {
                // Assuming an endpoint exists or simulating one
                // const data = await api.get('/pickups');
                // setPickups(data);
                
                // Mocking data for now as specific pickup endpoint might not be in the minimal backend provided
                setTimeout(() => {
                    setPickups([
                        { id: 'PICK-1001', date: '2024-02-28', city: 'Riyadh', route: 'RUH-N', driver: 'Ahmed Ali', status: 'Pending' },
                        { id: 'PICK-1002', date: '2024-02-28', city: 'Jeddah', route: 'JED-W', driver: 'Omar F.', status: 'Completed' },
                        { id: 'PICK-1003', date: '2024-02-27', city: 'Dammam', route: 'DMM-C', driver: 'Fahad K.', status: 'In Progress' },
                    ]);
                    setLoading(false);
                }, 800);
            } catch (e) {
                console.error(e);
                setLoading(false);
            }
        };
        fetchPickups();
    }, []);

    return (
        <div>
            <Header 
                title="Pickup List" 
                description="View and manage generated pickup sheets." 
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700 font-medium">
                        <Plus size={16} /> New Pickup
                    </button>
                }
            />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex flex-col md:flex-row justify-between gap-4">
                    <div className="flex gap-4 flex-1">
                        <input type="text" placeholder="Scan Barcode..." className="flex-1 px-4 py-2 border border-gray-300 rounded-lg outline-none" />
                        <input type="text" placeholder="Search Pickup ID..." className="flex-1 px-4 py-2 border border-gray-300 rounded-lg outline-none" />
                        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg">Search</button>
                    </div>
                </div>
                
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">#</th>
                            <th className="px-6 py-4">Unique ID</th>
                            <th className="px-6 py-4">Date</th>
                            <th className="px-6 py-4">City</th>
                            <th className="px-6 py-4">Route</th>
                            <th className="px-6 py-4">Driver</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {loading ? (
                            <tr><td colSpan={8} className="p-6 text-center"><Loader className="animate-spin mx-auto"/></td></tr>
                        ) : pickups.length === 0 ? (
                            <tr><td colSpan={8} className="p-6 text-center text-gray-400">No pickups found.</td></tr>
                        ) : (
                            pickups.map((p, i) => (
                                <tr key={i} className="hover:bg-gray-50">
                                    <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                    <td className="px-6 py-4 font-mono font-medium text-blue-600">{p.id}</td>
                                    <td className="px-6 py-4">{p.date}</td>
                                    <td className="px-6 py-4">{p.city}</td>
                                    <td className="px-6 py-4"><span className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs font-mono">{p.route}</span></td>
                                    <td className="px-6 py-4">{p.driver}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 rounded-full text-xs font-medium 
                                            ${p.status === 'Completed' ? 'bg-green-100 text-green-700' : 
                                            p.status === 'In Progress' ? 'bg-blue-100 text-blue-700' : 
                                            'bg-yellow-100 text-yellow-700'}`}>
                                            {p.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <button className="text-gray-400 hover:text-gray-600">
                                            <MoreHorizontal size={20} />
                                        </button>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 4. Scan New Pickup
export const ScanNewPickup: React.FC = () => {
    return (
        <div className="max-w-6xl mx-auto pb-10">
            <Header title="Scan New Pickup" description="Quickly create a pickup sheet by scanning." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
                        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                            <option>Saudi Arabia</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                            <option>Select City...</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Route</label>
                        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                            <option>Select Route...</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Courier</label>
                        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                            <option>Select Courier...</option>
                        </select>
                    </div>
                </div>
                <div className="mt-4 flex gap-4 items-end">
                    <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Scan Barcode</label>
                        <div className="relative">
                            <Barcode className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                            <input type="text" className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500" placeholder="Scan AWB..." autoFocus />
                        </div>
                    </div>
                    <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Make Pickup Sheet</button>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Sr.No.</th>
                            <th className="px-6 py-4">AWB No.</th>
                            <th className="px-6 py-4">Shipper</th>
                            <th className="px-6 py-4">Pieces</th>
                            <th className="px-6 py-4">Weight</th>
                            <th className="px-6 py-4">Origin</th>
                            <th className="px-6 py-4">Destination</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        <tr>
                            <td colSpan={7} className="px-6 py-8 text-center text-gray-400">
                                Scan items to add them to the list.
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 5. Show Pickup Detail
export const ShowPickupDetail: React.FC = () => {
    // Mock Data
    const details = [
        { awb: 'AWB-882190', product: 'Parcel', address: 'King Fahd Rd, Riyadh', messenger: 'Ahmed Ali', route: 'RUH-N', status: 'Pending' },
        { awb: 'AWB-882191', product: 'Document', address: 'Olaya St, Riyadh', messenger: 'Ahmed Ali', route: 'RUH-N', status: 'Collected' },
    ];

    return (
        <div>
            <Header 
                title="Pickup Sheet Details" 
                description="Details for Pickup Sheet #PICK-1001"
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700 font-medium">
                        <Printer size={16} /> Print Sheet
                    </button>
                }
            />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">#</th>
                            <th className="px-6 py-4">AWB No.</th>
                            <th className="px-6 py-4">Product Type</th>
                            <th className="px-6 py-4">Address</th>
                            <th className="px-6 py-4">Messenger</th>
                            <th className="px-6 py-4">Route Code</th>
                            <th className="px-6 py-4">Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {details.map((d, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                <td className="px-6 py-4 font-mono text-blue-600">{d.awb}</td>
                                <td className="px-6 py-4">{d.product}</td>
                                <td className="px-6 py-4 flex items-center gap-1"><MapPin size={14} className="text-gray-400" /> {d.address}</td>
                                <td className="px-6 py-4">{d.messenger}</td>
                                <td className="px-6 py-4"><span className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs font-mono">{d.route}</span></td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium 
                                        ${d.status === 'Collected' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                                        {d.status}
                                    </span>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
