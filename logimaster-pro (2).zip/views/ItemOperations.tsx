import React from 'react';
import { 
  Box, Save, Upload, Search, Filter, Printer, FileText, 
  Edit, Trash2, Barcode 
} from 'lucide-react';

// Reusable Header
const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Add Item
export const AddItem: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Add New Item" description="Register a new product SKU into the master catalog." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="md:col-span-2">
                         <h3 className="text-md font-semibold text-gray-800 mb-4 border-b pb-2">Basic Information</h3>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Item SKU</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. PRD-1001" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Item Name</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. Leather Wallet" />
                    </div>
                    <div>
                         <label className="block text-sm font-medium text-gray-700 mb-1.5">Category</label>
                         <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                             <option>Fashion</option>
                             <option>Electronics</option>
                             <option>Home</option>
                         </select>
                    </div>
                    <div>
                         <label className="block text-sm font-medium text-gray-700 mb-1.5">Client Owner</label>
                         <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                             <option>LogiMaster (Internal)</option>
                             <option>Client A</option>
                             <option>Client B</option>
                         </select>
                    </div>
                    
                    <div className="md:col-span-2 mt-4">
                         <h3 className="text-md font-semibold text-gray-800 mb-4 border-b pb-2">Dimensions & Weight</h3>
                    </div>
                    <div className="grid grid-cols-3 gap-4 md:col-span-2">
                         <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Length (cm)</label>
                            <input type="number" className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" placeholder="0.0" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Width (cm)</label>
                            <input type="number" className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" placeholder="0.0" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Height (cm)</label>
                            <input type="number" className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" placeholder="0.0" />
                        </div>
                    </div>
                    <div>
                         <label className="block text-sm font-medium text-gray-700 mb-1.5">Weight (kg)</label>
                         <input type="number" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="0.0" />
                    </div>

                     <div className="md:col-span-2 mt-4">
                         <h3 className="text-md font-semibold text-gray-800 mb-4 border-b pb-2">Additional Details</h3>
                    </div>
                    <div className="md:col-span-2">
                         <label className="block text-sm font-medium text-gray-700 mb-1.5">Description</label>
                         <textarea rows={3} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg resize-none"></textarea>
                    </div>
                </div>

                <div className="mt-8 flex justify-end gap-3">
                    <button className="px-5 py-2.5 text-gray-700 hover:bg-gray-100 rounded-lg font-medium">Cancel</button>
                    <button className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                        <Save size={18} /> Save Item Master
                    </button>
                </div>
            </div>
        </div>
    );
};

// 2. View All Items
export const ViewAllItems: React.FC = () => {
    // Mock data
    const items = [
        { sku: 'PRD-001', name: 'Running Shoes', category: 'Fashion', dimensions: '30x20x10', weight: '0.8 kg', stock: 150 },
        { sku: 'ELEC-992', name: 'Bluetooth Speaker', category: 'Electronics', dimensions: '15x15x10', weight: '0.5 kg', stock: 42 },
        { sku: 'HOME-102', name: 'Ceramic Vase', category: 'Home', dimensions: '40x20x20', weight: '1.2 kg', stock: 12 },
        { sku: 'FASH-221', name: 'Cotton T-Shirt', category: 'Fashion', dimensions: '30x25x2', weight: '0.2 kg', stock: 500 },
        { sku: 'PRD-005', name: 'Wrist Watch', category: 'Fashion', dimensions: '10x10x5', weight: '0.3 kg', stock: 88 },
    ];

    return (
        <div>
            <Header 
                title="All Items" 
                description="Master catalog of all registered products."
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Box size={16} /> Add Item
                    </button>
                }
            />
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search by SKU or Name..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                    <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 flex items-center gap-2">
                        <Filter size={16} /> Filter
                    </button>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">SKU</th>
                            <th className="px-6 py-4">Product Name</th>
                            <th className="px-6 py-4">Category</th>
                            <th className="px-6 py-4">Dimensions</th>
                            <th className="px-6 py-4">Weight</th>
                            <th className="px-6 py-4">Total Stock</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {items.map((item, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono font-medium text-blue-600">{item.sku}</td>
                                <td className="px-6 py-4 font-medium text-gray-900">{item.name}</td>
                                <td className="px-6 py-4">{item.category}</td>
                                <td className="px-6 py-4">{item.dimensions}</td>
                                <td className="px-6 py-4">{item.weight}</td>
                                <td className="px-6 py-4">{item.stock}</td>
                                <td className="px-6 py-4 text-right flex justify-end gap-2">
                                    <button className="p-1 hover:text-blue-600 text-gray-400"><Edit size={16} /></button>
                                    <button className="p-1 hover:text-red-600 text-gray-400"><Trash2 size={16} /></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
             </div>
        </div>
    );
};

// 3. Bulk SKU Print
export const BulkSkuPrint: React.FC = () => {
    return (
        <div>
            <Header 
                title="Bulk SKU Print" 
                description="Generate and print barcode labels for multiple items."
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Printer size={16} /> Print Selected
                    </button>
                }
            />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                <div className="flex gap-4 items-end">
                    <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Enter SKUs</label>
                         <textarea rows={3} className="w-full px-4 py-2 border border-gray-300 rounded-lg font-mono text-sm" placeholder="Paste SKUs here, one per line..."></textarea>
                    </div>
                    <div className="w-48">
                         <label className="block text-sm font-medium text-gray-700 mb-1">Label Quantity (Per SKU)</label>
                         <input type="number" className="w-full px-4 py-2 border border-gray-300 rounded-lg" defaultValue={1} />
                    </div>
                     <div className="w-48">
                         <label className="block text-sm font-medium text-gray-700 mb-1">Barcode Format</label>
                         <select className="w-full px-4 py-2 border border-gray-300 rounded-lg">
                             <option>Code 128</option>
                             <option>EAN-13</option>
                             <option>QR Code</option>
                         </select>
                    </div>
                </div>
                <div className="mt-4 flex justify-end">
                    <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 flex items-center gap-2">
                        <Barcode size={18} /> Preview Labels
                    </button>
                </div>
            </div>
            
            {/* Using ViewAllItems table as placeholder for selection list */}
            <ViewAllItems />
        </div>
    );
};

// 4. Bulk Item Update
export const BulkItemUpdate: React.FC = () => {
    return (
        <div className="max-w-3xl mx-auto pb-10">
            <Header title="Bulk Item Update" description="Update specific fields for multiple items at once." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="space-y-6">
                    <div>
                         <label className="block text-sm font-medium text-gray-700 mb-1">Step 1: Select Items by SKU</label>
                         <textarea rows={5} className="w-full px-4 py-2 border border-gray-300 rounded-lg font-mono text-sm" placeholder="Paste SKUs to update..."></textarea>
                    </div>
                    
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Step 2: Choose Field to Update</label>
                        <div className="p-4 border border-gray-200 rounded-lg bg-gray-50 space-y-4">
                            <select className="w-full px-4 py-2 border border-gray-300 rounded-lg">
                                <option>Update Category</option>
                                <option>Update Client Owner</option>
                                <option>Update Status (Active/Inactive)</option>
                            </select>
                            
                            {/* Dynamic Input based on selection */}
                            <input type="text" className="w-full px-4 py-2 border border-gray-300 rounded-lg" placeholder="Enter new value..." />
                        </div>
                    </div>

                    <button className="w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
                        Apply Bulk Update
                    </button>
                </div>
            </div>
        </div>
    );
};

// 5. Import Items
export const ImportItems: React.FC = () => {
    return (
        <div className="max-w-3xl mx-auto pb-10">
             <Header title="Import Items" description="Upload a CSV file to create or update item master data." />
             
             <div className="bg-white p-10 rounded-xl shadow-sm border border-dashed border-gray-300 flex flex-col items-center justify-center text-center">
                 <Upload size={48} className="text-gray-300 mb-4" />
                 <h3 className="text-lg font-medium text-gray-900 mb-2">Upload Item Master File</h3>
                 <p className="text-sm text-gray-500 mb-6 max-w-md">
                     Supported columns: SKU, Name, Description, Category, Length, Width, Height, Weight.
                 </p>
                 <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                     Browse Files
                 </button>
                 <div className="mt-8 flex gap-4 text-sm">
                     <button className="text-blue-600 hover:underline flex items-center gap-1">
                         <FileText size={14} /> Download CSV Template
                     </button>
                 </div>
             </div>
        </div>
    );
};