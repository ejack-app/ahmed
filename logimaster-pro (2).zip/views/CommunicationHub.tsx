
import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, Mail, Send, Phone, User, QrCode, Smartphone, 
  Facebook, Search, MoreHorizontal, Paperclip, Mic, PlayCircle, 
  PauseCircle, Headphones, ArrowRightLeft, Globe, Bot, Settings, Users, FileText,
  PhoneCall, Voicemail, Activity, Server, Cpu, Radio, ShieldCheck, PhoneForwarded,
  Layout, Save, Power, Wifi, CheckCircle, X, Loader, Zap, Sliders, Lock, Bell,
  Database, RefreshCw, AlertTriangle, ToggleLeft, ToggleRight, List, Workflow,
  MicOff, Volume2, Grid, StopCircle, Clock, ChevronDown, ChevronRight
} from 'lucide-react';
import { api } from '../utils/api';

// --- Shared Components ---

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

const MessagingView: React.FC = () => {
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);

  // Fetch Messages
  useEffect(() => {
      const fetchMsgs = async () => {
          try {
              const data = await api.get('/messages');
              setMessages(data.reverse()); // Show newest at bottom
          } catch(e) { console.error(e); }
          finally { setLoading(false); }
      };
      fetchMsgs();
      // Poll for new messages every 10s
      const interval = setInterval(fetchMsgs, 10000);
      return () => clearInterval(interval);
  }, []);

  const handleSend = async () => {
      if(!input.trim()) return;
      try {
          await api.post('/messages', {
              sender_id: 1, // Mock current user
              customer_name: 'Current User',
              platform: 'Web',
              content: input
          });
          setInput('');
          // Optimistically update
          setMessages(prev => [...prev, { content: input, status: 'Sent', platform: 'Web', created_at: new Date().toISOString() }]);
      } catch(e) { console.error(e); }
  };

  return (
    <div className="flex h-full bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      {/* Sidebar */}
      <div className="w-80 border-r border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
            <input type="text" placeholder="Search messages..." className="w-full pl-9 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm outline-none" />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
            <div className="p-4 border-b border-gray-100 bg-blue-50 cursor-pointer flex gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold text-sm">G</div>
              <div className="flex-1 overflow-hidden">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-semibold text-gray-900 text-sm">General Channel</span>
                  <span className="text-xs text-gray-400">Now</span>
                </div>
                <p className="text-xs text-gray-500 truncate">System wide messages...</p>
              </div>
            </div>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col bg-gray-50">
        <div className="p-4 bg-white border-b border-gray-200 flex justify-between items-center">
            <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold">G</div>
                <div>
                    <h4 className="font-bold text-gray-900">General Channel</h4>
                    <p className="text-xs text-green-600 flex items-center gap-1"><span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span> Live</p>
                </div>
            </div>
        </div>
        
        <div className="flex-1 p-6 overflow-y-auto space-y-4 flex flex-col">
            {loading ? <Loader className="animate-spin mx-auto text-gray-400"/> : messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.platform === 'Web' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`p-3 rounded-xl max-w-[70%] text-sm shadow-sm ${msg.platform === 'Web' ? 'bg-blue-600 text-white rounded-br-none' : 'bg-white border border-gray-200 text-gray-800 rounded-bl-none'}`}>
                        {msg.content}
                        <div className={`text-[10px] mt-1 text-right ${msg.platform === 'Web' ? 'text-blue-200' : 'text-gray-400'}`}>
                            {new Date(msg.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </div>
                    </div>
                </div>
            ))}
        </div>

        <div className="p-4 bg-white border-t border-gray-200">
            <div className="flex gap-2 items-center">
                <button className="text-gray-400 hover:text-gray-600"><Paperclip size={20} /></button>
                <input 
                    type="text" 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Type a message..." 
                    className="flex-1 bg-gray-50 border border-gray-200 rounded-full px-4 py-2 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500" 
                />
                <button onClick={handleSend} className="bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700"><Send size={18} /></button>
            </div>
        </div>
      </div>
    </div>
  );
};

export const CommunicationHub: React.FC = () => {
  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col">
        <Header 
            title="Unified Communication Hub" 
            description="Manage all interactions from a single dashboard." 
        />
        <MessagingView />
    </div>
  );
};
