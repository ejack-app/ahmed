import React, { useState } from 'react';
import { RefreshCw, CheckCircle, AlertTriangle, FileText, ArrowRight } from 'lucide-react';

const Header: React.FC<{ title: string; description: string }> = ({ title, description }) => (
  <div className="mb-6">
    <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
    <p className="text-sm text-gray-500">{description}</p>
  </div>
);

export const BulkUpdate: React.FC = () => {
  const [awbNumbers, setAwbNumbers] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [comment, setComment] = useState('');
  const [subCategory, setSubCategory] = useState('');
  const [shelveNo, setShelveNo] = useState('');
  const [driverId, setDriverId] = useState('');
  const [drsId, setDrsId] = useState('');

  // Mock Data
  const statuses = [
    { code: 'OFD', label: 'Out for Delivery' },
    { code: 'DELIVERED', label: 'Delivered' },
    { code: 'SHELVED', label: 'Shelved / In Warehouse' },
    { code: 'ON_HOLD', label: 'On Hold' },
    { code: 'RETURNED', label: 'Returned' },
  ];

  const subCategories = [
    { code: 'WRONG_ADDRESS', label: 'Wrong Address' },
    { code: 'CUSTOMER_REFUSED', label: 'Customer Refused' },
    { code: 'NO_RESPONSE', label: 'No Response' },
  ];

  const shelves = ['A-01-01', 'A-01-02', 'B-02-05', 'C-05-09'];
  const drivers = [
    { id: '101', name: 'Ahmed Ali (RUH-109)' },
    { id: '102', name: 'Mohammed S. (JED-002)' },
  ];
  const drsList = ['DRS-2024-001', 'DRS-2024-002'];

  const handleSubmit = () => {
    // Logic to handle bulk update
    console.log({
      awbNumbers: awbNumbers.split('\n'),
      status: selectedStatus,
      comment,
      subCategory,
      shelveNo,
      driverId,
      drsId
    });
    alert('Bulk update submitted successfully (Mock)');
  };

  return (
    <div className="max-w-5xl mx-auto pb-10">
      <Header title="Bulk Shipment Update" description="Update status, driver, or location for multiple shipments at once." />

      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
        
        {/* Error / Success Message Placeholder */}
        <div className="mb-6 hidden">
            <div className="p-4 bg-green-50 border border-green-200 text-green-700 rounded-lg flex items-center gap-2">
                <CheckCircle size={18} /> Successfully updated 15 orders.
            </div>
            <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg flex items-center gap-2 mt-2">
                <AlertTriangle size={18} /> Error updating AWB: 123456 (Invalid ID)
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            {/* Left Column: AWB Input */}
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">AWB Numbers</label>
                <textarea 
                    className="w-full h-80 px-4 py-3 border border-gray-300 rounded-lg font-mono text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                    placeholder="Enter AWB numbers here, one per line..."
                    value={awbNumbers}
                    onChange={(e) => setAwbNumbers(e.target.value)}
                ></textarea>
                <div className="mt-2 text-xs text-gray-500 flex justify-between">
                    <span>One tracking number per line</span>
                    <span>{awbNumbers.split('\n').filter(l => l.trim() !== '').length} Entries</span>
                </div>
            </div>

            {/* Right Column: Configuration */}
            <div className="space-y-6">
                
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">New Status</label>
                    <select 
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                        value={selectedStatus}
                        onChange={(e) => setSelectedStatus(e.target.value)}
                    >
                        <option value="">Select Status...</option>
                        {statuses.map(s => <option key={s.code} value={s.code}>{s.label}</option>)}
                    </select>
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Comment (Optional)</label>
                    <textarea 
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg resize-none"
                        rows={3}
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        placeholder="Add internal notes..."
                    ></textarea>
                </div>

                {/* Conditional Fields based on Status */}
                <div className="p-4 bg-gray-50 rounded-lg border border-gray-200 space-y-4">
                    
                    {/* Reason for On Hold / Returned */}
                    {(selectedStatus === 'ON_HOLD' || selectedStatus === 'RETURNED') && (
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Reason Code</label>
                            <select 
                                className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
                                value={subCategory}
                                onChange={(e) => setSubCategory(e.target.value)}
                            >
                                <option value="">Select Reason...</option>
                                {subCategories.map(c => <option key={c.code} value={c.code}>{c.label}</option>)}
                            </select>
                        </div>
                    )}

                    {/* Shelve for Shelved */}
                    {selectedStatus === 'SHELVED' && (
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Shelf Location</label>
                            <select 
                                className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
                                value={shelveNo}
                                onChange={(e) => setShelveNo(e.target.value)}
                            >
                                <option value="">Select Shelf...</option>
                                {shelves.map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                        </div>
                    )}

                    {/* Driver / Messenger for OFD */}
                    {selectedStatus === 'OFD' && (
                        <>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">Assign Driver / Messenger</label>
                                <select 
                                    className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
                                    value={driverId}
                                    onChange={(e) => setDriverId(e.target.value)}
                                >
                                    <option value="">Select Driver...</option>
                                    {drivers.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                                </select>
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">DRS Sheet (Optional)</label>
                                <select 
                                    className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
                                    value={drsId}
                                    onChange={(e) => setDrsId(e.target.value)}
                                >
                                    <option value="">Select DRS...</option>
                                    {drsList.map(d => <option key={d} value={d}>{d}</option>)}
                                </select>
                            </div>
                        </>
                    )}

                    {!selectedStatus && (
                        <p className="text-sm text-gray-400 text-center py-2">Select a status to view additional options.</p>
                    )}
                </div>

                <button 
                    onClick={handleSubmit}
                    className="w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center justify-center gap-2 shadow-sm transition-all"
                >
                    <RefreshCw size={18} /> Update Shipments
                </button>

            </div>
        </div>
      </div>
    </div>
  );
};