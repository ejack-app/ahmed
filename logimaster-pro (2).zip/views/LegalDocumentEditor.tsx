import React, { useState } from 'react';
import { Save, Eye, RotateCcw, FileText, CheckCircle } from 'lucide-react';

interface LegalDocumentEditorProps {
  title: string;
  defaultContent: string;
  lastUpdated: string;
}

export const LegalDocumentEditor: React.FC<LegalDocumentEditorProps> = ({ title, defaultContent, lastUpdated }) => {
  const [content, setContent] = useState(defaultContent);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    // Simulate save
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto pb-10">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
          <p className="text-sm text-gray-500">Last updated on <span className="font-medium text-gray-700">{lastUpdated}</span></p>
        </div>
        <div className="flex gap-2">
            <button className="px-4 py-2.5 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 flex items-center gap-2 font-medium">
                <Eye size={18} /> Preview
            </button>
            <button 
                onClick={handleSave}
                className={`px-5 py-2.5 text-white rounded-lg flex items-center gap-2 font-medium shadow-sm transition-all ${isSaved ? 'bg-green-600' : 'bg-blue-600 hover:bg-blue-700'}`}
            >
                {isSaved ? <CheckCircle size={18} /> : <Save size={18} />}
                {isSaved ? 'Published!' : 'Publish Changes'}
            </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col h-[600px]">
                {/* Mock Toolbar */}
                <div className="p-3 border-b border-gray-200 bg-gray-50 flex items-center gap-2 flex-wrap rounded-t-xl">
                    <select className="px-2 py-1 bg-white border border-gray-300 rounded text-sm text-gray-700 outline-none">
                        <option>Normal Text</option>
                        <option>Heading 1</option>
                        <option>Heading 2</option>
                    </select>
                    <div className="h-5 w-[1px] bg-gray-300 mx-1"></div>
                    <button className="p-1.5 hover:bg-gray-200 rounded text-gray-600 font-bold">B</button>
                    <button className="p-1.5 hover:bg-gray-200 rounded text-gray-600 italic">I</button>
                    <button className="p-1.5 hover:bg-gray-200 rounded text-gray-600 underline">U</button>
                    <div className="h-5 w-[1px] bg-gray-300 mx-1"></div>
                    <button className="p-1.5 hover:bg-gray-200 rounded text-gray-600">List</button>
                    <button className="p-1.5 hover:bg-gray-200 rounded text-gray-600">Link</button>
                </div>
                
                <textarea 
                    className="flex-1 w-full p-6 outline-none resize-none font-sans text-gray-700 leading-relaxed"
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="Enter your legal text here..."
                />
                
                <div className="p-3 border-t border-gray-200 bg-gray-50 text-xs text-gray-500 flex justify-between rounded-b-xl">
                    <span>{content.length} characters</span>
                    <span>HTML Mode</span>
                </div>
            </div>
          </div>

          <div className="lg:col-span-1 space-y-4">
              <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200">
                  <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                      <RotateCcw size={16} className="text-gray-500" /> Version History
                  </h4>
                  <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-600">v2.1 (Current)</span>
                          <span className="text-gray-400 text-xs">Today</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                          <span className="text-blue-600 hover:underline cursor-pointer">v2.0</span>
                          <span className="text-gray-400 text-xs">Oct 12, 2024</span>
                      </div>
                       <div className="flex items-center justify-between text-sm">
                          <span className="text-blue-600 hover:underline cursor-pointer">v1.5</span>
                          <span className="text-gray-400 text-xs">Jan 05, 2024</span>
                      </div>
                  </div>
              </div>

               <div className="bg-blue-50 p-5 rounded-xl border border-blue-100">
                  <div className="flex items-start gap-3">
                      <FileText className="text-blue-600 mt-1" size={20} />
                      <div>
                          <h4 className="font-semibold text-blue-900 text-sm mb-1">Legal Notice</h4>
                          <p className="text-xs text-blue-700 leading-snug">
                              Ensure your {title.toLowerCase()} complies with local regulations (e.g., KSA E-Commerce Law). Consult a legal expert before publishing.
                          </p>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};