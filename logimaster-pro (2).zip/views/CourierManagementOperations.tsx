
import React, { useState, useEffect } from 'react';
import { 
  UserPlus, Upload, Search, Filter, MoreHorizontal, MapPin, 
  User, CheckCircle, XCircle, FileText, Settings, Fuel, 
  Calendar, Camera, Eye, Trash2, Edit, Loader
} from 'lucide-react';
import { api } from '../utils/api';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Add Courier
export const AddCourier: React.FC = () => {
    const [formData, setFormData] = useState({
        full_name: '', email: '', phone: '', password: '', role_id: '3', branch_id: '1', status: 'Active'
    });

    const handleSubmit = async () => {
        try {
            await api.post('/users', formData); // Creating user with Role ID 3 (Driver)
            alert("Courier Added Successfully");
        } catch(e: any) {
            alert(e.message);
        }
    };

    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Add New Courier" description="Register a new driver or messenger to the system." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Courier Name <span className="text-red-500">*</span></label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="Full Name" onChange={e => setFormData({...formData, full_name: e.target.value})} />
                    </div>
                    
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Country <span className="text-red-500">*</span></label>
                        <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                            <option value="">Select Country...</option>
                            <option value="SA">Saudi Arabia</option>
                            <option value="AE">UAE</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">City <span className="text-red-500">*</span></label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="City" />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Mobile <span className="text-red-500">*</span></label>
                        <input type="tel" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="+966..." onChange={e => setFormData({...formData, phone: e.target.value})} />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Email <span className="text-red-500">*</span></label>
                        <input type="email" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="email@example.com" onChange={e => setFormData({...formData, email: e.target.value})} />
                    </div>
                    
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Password <span className="text-red-500">*</span></label>
                        <input type="password" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" onChange={e => setFormData({...formData, password: e.target.value})} />
                    </div>

                    <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Vehicle Number <span className="text-red-500">*</span></label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="Plate No." />
                    </div>
                </div>

                <div className="mt-8 flex justify-end gap-3">
                    <button className="px-5 py-2.5 text-gray-700 hover:bg-gray-100 rounded-lg font-medium">Cancel</button>
                    <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2" onClick={handleSubmit}>
                        <UserPlus size={18} /> Register Courier
                    </button>
                </div>
            </div>
        </div>
    );
};

// 2. Courier List
export const CourierList: React.FC<{ onViewDetails: () => void, onAssignRoute: () => void }> = ({ onViewDetails, onAssignRoute }) => {
    const [couriers, setCouriers] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchCouriers = async () => {
            try {
                const data = await api.get('/drivers');
                setCouriers(data);
            } catch(e) { console.error(e); }
            finally { setLoading(false); }
        };
        fetchCouriers();
    }, []);

    return (
        <div>
            <Header 
                title="Couriers List" 
                description="Manage all registered couriers and their status."
                action={
                    <div className="flex gap-2">
                        <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 flex items-center gap-2">
                            <Upload size={16} /> Import
                        </button>
                        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                            <UserPlus size={16} /> Add Courier
                        </button>
                    </div>
                }
            />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search Name, Code, Mobile..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                    <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 flex items-center gap-2">
                        <Filter size={16} /> Filter
                    </button>
                </div>
                
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">#</th>
                            <th className="px-6 py-4">Name</th>
                            <th className="px-6 py-4">Online</th>
                            <th className="px-6 py-4">Location</th>
                            <th className="px-6 py-4">Vehicle No</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {loading ? (
                            <tr><td colSpan={6} className="p-6 text-center"><Loader className="animate-spin mx-auto"/></td></tr>
                        ) : couriers.length === 0 ? (
                            <tr><td colSpan={6} className="p-6 text-center text-gray-400">No couriers found.</td></tr>
                        ) : (
                            couriers.map((c, i) => (
                                <tr key={i} className="hover:bg-gray-50">
                                    <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                    <td className="px-6 py-4 font-medium text-gray-900">{c.full_name}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 rounded text-xs font-bold ${c.is_online ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                                            {c.is_online ? 'Online' : 'Offline'}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-xs font-mono">{c.current_lat ? `${c.current_lat}, ${c.current_lng}` : 'N/A'}</td>
                                    <td className="px-6 py-4 font-mono">{c.plate_number || '-'}</td>
                                    <td className="px-6 py-4 text-right">
                                        <div className="flex justify-end gap-2">
                                            <button className="p-1 text-gray-400 hover:text-blue-600" title="Edit"><Edit size={16}/></button>
                                            <button onClick={onViewDetails} className="p-1 text-gray-400 hover:text-blue-600" title="View Details"><Eye size={16}/></button>
                                            <button onClick={onAssignRoute} className="p-1 text-gray-400 hover:text-blue-600" title="Assign Route"><MapPin size={16}/></button>
                                            <button className="p-1 text-gray-400 hover:text-red-600" title="Delete"><Trash2 size={16}/></button>
                                        </div>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 3. Courier Details
export const CourierDetails: React.FC = () => {
    return (
        <div className="max-w-5xl mx-auto pb-10">
            <Header title="Courier Details" description="View profile information for Ameen-Test." />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Basic Details */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <h3 className="font-semibold text-gray-900 mb-4 border-b pb-2">Basic Information</h3>
                    <div className="space-y-3">
                        <div className="flex justify-between">
                            <span className="text-gray-500 text-sm">Name:</span>
                            <span className="font-medium">Ameen-Test</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-gray-500 text-sm">Email:</span>
                            <span className="font-medium">ameen@example.com</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-gray-500 text-sm">Phone:</span>
                            <span className="font-medium">0551234567</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-gray-500 text-sm">Vehicle No:</span>
                            <span className="font-medium">1234 ABC</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-gray-500 text-sm">Join Date:</span>
                            <span className="font-medium">2023-01-15</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-gray-500 text-sm">City:</span>
                            <span className="font-medium">Riyadh</span>
                        </div>
                    </div>
                </div>

                {/* Other Details */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <h3 className="font-semibold text-gray-900 mb-4 border-b pb-2">Operational Details</h3>
                    <div className="space-y-3">
                        <div className="flex justify-between">
                            <span className="text-gray-500 text-sm">Messenger Code:</span>
                            <span className="font-medium bg-gray-100 px-2 rounded text-xs">RUH-109</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-gray-500 text-sm">Iqama ID:</span>
                            <span className="font-medium">2233445566</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-gray-500 text-sm">Vehicle Type:</span>
                            <span className="font-medium">Van</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-gray-500 text-sm">Supplier:</span>
                            <span className="font-medium">Internal Fleet</span>
                        </div>
                    </div>
                </div>

                {/* Documents */}
                <div className="md:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <h3 className="font-semibold text-gray-900 mb-4 border-b pb-2">Documents & Images</h3>
                    <div className="flex gap-6">
                        <div className="text-center">
                            <div className="w-24 h-24 bg-gray-100 rounded-lg flex items-center justify-center mb-2">
                                <User size={32} className="text-gray-400"/>
                            </div>
                            <span className="text-xs text-gray-600">Profile Photo</span>
                        </div>
                        <div className="text-center">
                            <div className="w-24 h-24 bg-red-50 border border-red-100 rounded-lg flex items-center justify-center mb-2 cursor-pointer hover:bg-red-100">
                                <FileText size={32} className="text-red-500"/>
                            </div>
                            <span className="text-xs text-gray-600">License PDF</span>
                        </div>
                        <div className="text-center">
                            <div className="w-24 h-24 bg-red-50 border border-red-100 rounded-lg flex items-center justify-center mb-2 cursor-pointer hover:bg-red-100">
                                <FileText size={32} className="text-red-500"/>
                            </div>
                            <span className="text-xs text-gray-600">Iqama PDF</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

// 4. Assign Route
export const AssignRoute: React.FC = () => {
    // Mock Routes
    const routes = [
        { id: 1, code: 'RT-001', name: 'Riyadh North', assigned: true },
        { id: 2, code: 'RT-002', name: 'Riyadh East', assigned: false },
        { id: 3, code: 'RT-003', name: 'Riyadh West', assigned: false },
    ];

    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Assign Routes" description="Manage route permissions for Ameen-Test." />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">#</th>
                            <th className="px-6 py-4">Route Code</th>
                            <th className="px-6 py-4">Route Name</th>
                            <th className="px-6 py-4">Assigned</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {routes.map((r, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                <td className="px-6 py-4 font-mono font-medium">{r.code}</td>
                                <td className="px-6 py-4">{r.name}</td>
                                <td className="px-6 py-4">
                                    <label className="flex items-center cursor-pointer">
                                        <div className="relative">
                                            <input type="checkbox" className="sr-only" defaultChecked={r.assigned} />
                                            <div className={`w-10 h-6 bg-gray-200 rounded-full shadow-inner ${r.assigned ? 'bg-green-500' : ''}`}></div>
                                            <div className={`dot absolute w-4 h-4 bg-white rounded-full shadow left-1 top-1 transition ${r.assigned ? 'transform translate-x-4' : ''}`}></div>
                                        </div>
                                    </label>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 5. Odo Meter List & History
export const OdoMeterHistory: React.FC = () => {
    // Mock Odo Data
    const odoLogs = [
        { id: 1, courier: 'Ameen-Test', date: '2024-02-28', vehicle: 'Van (1234 ABC)', startKm: '37741', endKm: '37850', startImg: true, endImg: true, fuelCard: '50.00' },
        { id: 2, courier: 'Rashid Nazir', date: '2024-02-28', vehicle: 'Truck (9988 XYZ)', startKm: '10200', endKm: '10350', startImg: true, endImg: false, fuelCard: 'Pending' },
    ];

    return (
        <div>
            <Header 
                title="Odometer & Fuel Logs" 
                description="Track daily vehicle usage and fuel consumption."
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Fuel size={16} /> Export Report
                    </button>
                }
            />
            
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200 mb-6 flex flex-wrap gap-4 items-end">
                <div className="w-64">
                    <label className="block text-xs font-medium text-gray-500 mb-1">Courier</label>
                    <input type="text" placeholder="Search Courier..." className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
                </div>
                <div className="w-40">
                    <label className="block text-xs font-medium text-gray-500 mb-1">From Date</label>
                    <input type="date" className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
                </div>
                <div className="w-40">
                    <label className="block text-xs font-medium text-gray-500 mb-1">To Date</label>
                    <input type="date" className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
                </div>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700">Filter</button>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">#</th>
                            <th className="px-6 py-4">Courier</th>
                            <th className="px-6 py-4">Date</th>
                            <th className="px-6 py-4">Vehicle</th>
                            <th className="px-6 py-4">Start KM</th>
                            <th className="px-6 py-4">End KM</th>
                            <th className="px-6 py-4">Running KM</th>
                            <th className="px-6 py-4">Fuel Card</th>
                            <th className="px-6 py-4">Images</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {odoLogs.map((log, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                <td className="px-6 py-4 font-medium text-gray-900">{log.courier}</td>
                                <td className="px-6 py-4">{log.date}</td>
                                <td className="px-6 py-4">{log.vehicle}</td>
                                <td className="px-6 py-4"><span className="bg-green-100 text-green-800 px-2 rounded text-xs font-mono">{log.startKm}</span></td>
                                <td className="px-6 py-4"><span className="bg-red-100 text-red-800 px-2 rounded text-xs font-mono">{log.endKm}</span></td>
                                <td className="px-6 py-4 font-bold">{parseInt(log.endKm) - parseInt(log.startKm)} km</td>
                                <td className="px-6 py-4">{log.fuelCard}</td>
                                <td className="px-6 py-4 flex gap-1">
                                    {log.startImg ? <Camera size={16} className="text-green-500" /> : <Camera size={16} className="text-gray-300" />}
                                    {log.endImg ? <Camera size={16} className="text-red-500" /> : <Camera size={16} className="text-gray-300" />}
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-blue-600 hover:underline text-xs">Edit</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
