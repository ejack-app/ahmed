import React from 'react';
import { Save, RefreshCw, CheckCircle, XCircle } from 'lucide-react';

export const IntegrationConfig: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Platform Integrations</h2>
        <p className="text-gray-500">Configure your e-commerce platform connections.</p>
      </div>

      {/* Zid Config */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex justify-between items-start mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center text-purple-600 font-bold text-xl">
              Z
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Zid Store Integration</h3>
              <p className="text-sm text-gray-500">Sync orders and inventory automatically.</p>
            </div>
          </div>
          <span className="flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
            <CheckCircle size={14} /> Connected
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Manager Token</label>
            <input type="password" value="************************" className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500" readOnly />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Store ID</label>
            <input type="text" value="8829102" className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500" readOnly />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Webhook Secret</label>
            <input type="password" value="************************" className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500" readOnly />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Sync Frequency</label>
            <select className="w-full px-4 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500">
              <option>Real-time (Webhook)</option>
              <option>Every 15 Minutes</option>
              <option>Every Hour</option>
            </select>
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-3 border-t border-gray-100 pt-4">
          <button className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg flex items-center gap-2">
            <RefreshCw size={16} /> Test Connection
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2">
            <Save size={16} /> Save Changes
          </button>
        </div>
      </div>

      {/* Salla Config */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 opacity-75">
        <div className="flex justify-between items-start mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center text-green-600 font-bold text-xl">
              S
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Salla Store Integration</h3>
              <p className="text-sm text-gray-500">Configure your Salla merchant account.</p>
            </div>
          </div>
          <span className="flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-500 rounded-full text-sm font-medium">
            <XCircle size={14} /> Inactive
          </span>
        </div>
        
        <div className="text-center py-8">
            <button className="px-6 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 font-medium">
                Connect Salla Account
            </button>
        </div>
      </div>
    </div>
  );
};