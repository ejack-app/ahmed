
import React, { useState } from 'react';
import { Shield, Plus, Lock, Check, Save } from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

export const NewTemplate: React.FC = () => {
    const modules = [
        'Shipment Management', 'Inventory Management', 'Finance Management', 'Reports', 'User Management', 'Settings'
    ];
    const [roleName, setRoleName] = useState('');

    const handleSave = () => {
        // In a real app: api.post('/roles', { name: roleName, permissions: [...] })
        alert(`Role Template "${roleName}" Created (Mock)`);
        setRoleName('');
    }

    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Create Role Template" description="Define access permissions for a new user role." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Role Name</label>
                    <input 
                        type="text" 
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" 
                        placeholder="e.g. Warehouse Supervisor" 
                        value={roleName}
                        onChange={e => setRoleName(e.target.value)}
                    />
                </div>

                <h3 className="font-semibold text-gray-900 mb-4">Module Permissions</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {modules.map((mod) => (
                        <div key={mod} className="p-4 border border-gray-200 rounded-lg flex items-center justify-between hover:bg-gray-50">
                            <span className="font-medium text-gray-700">{mod}</span>
                            <div className="flex gap-3 text-sm">
                                <label className="flex items-center gap-1"><input type="checkbox" className="rounded text-blue-600" /> Read</label>
                                <label className="flex items-center gap-1"><input type="checkbox" className="rounded text-blue-600" /> Write</label>
                                <label className="flex items-center gap-1"><input type="checkbox" className="rounded text-blue-600" /> Delete</label>
                            </div>
                        </div>
                    ))}
                </div>

                <div className="mt-8 flex justify-end">
                    <button onClick={handleSave} className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                        <Save size={18} /> Save Template
                    </button>
                </div>
            </div>
        </div>
    );
};

export const ShowTemplate: React.FC = () => {
    // In a real app, fetch from /roles
    const roles = [
        { name: 'Administrator', users: 2, access: 'Full Access' },
        { name: 'Logistics Manager', users: 1, access: 'Operations, Reports, Finance' },
        { name: 'Picker/Packer', users: 15, access: 'Shipments, Inventory (Read Only)' },
        { name: 'Driver', users: 40, access: 'Manifests, Route App' },
    ];

    return (
        <div>
            <Header 
                title="Role Templates" 
                description="Manage existing access roles."
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Plus size={16} /> New Template
                    </button>
                }
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {roles.map((role, i) => (
                    <div key={i} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                        <div className="flex justify-between items-start mb-4">
                            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                                <Shield size={24} />
                            </div>
                            <span className="text-xs font-mono bg-gray-100 px-2 py-1 rounded">{role.users} Users</span>
                        </div>
                        <h3 className="font-bold text-gray-900 text-lg">{role.name}</h3>
                        <p className="text-sm text-gray-500 mt-2">{role.access}</p>
                        <div className="mt-4 pt-4 border-t border-gray-100 flex gap-2">
                            <button className="flex-1 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50">Edit</button>
                            <button className="flex-1 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">Assign Users</button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};
