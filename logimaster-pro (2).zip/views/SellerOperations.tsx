import React, { useState } from 'react';
import { Store, Plus, Search, Filter, MoreHorizontal, FileText, Upload, Save, DollarSign, BarChart2, Briefcase, Calculator } from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Add Seller
export const AddSeller: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Add New Seller" description="Register a 3PL client or marketplace seller." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="md:col-span-2">
                        <h3 className="font-semibold text-gray-800 mb-2 border-b pb-2">Basic Info</h3>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Business Name (Company) <span className="text-red-500">*</span></label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. Fashion World" />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Contact Person Name <span className="text-red-500">*</span></label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="Full Name" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Email <span className="text-red-500">*</span></label>
                        <input type="email" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="seller@example.com" />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone <span className="text-red-500">*</span></label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="+966..." />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">City <span className="text-red-500">*</span></label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. Riyadh" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Address <span className="text-red-500">*</span></label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="Street Address" />
                    </div>

                    <div className="md:col-span-2 mt-4">
                        <h3 className="font-semibold text-gray-800 mb-2 border-b pb-2">Financial Details</h3>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Bank Name</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. Al Rajhi Bank" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">IBAN Number</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="SA..." />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">VAT Number</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Bank Fees (Fixed)</label>
                        <input type="number" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="0.00" />
                    </div>

                    <div className="md:col-span-2 mt-4">
                        <h3 className="font-semibold text-gray-800 mb-2 border-b pb-2">Account Settings</h3>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
                        <input type="password" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Confirm Password</label>
                        <input type="password" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                    </div>
                    
                    <div className="md:col-span-2">
                        <label className="flex items-center gap-2 mt-2">
                            <input type="checkbox" className="rounded text-blue-600" />
                            <span className="text-sm text-gray-700">Allow B2C Client Access</span>
                        </label>
                    </div>

                    <div className="md:col-span-2 mt-4">
                        <h3 className="font-semibold text-gray-800 mb-2 border-b pb-2">Documents</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="border border-dashed border-gray-300 rounded-lg p-4 text-center bg-gray-50">
                                <FileText className="mx-auto text-gray-400 mb-2" />
                                <p className="text-xs text-gray-600 mb-2">CR Document (PDF)</p>
                                <button className="text-xs text-blue-600 font-medium">Upload</button>
                            </div>
                            <div className="border border-dashed border-gray-300 rounded-lg p-4 text-center bg-gray-50">
                                <FileText className="mx-auto text-gray-400 mb-2" />
                                <p className="text-xs text-gray-600 mb-2">ID Copy (PDF)</p>
                                <button className="text-xs text-blue-600 font-medium">Upload</button>
                            </div>
                            <div className="border border-dashed border-gray-300 rounded-lg p-4 text-center bg-gray-50">
                                <FileText className="mx-auto text-gray-400 mb-2" />
                                <p className="text-xs text-gray-600 mb-2">Contract (PDF)</p>
                                <button className="text-xs text-blue-600 font-medium">Upload</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="mt-8 flex justify-end gap-3">
                    <button className="px-5 py-2.5 text-gray-700 hover:bg-gray-100 rounded-lg font-medium">Cancel</button>
                    <button className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                        <Plus size={18} /> Register Seller
                    </button>
                </div>
            </div>
        </div>
    );
};

// 2. View All Sellers
export const ViewAllSellers: React.FC = () => {
    // Mock Data
    const sellers = [
        { id: 'SEL-001', name: 'TechStore KSA', contact: 'Ahmed K.', phone: '0551234567', email: 'ahmed@techstore.sa', status: 'Active' },
        { id: 'SEL-002', name: 'Beauty Box', contact: 'Sarah M.', phone: '0569988776', email: 'sarah@beautybox.com', status: 'Active' },
        { id: 'SEL-003', name: 'Home Essentials', contact: 'John D.', phone: '0543322110', email: 'john@homeessentials.sa', status: 'Inactive' },
    ];

    return (
        <div>
            <Header 
                title="Seller Directory" 
                description="Manage registered 3PL clients and marketplace sellers."
                action={
                    <div className="flex gap-2">
                        <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 flex items-center gap-2">
                            <Upload size={16} /> Export
                        </button>
                        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                            <Plus size={16} /> Add Seller
                        </button>
                    </div>
                }
            />
            
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search by Name, ID, Email..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                    <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 flex items-center gap-2">
                        <Filter size={16} /> Filter
                    </button>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4 w-10"><input type="checkbox" /></th>
                            <th className="px-6 py-4">Seller ID</th>
                            <th className="px-6 py-4">Business Name</th>
                            <th className="px-6 py-4">Contact Person</th>
                            <th className="px-6 py-4">Phone</th>
                            <th className="px-6 py-4">Email</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {sellers.map((s, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4"><input type="checkbox" /></td>
                                <td className="px-6 py-4 font-mono font-medium text-blue-600">{s.id}</td>
                                <td className="px-6 py-4 font-medium text-gray-900">{s.name}</td>
                                <td className="px-6 py-4">{s.contact}</td>
                                <td className="px-6 py-4">{s.phone}</td>
                                <td className="px-6 py-4">{s.email}</td>
                                <td className="px-6 py-4">
                                     <span className={`px-2 py-1 rounded-full text-xs font-medium 
                                        ${s.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                        {s.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-gray-400 hover:text-gray-600">
                                        <MoreHorizontal size={20} />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
             </div>
        </div>
    );
};

// 3. Seller Rates (Zone Rates & Weight Ranges)
export const SellerRates: React.FC = () => {
    return (
        <div className="max-w-5xl mx-auto pb-10">
            <Header title="Seller Rates Configuration" description="Manage weight ranges and zone-based pricing." />
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* Weight Ranges */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 md:col-span-1 h-fit">
                    <h3 className="font-semibold text-gray-800 mb-4 flex justify-between items-center">
                        <span>Weight Ranges</span>
                        <button className="text-blue-600 text-xs font-medium hover:underline">+ Add Range</button>
                    </h3>
                    <div className="space-y-2">
                        {[
                            { id: 1, start: '0', end: '5' },
                            { id: 2, start: '5', end: '10' },
                            { id: 3, start: '10', end: '15' },
                            { id: 4, start: '15', end: '20' },
                        ].map((r, i) => (
                            <div key={i} className="flex justify-between items-center p-2 bg-gray-50 rounded border border-gray-100 text-sm">
                                <span>{r.start}kg - {r.end}kg</span>
                                <button className="text-red-400 hover:text-red-600 text-xs">Remove</button>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Zone Rates */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 md:col-span-2">
                    <h3 className="font-semibold text-gray-800 mb-4">Zone Pricing Matrix</h3>
                    
                    <div className="flex gap-4 mb-4">
                        <select className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm">
                            <option>Select Seller...</option>
                            <option>TechStore KSA</option>
                        </select>
                        <select className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm">
                            <option>Select Service...</option>
                            <option>Express Delivery</option>
                            <option>Standard Delivery</option>
                        </select>
                        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm">Load Rates</button>
                    </div>

                    <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm text-gray-600">
                            <thead className="bg-gray-50 uppercase font-semibold text-xs">
                                <tr>
                                    <th className="px-4 py-3">Weight Range</th>
                                    <th className="px-4 py-3">Riyadh (Zone A)</th>
                                    <th className="px-4 py-3">Jeddah (Zone B)</th>
                                    <th className="px-4 py-3">Remote (Zone C)</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-200">
                                <tr>
                                    <td className="px-4 py-3">0-5 kg</td>
                                    <td className="px-4 py-3"><input type="text" className="w-16 px-1 border rounded text-center" defaultValue="20" /></td>
                                    <td className="px-4 py-3"><input type="text" className="w-16 px-1 border rounded text-center" defaultValue="35" /></td>
                                    <td className="px-4 py-3"><input type="text" className="w-16 px-1 border rounded text-center" defaultValue="50" /></td>
                                </tr>
                                <tr>
                                    <td className="px-4 py-3">5-10 kg</td>
                                    <td className="px-4 py-3"><input type="text" className="w-16 px-1 border rounded text-center" defaultValue="25" /></td>
                                    <td className="px-4 py-3"><input type="text" className="w-16 px-1 border rounded text-center" defaultValue="40" /></td>
                                    <td className="px-4 py-3"><input type="text" className="w-16 px-1 border rounded text-center" defaultValue="60" /></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <div className="mt-4 pt-4 border-t border-gray-100 grid grid-cols-2 gap-4">
                        <div className="flex items-center justify-between p-3 bg-gray-50 rounded border border-gray-100">
                            <span className="text-sm font-medium">COD Fee</span>
                            <input type="text" className="w-16 px-1 border rounded text-center" defaultValue="10" />
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-50 rounded border border-gray-100">
                            <span className="text-sm font-medium">Return Fee</span>
                            <input type="text" className="w-16 px-1 border rounded text-center" defaultValue="15" />
                        </div>
                    </div>

                    <div className="mt-6 flex justify-end">
                        <button className="px-5 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                            <Save size={16} /> Save Rates
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

// 4. Seller Finance (Payments & Booking Details)
export const SellerFinance: React.FC = () => {
    // Mock Payment Info Data
    const payments = [
        { month: 'Feb 2024', shipments: 120, total: '15,000', cod: '5,000', due: '10,000', invoice: 'INV-2024-002', status: 'Unpaid' },
        { month: 'Jan 2024', shipments: 145, total: '18,500', cod: '6,500', due: '12,000', invoice: 'INV-2024-001', status: 'Paid' },
    ];

    return (
        <div className="max-w-5xl mx-auto pb-10">
            <Header title="Seller Finance" description="Payment history, invoices, and booking financial details." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                <div className="flex flex-wrap gap-4 items-end">
                    <div className="w-64">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Select Seller</label>
                        <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                            <option>TechStore KSA</option>
                            <option>Beauty Box</option>
                        </select>
                    </div>
                    <div className="w-48">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Filter Month</label>
                        <input type="month" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                    </div>
                    <div className="flex-1 flex justify-end gap-2">
                        <button className="px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Search</button>
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-8">
                <div className="p-4 bg-gray-50 border-b border-gray-200">
                    <h3 className="font-semibold text-gray-800 flex items-center gap-2">
                        <DollarSign size={18} className="text-blue-600" /> Monthly Payment Summary
                    </h3>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-white border-b">
                        <tr>
                            <th className="px-6 py-4">Month</th>
                            <th className="px-6 py-4">Total Shipments</th>
                            <th className="px-6 py-4">Total Amount (SAR)</th>
                            <th className="px-6 py-4">Total COD (SAR)</th>
                            <th className="px-6 py-4">Due Amount (SAR)</th>
                            <th className="px-6 py-4">Invoice No</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {payments.map((p, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-medium text-blue-600">{p.month}</td>
                                <td className="px-6 py-4">{p.shipments}</td>
                                <td className="px-6 py-4">{p.total}</td>
                                <td className="px-6 py-4">{p.cod}</td>
                                <td className="px-6 py-4 font-bold">{p.due}</td>
                                <td className="px-6 py-4 font-mono">{p.invoice}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded text-xs font-bold text-white ${p.status === 'Paid' ? 'bg-green-500' : 'bg-red-500'}`}>
                                        {p.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-blue-600 hover:underline">Details</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Booking Details / Transactions */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 bg-gray-50 border-b border-gray-200">
                    <h3 className="font-semibold text-gray-800 flex items-center gap-2">
                        <Briefcase size={18} className="text-purple-600" /> Recent Booking Transactions
                    </h3>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-white border-b">
                        <tr>
                            <th className="px-6 py-4">Date</th>
                            <th className="px-6 py-4">AWB No</th>
                            <th className="px-6 py-4">Service Charge</th>
                            <th className="px-6 py-4">COD Fees</th>
                            <th className="px-6 py-4">Total</th>
                            <th className="px-6 py-4">Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        <tr>
                            <td className="px-6 py-4">2024-02-28</td>
                            <td className="px-6 py-4 text-blue-600">AWB-100299</td>
                            <td className="px-6 py-4">25.00</td>
                            <td className="px-6 py-4">10.00</td>
                            <td className="px-6 py-4 font-bold">35.00</td>
                            <td className="px-6 py-4"><span className="bg-green-100 text-green-700 px-2 py-1 rounded text-xs">Delivered</span></td>
                        </tr>
                         <tr>
                            <td className="px-6 py-4">2024-02-28</td>
                            <td className="px-6 py-4 text-blue-600">AWB-100300</td>
                            <td className="px-6 py-4">25.00</td>
                            <td className="px-6 py-4">0.00</td>
                            <td className="px-6 py-4 font-bold">25.00</td>
                            <td className="px-6 py-4"><span className="bg-yellow-100 text-yellow-700 px-2 py-1 rounded text-xs">In Transit</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
};