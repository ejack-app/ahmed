import React, { useState } from 'react';
import { 
  Map, Navigation, Search, Truck, Package, MapPin, 
  Info, Maximize, ZoomIn, ZoomOut, Phone, User, CheckCircle
} from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// --- Mock Map Component (Visual Simulation) ---
const MockMap: React.FC<{ 
    markers?: Array<{id: string, x: number, y: number, color: string, tooltip: string, icon?: any}>,
    paths?: Array<Array<{x: number, y: number}>>
    zoom?: number
}> = ({ markers = [], paths = [], zoom = 1 }) => {
    
    return (
        <div className="relative w-full h-[600px] bg-slate-100 rounded-xl overflow-hidden border border-gray-300 group">
            {/* Grid Pattern Background to Simulate Map */}
            <div 
                className="absolute inset-0 opacity-10" 
                style={{
                    backgroundImage: 'linear-gradient(#94a3b8 1px, transparent 1px), linear-gradient(90deg, #94a3b8 1px, transparent 1px)',
                    backgroundSize: '40px 40px'
                }}
            ></div>
            
            {/* Mock Roads/Paths */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-40">
                {paths.map((path, idx) => (
                    <polyline 
                        key={idx}
                        points={path.map(p => `${p.x}%,${p.y}%`).join(' ')}
                        fill="none"
                        stroke="#3b82f6"
                        strokeWidth="4"
                        strokeLinecap="round"
                        strokeDasharray="8 4"
                    />
                ))}
            </svg>

            {/* Map Markers */}
            {markers.map((marker, i) => (
                <div 
                    key={marker.id}
                    className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all hover:scale-110 hover:z-20 group-hover:opacity-100"
                    style={{ left: `${marker.x}%`, top: `${marker.y}%` }}
                >
                    <div className={`p-2 rounded-full shadow-lg border-2 border-white ${marker.color}`}>
                        {marker.icon || <MapPin size={20} className="text-white" />}
                    </div>
                    {/* Tooltip */}
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-40 bg-white p-2 rounded shadow-lg text-xs hidden group-hover:block z-50">
                        <div className="font-bold text-gray-800">{marker.id}</div>
                        <div className="text-gray-500">{marker.tooltip}</div>
                    </div>
                </div>
            ))}

            {/* Map Controls UI (Simulated) */}
            <div className="absolute right-4 bottom-4 flex flex-col gap-2">
                <button className="p-2 bg-white rounded shadow text-gray-600 hover:bg-gray-50"><ZoomIn size={20}/></button>
                <button className="p-2 bg-white rounded shadow text-gray-600 hover:bg-gray-50"><ZoomOut size={20}/></button>
                <button className="p-2 bg-white rounded shadow text-gray-600 hover:bg-gray-50"><Maximize size={20}/></button>
            </div>
            
            <div className="absolute left-4 top-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded shadow text-xs font-mono text-gray-500">
                Simulated Map View • Riyadh, KSA
            </div>
        </div>
    );
};

// 1. Driver Tracking Map
export const DriverTrackingView: React.FC = () => {
    const [selectedDriver, setSelectedDriver] = useState<string | null>(null);

    // Mock Drivers
    const drivers = [
        { id: 'D-101', name: 'Ahmed Ali', vehicle: 'Van (Toyota)', status: 'Moving', speed: '45 km/h', location: 'Olaya Dist.', lat: 40, lng: 30, task: 'DELIVERING' },
        { id: 'D-102', name: 'Mohammed S.', vehicle: 'Bike (Honda)', status: 'Stopped', speed: '0 km/h', location: 'Malaz Dist.', lat: 60, lng: 55, task: 'PICKUP' },
        { id: 'D-103', name: 'Fahad K.', vehicle: 'Truck (Isuzu)', status: 'Moving', speed: '60 km/h', location: 'Ring Road', lat: 25, lng: 70, task: 'TRANSIT' },
    ];

    const markers = drivers.map(d => ({
        id: d.name,
        x: d.lng,
        y: d.lat,
        color: d.status === 'Moving' ? 'bg-green-500' : 'bg-orange-500',
        tooltip: `${d.vehicle} • ${d.speed}`,
        icon: <Truck size={16} className="text-white" />
    }));

    return (
        <div className="flex flex-col h-[calc(100vh-8rem)]">
            <Header 
                title="Live Driver Tracking" 
                description="Real-time location and status of active fleet." 
                action={
                    <div className="bg-white border border-gray-200 rounded-lg p-1 flex text-xs font-medium">
                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded">Moving (2)</span>
                        <span className="px-3 py-1 text-gray-500">Stopped (1)</span>
                        <span className="px-3 py-1 text-gray-500">Offline (5)</span>
                    </div>
                }
            />
            
            <div className="flex-1 flex gap-6 overflow-hidden">
                {/* Sidebar List */}
                <div className="w-80 bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col">
                    <div className="p-4 border-b border-gray-200">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                            <input 
                                type="text" 
                                placeholder="Search driver..." 
                                className="w-full pl-9 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm outline-none focus:ring-1 focus:ring-blue-500"
                            />
                        </div>
                    </div>
                    <div className="flex-1 overflow-y-auto">
                        {drivers.map(driver => (
                            <div 
                                key={driver.id} 
                                onClick={() => setSelectedDriver(driver.id)}
                                className={`p-4 border-b border-gray-100 hover:bg-blue-50 cursor-pointer transition-colors ${selectedDriver === driver.id ? 'bg-blue-50' : ''}`}
                            >
                                <div className="flex justify-between items-start mb-1">
                                    <h4 className="font-semibold text-gray-900 text-sm">{driver.name}</h4>
                                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${driver.status === 'Moving' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
                                        {driver.status}
                                    </span>
                                </div>
                                <div className="text-xs text-gray-500 mb-2 flex items-center gap-1">
                                    <Truck size={12} /> {driver.vehicle}
                                </div>
                                <div className="flex justify-between items-center text-xs">
                                    <span className="text-gray-400">{driver.location}</span>
                                    <span className="font-mono">{driver.speed}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Map Area */}
                <div className="flex-1 flex flex-col bg-white rounded-xl shadow-sm border border-gray-200 p-1">
                    <MockMap markers={markers} />
                    
                    {/* Selected Driver Detail Overlay */}
                    {selectedDriver && (
                        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 bg-white rounded-xl shadow-2xl p-4 w-96 border border-gray-200 flex gap-4 animate-in slide-in-from-bottom-4">
                            <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
                                <User className="text-gray-500" />
                            </div>
                            <div className="flex-1">
                                <h4 className="font-bold text-gray-900">{drivers.find(d => d.id === selectedDriver)?.name}</h4>
                                <p className="text-sm text-gray-500 mb-2">{drivers.find(d => d.id === selectedDriver)?.vehicle}</p>
                                <div className="flex gap-2">
                                    <button className="flex-1 py-1.5 bg-blue-600 text-white rounded text-xs font-medium hover:bg-blue-700 flex items-center justify-center gap-1">
                                        <Phone size={12} /> Call
                                    </button>
                                    <button className="flex-1 py-1.5 bg-gray-100 text-gray-700 rounded text-xs font-medium hover:bg-gray-200">
                                        View Log
                                    </button>
                                </div>
                            </div>
                            <button 
                                onClick={() => setSelectedDriver(null)}
                                className="text-gray-400 hover:text-gray-600 self-start"
                            >
                                &times;
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

// 2. Shipment Path
export const ShipmentPathView: React.FC = () => {
    const [awb, setAwb] = useState('AWB-882190');
    
    // Mock Path: Riyadh Hub -> Transit -> Dammam Hub -> Delivered
    const pathCoordinates = [
        {x: 20, y: 50}, // Origin
        {x: 40, y: 45},
        {x: 60, y: 60},
        {x: 80, y: 30}  // Destination
    ];

    const checkpoints = [
        { id: 1, name: 'Riyadh Central Hub', time: '10:00 AM', status: 'Departed', x: 20, y: 50 },
        { id: 2, name: 'Transit Point A', time: '02:30 PM', status: 'Passed', x: 40, y: 45 },
        { id: 3, name: 'Dammam Distribution', time: '06:15 PM', status: 'Arrived', x: 60, y: 60 },
        { id: 4, name: 'Customer Location', time: 'Est. 08:00 PM', status: 'Pending', x: 80, y: 30 },
    ];

    const mapMarkers = checkpoints.map(cp => ({
        id: cp.name,
        x: cp.x,
        y: cp.y,
        color: cp.status === 'Pending' ? 'bg-gray-400' : 'bg-blue-600',
        tooltip: `${cp.time} - ${cp.status}`,
        icon: cp.status === 'Pending' ? <MapPin size={16} className="text-white" /> : <CheckCircle size={16} className="text-white" /> // Icon override
    }));

    return (
        <div className="flex flex-col h-[calc(100vh-8rem)]">
            <Header title="Shipment Route Visualizer" description="Track the geographical path of a specific shipment." />
            
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200 mb-6 flex gap-4">
                <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                    <input 
                        type="text" 
                        value={awb}
                        onChange={(e) => setAwb(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg outline-none font-mono focus:ring-2 focus:ring-blue-500"
                        placeholder="Enter AWB Number..."
                    />
                </div>
                <button className="px-6 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700">
                    Track Route
                </button>
            </div>

            <div className="flex-1 grid grid-cols-3 gap-6 overflow-hidden">
                {/* Timeline Panel */}
                <div className="col-span-1 bg-white rounded-xl shadow-sm border border-gray-200 p-6 overflow-y-auto">
                    <h3 className="font-bold text-gray-900 mb-6 flex items-center gap-2">
                        <Package className="text-blue-600" /> Shipment Timeline
                    </h3>
                    <div className="relative border-l-2 border-gray-200 ml-3 space-y-8 pb-4">
                        {checkpoints.map((cp, idx) => (
                            <div key={idx} className="relative pl-8">
                                <div className={`absolute -left-[9px] top-0 w-4 h-4 rounded-full border-2 border-white ${cp.status === 'Pending' ? 'bg-gray-300' : 'bg-blue-600'}`}></div>
                                <div>
                                    <span className="text-xs text-gray-400 font-mono block mb-1">{cp.time}</span>
                                    <h4 className={`text-sm font-semibold ${cp.status === 'Pending' ? 'text-gray-500' : 'text-gray-900'}`}>{cp.name}</h4>
                                    <p className="text-xs text-gray-500">{cp.status}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                    
                    <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-100">
                        <h4 className="text-xs font-bold text-blue-800 uppercase mb-2">Current Status</h4>
                        <p className="text-sm text-blue-700">
                            Shipment is currently <strong>In Transit</strong> towards the destination hub. Expected arrival in 2 hours.
                        </p>
                    </div>
                </div>

                {/* Map Panel */}
                <div className="col-span-2 bg-white rounded-xl shadow-sm border border-gray-200 p-1 flex flex-col">
                    <MockMap markers={mapMarkers} paths={[pathCoordinates]} />
                </div>
            </div>
        </div>
    );
};