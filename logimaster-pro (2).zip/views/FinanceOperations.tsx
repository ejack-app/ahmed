
import React, { useState, useEffect } from 'react';
import { DollarSign, Save, Search, FileText, PieChart, CreditCard, RefreshCw, XCircle, Filter, Calendar, Loader, Settings, AlertTriangle, Upload, CheckSquare, ArrowRight, Plus, Trash2, Edit } from 'lucide-react';
import { api } from '../utils/api';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// Reusable Finance Table connected to API
const FinanceTable: React.FC<{ type: string }> = ({ type }) => {
    const [invoices, setInvoices] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchInvoices = async () => {
            try {
                const data = await api.get('/invoices');
                setInvoices(data);
            } catch (e) {
                console.error(e);
            } finally {
                setLoading(false);
            }
        };
        fetchInvoices();
    }, []);

    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                    <input type="text" placeholder={`Search ${type}...`} className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                </div>
            </div>
            <table className="w-full text-left text-sm text-gray-600">
                <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                    <tr>
                        <th className="px-6 py-4">Invoice No</th>
                        <th className="px-6 py-4">Client ID</th>
                        <th className="px-6 py-4">Due Date</th>
                        <th className="px-6 py-4">Type</th>
                        <th className="px-6 py-4">Amount</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4 text-right">Action</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                    {loading ? (
                        <tr><td colSpan={7} className="p-6 text-center"><Loader className="animate-spin mx-auto"/></td></tr>
                    ) : invoices.length === 0 ? (
                        <tr><td colSpan={7} className="p-6 text-center text-gray-400">No invoices found.</td></tr>
                    ) : (
                        invoices.map((inv, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono text-blue-600">{inv.invoice_no}</td>
                                <td className="px-6 py-4">Client #{inv.client_id}</td>
                                <td className="px-6 py-4">{new Date(inv.due_date).toLocaleDateString()}</td>
                                <td className="px-6 py-4">{inv.type}</td>
                                <td className="px-6 py-4 font-bold">SAR {inv.amount}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded text-xs font-bold ${inv.status === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                        {inv.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right"><button className="text-gray-400 hover:text-gray-600">View</button></td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
        </div>
    );
};

// 1. Set Fixed Rate Charges
export const SetFixedRateCharges: React.FC = () => {
    return (
        <div className="max-w-3xl mx-auto pb-10">
            <Header title="Fixed Rate Configuration" description="Set standard service fees for general clients." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center gap-2 mb-6 text-blue-600 bg-blue-50 p-3 rounded-lg">
                    <Settings size={20} />
                    <span className="font-medium">Global Service Rates</span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Base Delivery Fee (SAR)</label>
                        <input type="number" defaultValue={25} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">COD Service Fee (SAR)</label>
                        <input type="number" defaultValue={10} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Return (RTO) Fee (SAR)</label>
                        <input type="number" defaultValue={15} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Reschedule Fee (SAR)</label>
                        <input type="number" defaultValue={5} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">VAT %</label>
                        <input type="number" defaultValue={15} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                    </div>
                </div>

                <div className="mt-8 flex justify-end">
                    <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                        <Save size={18} /> Save Configurations
                    </button>
                </div>
            </div>
        </div>
    );
};

// 2. Set Dynamic Rate Charges
export const SetDynamicRateCharges: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Dynamic Rate Rules" description="Configure variable pricing based on weight and zones." />
            <div className="bg-white p-6 rounded-xl border border-gray-200">
                <div className="text-center text-gray-500 py-10">
                    <Filter size={48} className="mx-auto mb-2 opacity-20" />
                    <p>Advanced rate matrix configuration.</p>
                </div>
            </div>
        </div>
    );
};

// 3. Expense Categories
export const AllCategory: React.FC = () => {
    const categories = [
        { id: 1, name: 'Fleet Fuel', type: 'Expense', budget: '20,000' },
        { id: 2, name: 'Vehicle Maintenance', type: 'Expense', budget: '15,000' },
        { id: 3, name: 'Staff Salaries', type: 'Expense', budget: '150,000' },
        { id: 4, name: 'Packaging Materials', type: 'COGS', budget: '5,000' },
    ];

    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header 
                title="Expense Categories" 
                description="Manage financial categories for reporting." 
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Plus size={16} /> Add Category
                    </button>
                }
            />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">ID</th>
                            <th className="px-6 py-4">Category Name</th>
                            <th className="px-6 py-4">Type</th>
                            <th className="px-6 py-4">Monthly Budget (SAR)</th>
                            <th className="px-6 py-4 text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {categories.map((cat, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 text-gray-400">{cat.id}</td>
                                <td className="px-6 py-4 font-medium text-gray-900">{cat.name}</td>
                                <td className="px-6 py-4">
                                    <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs">{cat.type}</span>
                                </td>
                                <td className="px-6 py-4">{cat.budget}</td>
                                <td className="px-6 py-4 text-right flex justify-end gap-2">
                                    <button className="text-blue-600 hover:bg-blue-50 p-1 rounded"><Edit size={16}/></button>
                                    <button className="text-red-600 hover:bg-red-50 p-1 rounded"><Trash2 size={16}/></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export const StorageChargesInvoices: React.FC = () => <div><Header title="Storage Invoices" description="Monthly storage fee invoices." /><FinanceTable type="Invoices" /></div>;
export const TransactionReport: React.FC = () => <div><Header title="Transaction Report" description="Financial activity log." /><FinanceTable type="Transactions" /></div>;
export const FixRateInvoice: React.FC = () => <div><Header title="Fixed Rate Invoices" description="Invoices generated from fixed service fees." /><FinanceTable type="Invoices" /></div>;
export const DynamicInvoice: React.FC = () => <div><Header title="Dynamic Rate Invoices" description="Invoices generated based on weight/zone." /><FinanceTable type="Invoices" /></div>;

// 4. Storage Types
export const AllStorageTypes: React.FC = () => {
    const storageTypes = [
        { id: 'ST-001', name: 'Standard Pallet', dims: '1.2 x 1.0 m', dailyRate: '1.50', monthlyRate: '45.00' },
        { id: 'ST-002', name: 'Small Bin (Shelf)', dims: '0.5 x 0.5 m', dailyRate: '0.50', monthlyRate: '15.00' },
        { id: 'ST-003', name: 'Cold Storage (Pallet)', dims: '1.2 x 1.0 m', dailyRate: '3.00', monthlyRate: '90.00' },
        { id: 'ST-004', name: 'Secure Cage', dims: '2.0 x 2.0 m', dailyRate: '10.00', monthlyRate: '300.00' },
    ];

    return (
        <div className="max-w-5xl mx-auto pb-10">
            <Header 
                title="Storage Types & Pricing" 
                description="Define billing rates for warehouse storage units." 
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Plus size={16} /> New Type
                    </button>
                }
            />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Code</th>
                            <th className="px-6 py-4">Storage Type</th>
                            <th className="px-6 py-4">Dimensions</th>
                            <th className="px-6 py-4">Daily Rate (SAR)</th>
                            <th className="px-6 py-4">Monthly Rate (SAR)</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {storageTypes.map((st, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono text-gray-500">{st.id}</td>
                                <td className="px-6 py-4 font-medium text-gray-900">{st.name}</td>
                                <td className="px-6 py-4">{st.dims}</td>
                                <td className="px-6 py-4">{st.dailyRate}</td>
                                <td className="px-6 py-4 font-bold text-green-700">{st.monthlyRate}</td>
                                <td className="px-6 py-4 text-right flex justify-end gap-2">
                                    <button className="text-blue-600 hover:bg-blue-50 p-1 rounded"><Edit size={16}/></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 5. Cancel Order Finance
export const CancelOrderFinance: React.FC = () => {
    return (
        <div className="max-w-2xl mx-auto pb-10">
            <Header title="Cancel Order Finance" description="Process refunds or void charges for cancelled orders." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Search Order ID</label>
                    <div className="flex gap-2">
                        <input type="text" className="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="Enter AWB or Order Ref..." />
                        <button className="px-4 py-2.5 bg-gray-100 text-gray-700 rounded-lg border border-gray-300">Find</button>
                    </div>
                </div>

                <div className="p-4 bg-red-50 rounded-lg border border-red-100 mb-6">
                    <div className="flex items-center gap-2 text-red-800 font-semibold mb-2">
                        <AlertTriangle size={18} /> Cancellation Impact
                    </div>
                    <p className="text-sm text-red-700">This action will void the invoice associated with the order and may trigger a credit note if payment was already collected.</p>
                </div>

                <div className="flex justify-end">
                    <button className="px-6 py-2.5 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium">
                        Confirm Cancellation
                    </button>
                </div>
            </div>
        </div>
    );
};

export const CreateLMInvoice: React.FC = () => {
    const [formData, setFormData] = useState({ client_id: '', amount: '', due_date: '', type: 'Manual' });

    const handleCreate = async () => {
        try {
            await api.post('/invoices', formData);
            alert('Invoice Generated');
            setFormData({ client_id: '', amount: '', due_date: '', type: 'Manual' });
        } catch(e: any) {
            alert(e.message);
        }
    };

    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Create LogiMaster Invoice" description="Manually generate an invoice for a client." />
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="grid grid-cols-2 gap-6 mb-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Client ID</label>
                        <input type="number" className="w-full px-4 py-2 border border-gray-300 rounded-lg" value={formData.client_id} onChange={e => setFormData({...formData, client_id: e.target.value})}/>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
                        <input type="date" className="w-full px-4 py-2 border border-gray-300 rounded-lg" value={formData.due_date} onChange={e => setFormData({...formData, due_date: e.target.value})}/>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Amount</label>
                        <input type="number" className="w-full px-4 py-2 border border-gray-300 rounded-lg" value={formData.amount} onChange={e => setFormData({...formData, amount: e.target.value})}/>
                    </div>
                </div>
                <div className="mt-6 flex justify-end">
                    <button onClick={handleCreate} className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium">Generate Invoice</button>
                </div>
            </div>
        </div>
    );
};

export const ViewLMInvoice: React.FC = () => <div><Header title="LogiMaster Invoices" description="All manually generated invoices." /><FinanceTable type="LM Invoices" /></div>;

// --- BULK INVOICE MANAGEMENT ---

export const CreateBulkInvoice: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Generate Bulk Invoice" description="Create consolidated invoices for clients based on unbilled shipments." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Select Client</label>
                        <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                            <option>TechStore KSA</option>
                            <option>Fashion World</option>
                            <option>Home Essentials</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Billing Period</label>
                        <div className="flex gap-2">
                            <input type="date" className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm" />
                            <input type="date" className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm" />
                        </div>
                    </div>
                    <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center justify-center gap-2">
                        <Filter size={18} /> Find Orders
                    </button>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-6">
                <div className="p-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
                    <h4 className="font-semibold text-gray-700">Unbilled Shipments (15)</h4>
                    <div className="flex items-center gap-4 text-sm">
                        <span>Total Service: <strong className="text-blue-600">SAR 450.00</strong></span>
                        <span>Total COD: <strong className="text-green-600">SAR 2,100.00</strong></span>
                    </div>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-white border-b">
                        <tr>
                            <th className="px-6 py-3 w-10"><input type="checkbox" defaultChecked /></th>
                            <th className="px-6 py-3">Date</th>
                            <th className="px-6 py-3">AWB No</th>
                            <th className="px-6 py-3">Service Type</th>
                            <th className="px-6 py-3">Weight</th>
                            <th className="px-6 py-3 text-right">Fee</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                        {[1,2,3].map(i => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-3"><input type="checkbox" defaultChecked /></td>
                                <td className="px-6 py-3">2024-03-0{i}</td>
                                <td className="px-6 py-3 font-mono text-blue-600">AWB-992{i}</td>
                                <td className="px-6 py-3">Standard Delivery</td>
                                <td className="px-6 py-3">2.5 kg</td>
                                <td className="px-6 py-3 text-right font-medium">30.00</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            <div className="flex justify-end">
                <button className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium flex items-center gap-2 shadow-lg">
                    <FileText size={18} /> Generate & Send Invoice
                </button>
            </div>
        </div>
    );
};

export const BulkCODInvoices: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Bulk COD Remittance" description="Reconcile and process COD payments to clients." />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
                        <Upload size={18} className="text-blue-600" /> Upload Bank Statement
                    </h3>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-gray-50">
                        <FileText size={32} className="text-gray-300 mb-2" />
                        <p className="text-sm font-medium text-gray-900">Drag & drop CSV/Excel</p>
                        <p className="text-xs text-gray-500 mt-1">To reconcile deposited amounts automatically.</p>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
                        <CreditCard size={18} className="text-green-600" /> Pending Transfers
                    </h3>
                    <div className="space-y-4">
                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                            <div>
                                <p className="text-sm font-medium text-gray-900">TechStore KSA</p>
                                <p className="text-xs text-gray-500">120 Orders</p>
                            </div>
                            <div className="text-right">
                                <p className="text-sm font-bold text-gray-900">SAR 15,200</p>
                                <button className="text-xs text-blue-600 hover:underline">Pay Now</button>
                            </div>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                            <div>
                                <p className="text-sm font-medium text-gray-900">Beauty Box</p>
                                <p className="text-xs text-gray-500">45 Orders</p>
                            </div>
                            <div className="text-right">
                                <p className="text-sm font-bold text-gray-900">SAR 4,500</p>
                                <button className="text-xs text-blue-600 hover:underline">Pay Now</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export const PayableInvoices: React.FC = () => {
    const payables = [
        { id: 'BILL-001', vendor: 'SMSA Express', date: '2024-02-28', amount: '5,400', status: 'Due' },
        { id: 'BILL-002', vendor: 'Packaging Supplier Co.', date: '2024-02-25', amount: '1,200', status: 'Overdue' },
        { id: 'BILL-003', vendor: 'Aramex', date: '2024-03-01', amount: '3,100', status: 'Paid' },
    ];

    return (
        <div className="max-w-5xl mx-auto pb-10">
            <Header title="Accounts Payable" description="Track and pay bills to suppliers and 3PL partners." />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Bill ID</th>
                            <th className="px-6 py-4">Vendor / Supplier</th>
                            <th className="px-6 py-4">Due Date</th>
                            <th className="px-6 py-4">Amount (SAR)</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {payables.map((bill, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono text-gray-700">{bill.id}</td>
                                <td className="px-6 py-4 font-medium text-gray-900">{bill.vendor}</td>
                                <td className="px-6 py-4">{bill.date}</td>
                                <td className="px-6 py-4 font-bold">{bill.amount}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded-full text-xs font-bold 
                                        ${bill.status === 'Paid' ? 'bg-green-100 text-green-700' : 
                                          bill.status === 'Overdue' ? 'bg-red-100 text-red-700' : 
                                          'bg-yellow-100 text-yellow-700'}`}>
                                        {bill.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    {bill.status !== 'Paid' && (
                                        <button className="text-blue-600 hover:underline text-xs font-medium">Record Payment</button>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
