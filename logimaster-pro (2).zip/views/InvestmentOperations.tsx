import React, { useState } from 'react';
import { 
  TrendingUp, PieChart, Users, DollarSign, FileText, 
  Upload, Search, Filter, Plus, CheckCircle, ExternalLink, 
  CreditCard, Landmark, ArrowRight, ShieldCheck, Activity,
  Briefcase, FileCode
} from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// --- INVESTMENT DASHBOARD ---
export const InvestmentDashboard: React.FC = () => {
    return (
        <div className="space-y-6">
            <Header title="Investment Dashboard" description="Overview of capital raising, equity distribution, and active rounds." />
            
            {/* Top Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between mb-4">
                        <div className="p-3 bg-green-50 text-green-600 rounded-lg">
                            <DollarSign size={24} />
                        </div>
                        <span className="text-xs font-medium text-green-600 bg-green-100 px-2 py-1 rounded-full">+12% vs Target</span>
                    </div>
                    <p className="text-sm text-gray-500">Total Capital Raised</p>
                    <h3 className="text-2xl font-bold text-gray-900">SAR 5,250,000</h3>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between mb-4">
                        <div className="p-3 bg-blue-50 text-blue-600 rounded-lg">
                            <PieChart size={24} />
                        </div>
                    </div>
                    <p className="text-sm text-gray-500">Equity Offered</p>
                    <h3 className="text-2xl font-bold text-gray-900">15.5%</h3>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between mb-4">
                        <div className="p-3 bg-purple-50 text-purple-600 rounded-lg">
                            <Users size={24} />
                        </div>
                    </div>
                    <p className="text-sm text-gray-500">Active Investors</p>
                    <h3 className="text-2xl font-bold text-gray-900">24</h3>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between mb-4">
                        <div className="p-3 bg-orange-50 text-orange-600 rounded-lg">
                            <Activity size={24} />
                        </div>
                        <span className="text-xs font-medium text-orange-600 bg-orange-100 px-2 py-1 rounded-full">Series A</span>
                    </div>
                    <p className="text-sm text-gray-500">Current Valuation</p>
                    <h3 className="text-2xl font-bold text-gray-900">SAR 45M</h3>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Active Round Summary */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="font-bold text-gray-900">Active Round: Series A Expansion</h3>
                        <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold">Live</span>
                    </div>
                    <div className="space-y-6">
                        <div>
                            <div className="flex justify-between text-sm mb-2">
                                <span className="text-gray-500">Progress</span>
                                <span className="font-bold text-gray-900">75%</span>
                            </div>
                            <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden">
                                <div className="bg-blue-600 h-3 rounded-full" style={{ width: '75%' }}></div>
                            </div>
                            <div className="flex justify-between text-xs text-gray-400 mt-2">
                                <span>Raised: SAR 3.75M</span>
                                <span>Target: SAR 5M</span>
                            </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-100">
                            <div>
                                <p className="text-xs text-gray-500">Share Price</p>
                                <p className="font-bold text-gray-900">SAR 125.00</p>
                            </div>
                            <div>
                                <p className="text-xs text-gray-500">Min. Ticket</p>
                                <p className="font-bold text-gray-900">SAR 50,000</p>
                            </div>
                            <div>
                                <p className="text-xs text-gray-500">Closing Date</p>
                                <p className="font-bold text-gray-900">30 Mar 2024</p>
                            </div>
                            <div>
                                <p className="text-xs text-gray-500">Remaining Shares</p>
                                <p className="font-bold text-gray-900">10,000</p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Recent Activity */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <h3 className="font-bold text-gray-900 mb-6">Recent Subscriptions</h3>
                    <div className="space-y-4">
                        {[
                            { name: 'Abdullah Al-Rajhi', amount: 'SAR 250,000', status: 'Completed', date: 'Today, 10:30 AM' },
                            { name: 'Sara Investment Group', amount: 'SAR 1,000,000', status: 'Pending', date: 'Yesterday' },
                            { name: 'Khalid O.', amount: 'SAR 50,000', status: 'Completed', date: '2 days ago' },
                        ].map((sub, i) => (
                            <div key={i} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors border border-gray-100">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center font-bold text-gray-500">
                                        {sub.name.charAt(0)}
                                    </div>
                                    <div>
                                        <p className="text-sm font-semibold text-gray-900">{sub.name}</p>
                                        <p className="text-xs text-gray-500">{sub.date}</p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="text-sm font-bold text-gray-900">{sub.amount}</p>
                                    <span className={`text-xs ${sub.status === 'Completed' ? 'text-green-600' : 'text-orange-600'}`}>
                                        {sub.status}
                                    </span>
                                </div>
                            </div>
                        ))}
                    </div>
                    <button className="w-full mt-4 py-2 text-sm text-blue-600 font-medium hover:bg-blue-50 rounded-lg">View All Transactions</button>
                </div>
            </div>
        </div>
    );
};

// --- INVESTMENT ROUNDS / OPPORTUNITIES ---
export const InvestmentOpportunities: React.FC = () => {
    const [isCreating, setIsCreating] = useState(false);

    // Mock Data
    const rounds = [
        { id: 'RND-001', name: 'Seed Round', date: 'Jan 2023', valuation: '10M', raised: '2M', status: 'Closed' },
        { id: 'RND-002', name: 'Series A Expansion', date: 'Feb 2024', valuation: '45M', raised: '3.75M', status: 'Active' },
    ];

    if (isCreating) {
        return (
            <div className="max-w-4xl mx-auto">
                <Header 
                    title="Create New Investment Round" 
                    description="Configure valuation, share distribution, and compliance documents." 
                    action={
                        <button onClick={() => setIsCreating(false)} className="text-gray-500 hover:text-gray-700">Cancel</button>
                    }
                />
                
                <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {/* Valuation Settings */}
                        <div className="space-y-6">
                            <h3 className="font-bold text-gray-900 border-b pb-2 flex items-center gap-2">
                                <Activity size={18} className="text-blue-600" /> Valuation & Pricing
                            </h3>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1.5">Round Name</label>
                                <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. Series B" />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Pre-Money Valuation (SAR)</label>
                                    <input type="number" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="0.00" />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Total Shares Issued</label>
                                    <input type="number" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="0" />
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Share Price (SAR)</label>
                                    <input type="number" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="0.00" />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Target Raise (SAR)</label>
                                    <input type="number" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg bg-gray-50" placeholder="Calculated..." readOnly />
                                </div>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1.5">Percentage Offered (%)</label>
                                <input type="number" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. 10" />
                            </div>
                        </div>

                        {/* Due Diligence */}
                        <div className="space-y-6">
                            <h3 className="font-bold text-gray-900 border-b pb-2 flex items-center gap-2">
                                <ShieldCheck size={18} className="text-green-600" /> Due Diligence (FDD)
                            </h3>
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-xs font-medium text-gray-700 mb-1">Financial Statements (Last 3 Years)</label>
                                    <div className="border border-dashed border-gray-300 rounded-lg p-3 flex items-center justify-center gap-2 cursor-pointer hover:bg-gray-50">
                                        <Upload size={16} className="text-gray-400" />
                                        <span className="text-sm text-blue-600">Upload PDF</span>
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-700 mb-1">Commercial Registration & Articles of Association</label>
                                    <div className="border border-dashed border-gray-300 rounded-lg p-3 flex items-center justify-center gap-2 cursor-pointer hover:bg-gray-50">
                                        <Upload size={16} className="text-gray-400" />
                                        <span className="text-sm text-blue-600">Upload PDF</span>
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-700 mb-1">Business Plan & Projections</label>
                                    <div className="border border-dashed border-gray-300 rounded-lg p-3 flex items-center justify-center gap-2 cursor-pointer hover:bg-gray-50">
                                        <Upload size={16} className="text-gray-400" />
                                        <span className="text-sm text-blue-600">Upload PDF</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="mt-8 pt-6 border-t border-gray-200 flex justify-end gap-4">
                        <button onClick={() => setIsCreating(false)} className="px-6 py-2.5 text-gray-700 hover:bg-gray-100 rounded-lg">Cancel</button>
                        <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                            <Plus size={18} /> Launch Round
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div>
            <Header 
                title="Investment Opportunities" 
                description="Manage active and past investment rounds." 
                action={
                    <button onClick={() => setIsCreating(true)} className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Plus size={16} /> New Round
                    </button>
                }
            />

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Round ID</th>
                            <th className="px-6 py-4">Name</th>
                            <th className="px-6 py-4">Date</th>
                            <th className="px-6 py-4">Valuation (SAR)</th>
                            <th className="px-6 py-4">Raised (SAR)</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {rounds.map((r, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono text-blue-600">{r.id}</td>
                                <td className="px-6 py-4 font-bold text-gray-900">{r.name}</td>
                                <td className="px-6 py-4">{r.date}</td>
                                <td className="px-6 py-4">{r.valuation}</td>
                                <td className="px-6 py-4">{r.raised}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded-full text-xs font-bold ${r.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                                        {r.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-blue-600 hover:underline text-xs font-medium">Manage</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// --- INVESTMENT SUBSCRIPTIONS ---
export const InvestmentSubscriptions: React.FC = () => {
    return (
        <div>
            <Header 
                title="Subscriptions & Contracts" 
                description="Track investor payments and legal contract status." 
                action={
                    <div className="flex gap-2">
                        <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 flex items-center gap-2">
                            <FileText size={16} /> Export CSV
                        </button>
                        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                            <Plus size={16} /> Add Manual Sub
                        </button>
                    </div>
                }
            />

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex gap-4">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search investor name, ID..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                    <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 flex items-center gap-2">
                        <Filter size={16} /> Filter
                    </button>
                </div>

                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Investor</th>
                            <th className="px-6 py-4">Shares</th>
                            <th className="px-6 py-4">Amount (SAR)</th>
                            <th className="px-6 py-4">Payment</th>
                            <th className="px-6 py-4">Contract</th>
                            <th className="px-6 py-4">KYC Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        <tr className="hover:bg-gray-50">
                            <td className="px-6 py-4 font-medium text-gray-900">Abdullah Al-Rajhi</td>
                            <td className="px-6 py-4">2,000</td>
                            <td className="px-6 py-4 font-bold">250,000</td>
                            <td className="px-6 py-4">
                                <span className="flex items-center gap-1 text-green-600 bg-green-50 px-2 py-1 rounded text-xs">
                                    <Landmark size={12} /> Bank Transfer (Verified)
                                </span>
                            </td>
                            <td className="px-6 py-4">
                                <a href="#" className="flex items-center gap-1 text-blue-600 hover:underline">
                                    <FileCode size={12} /> Signed (E-Contract)
                                </a>
                            </td>
                            <td className="px-6 py-4 text-green-600 font-bold text-xs">Approved</td>
                            <td className="px-6 py-4 text-right">
                                <button className="text-gray-400 hover:text-gray-600">Details</button>
                            </td>
                        </tr>
                        <tr className="hover:bg-gray-50">
                            <td className="px-6 py-4 font-medium text-gray-900">Sara Investment Group</td>
                            <td className="px-6 py-4">8,000</td>
                            <td className="px-6 py-4 font-bold">1,000,000</td>
                            <td className="px-6 py-4">
                                <span className="flex items-center gap-1 text-orange-600 bg-orange-50 px-2 py-1 rounded text-xs">
                                    <CreditCard size={12} /> Pending Payment
                                </span>
                            </td>
                            <td className="px-6 py-4">
                                <span className="text-gray-400 text-xs">Sent</span>
                            </td>
                            <td className="px-6 py-4 text-blue-600 font-bold text-xs">Under Review</td>
                            <td className="px-6 py-4 text-right">
                                <button className="text-gray-400 hover:text-gray-600">Details</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
};
