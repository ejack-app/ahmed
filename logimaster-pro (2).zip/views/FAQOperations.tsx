import React from 'react';
import { HelpCircle, Plus, Search, ChevronDown, ChevronUp, Edit, Trash } from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

export const AddFAQ: React.FC = () => {
    return (
        <div className="max-w-3xl mx-auto pb-10">
            <Header title="Add New FAQ" description="Create help content for staff and customers." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Question (Arabic / English)</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. How to track a shipment?" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Answer</label>
                        <textarea rows={5} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="Detailed answer..."></textarea>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Category</label>
                        <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                            <option>General</option>
                            <option>Shipping</option>
                            <option>Returns</option>
                            <option>Billing</option>
                        </select>
                    </div>
                </div>
                <div className="mt-6 flex justify-end">
                    <button className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                        <Plus size={18} /> Publish FAQ
                    </button>
                </div>
            </div>
        </div>
    );
};

export const ShowFAQ: React.FC = () => {
    const faqs = [
        { id: 1, q: 'How do I generate a return label?', a: 'Go to Shipment Management > Create Reverse Order, enter the original Order ID, and click "Create Return Label".', cat: 'Returns' },
        { id: 2, q: 'What is the cutoff time for same-day dispatch?', a: 'All orders received before 2:00 PM are processed for same-day dispatch.', cat: 'Shipping' },
        { id: 3, q: 'How to update stock manually?', a: 'Navigate to Inventory Management > View Item Inventory, search for the SKU, and click Edit to adjust stock levels.', cat: 'Inventory' },
    ];

    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Knowledge Base" description="Frequently Asked Questions." />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-6">
                 <div className="p-4 bg-gray-50 border-b border-gray-200">
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search knowledge base..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                </div>
                <div className="divide-y divide-gray-100">
                    {faqs.map((faq) => (
                        <div key={faq.id} className="p-6 hover:bg-gray-50 transition-colors group">
                            <div className="flex justify-between items-start mb-2">
                                <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                                    <HelpCircle size={16} className="text-blue-600" />
                                    {faq.q}
                                </h3>
                                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button className="p-1 text-gray-400 hover:text-blue-600"><Edit size={16} /></button>
                                    <button className="p-1 text-gray-400 hover:text-red-600"><Trash size={16} /></button>
                                </div>
                            </div>
                            <p className="text-sm text-gray-600 ml-6 mb-2">{faq.a}</p>
                            <span className="ml-6 inline-block bg-gray-100 text-gray-500 text-xs px-2 py-1 rounded">{faq.cat}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};