import React, { useState } from 'react';
import { 
  Search, Filter, ExternalLink, CheckCircle, X, 
  Smartphone, ShoppingCart, Briefcase, FileText, 
  Globe, MessageSquare, Database, Server, Settings,
  Zap, CloudLightning, Shield, LayoutGrid, List, Send,
  Megaphone, Truck, BarChart2, Lock, Map, MapPin
} from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

type Category = 'All' | 'Government' | 'E-commerce' | 'Accounting' | 'Communication' | 'CRM' | 'Productivity' | 'Payment' | 'Marketing' | 'ERP' | 'Logistics';

interface AppItem {
  id: string;
  name: string;
  category: Category;
  description: string;
  icon?: React.ReactNode;
  color: string;
  connected: boolean;
  featured?: boolean;
}

const AppLogo: React.FC<{ app: AppItem }> = ({ app }) => (
  <div className={`w-14 h-14 rounded-xl flex items-center justify-center shadow-sm text-white font-bold text-xl mb-4 ${app.color}`}>
    {app.icon || app.name.substring(0, 2).toUpperCase()}
  </div>
);

export const AppMarketplace: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<Category>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [showModal, setShowModal] = useState<string | null>(null);
  const [connectedApps, setConnectedApps] = useState<string[]>(['1', '4', '8', '23']); // Mock connected IDs

  // Extensive Mock Database of Apps
  const apps: AppItem[] = [
    // --- Featured / Automation ---
    { id: '23', name: 'Zapier', category: 'Productivity', description: 'Connect with 5000+ other apps instantly.', color: 'bg-orange-600', icon: <Zap />, connected: true, featured: true },
    { id: '99', name: 'Make (Integromat)', category: 'Productivity', description: 'Visual automation platform.', color: 'bg-purple-700', icon: <Zap />, connected: false },

    // --- Government (KSA) ---
    { id: '6', name: 'Absher', category: 'Government', description: 'KSA Government services verification.', color: 'bg-green-700', icon: <Shield />, connected: false, featured: true },
    { id: '7', name: 'ZATCA (Fatoora)', category: 'Government', description: 'E-invoicing integration for tax compliance.', color: 'bg-blue-800', icon: <FileText />, connected: false, featured: true },
    { id: '8', name: 'Muqeem', category: 'Government', description: 'Resident data verification services.', color: 'bg-emerald-600', icon: <Shield />, connected: true },
    { id: '9', name: 'Qiwa', category: 'Government', description: 'Labor ministry compliance contracts.', color: 'bg-teal-600', icon: <Briefcase />, connected: false },
    { id: '10', name: 'Tamm', category: 'Government', description: 'Traffic and vehicle services integration.', color: 'bg-gray-700', icon: <Car />, connected: false },
    { id: '101', name: 'Najiz', category: 'Government', description: 'Ministry of Justice services integration.', color: 'bg-emerald-800', icon: <Briefcase />, connected: false },
    { id: '102', name: 'Balady', category: 'Government', description: 'Municipal licensing and maps.', color: 'bg-green-600', icon: <Map />, connected: false },
    { id: '103', name: 'Mudad', category: 'Government', description: 'Payroll and compliance management.', color: 'bg-blue-900', icon: <FileText />, connected: false },
    { id: '104', name: 'SPL (Saudi Post)', category: 'Government', description: 'National address verification.', color: 'bg-blue-700', icon: <MapPin />, connected: false },
    { id: '105', name: 'GOSI', category: 'Government', description: 'Social insurance data sync.', color: 'bg-green-500', icon: <Shield />, connected: false },

    // --- E-commerce ---
    { id: '1', name: 'Zid', category: 'E-commerce', description: 'Sync products and orders with Zid.', color: 'bg-purple-600', connected: true, featured: true },
    { id: '2', name: 'Salla', category: 'E-commerce', description: 'Connect Salla store for shipping.', color: 'bg-green-500', icon: <ShoppingCart />, connected: false, featured: true },
    { id: '3', name: 'Shopify', category: 'E-commerce', description: 'Global e-commerce platform.', color: 'bg-lime-600', icon: <ShoppingCart />, connected: false },
    { id: '4', name: 'WooCommerce', category: 'E-commerce', description: 'WordPress e-commerce plugin.', color: 'bg-purple-800', icon: <ShoppingCart />, connected: true },
    { id: '5', name: 'Magento', category: 'E-commerce', description: 'Adobe Commerce integration.', color: 'bg-orange-600', icon: <ShoppingCart />, connected: false },
    { id: '301', name: 'Amazon Seller', category: 'E-commerce', description: 'Sync Amazon KSA orders.', color: 'bg-orange-500', icon: <ShoppingCart />, connected: false },
    { id: '302', name: 'Noon', category: 'E-commerce', description: 'Noon marketplace integration.', color: 'bg-yellow-400', icon: <ShoppingCart />, connected: false },
    { id: '303', name: 'BigCommerce', category: 'E-commerce', description: 'Enterprise ecommerce solution.', color: 'bg-blue-900', icon: <ShoppingCart />, connected: false },
    { id: '304', name: 'OpenCart', category: 'E-commerce', description: 'Open source PHP store.', color: 'bg-sky-500', icon: <ShoppingCart />, connected: false },
    { id: '305', name: 'Wix Stores', category: 'E-commerce', description: 'Wix website builder store.', color: 'bg-gray-800', icon: <Globe />, connected: false },

    // --- Accounting / ERP ---
    { id: '11', name: 'QuickBooks', category: 'Accounting', description: 'Sync invoices and expenses.', color: 'bg-green-600', icon: <DollarSign />, connected: false },
    { id: '12', name: 'Xero', category: 'Accounting', description: 'Cloud accounting software.', color: 'bg-blue-500', icon: <DollarSign />, connected: false },
    { id: '13', name: 'Zoho Books', category: 'Accounting', description: 'Online accounting for business.', color: 'bg-yellow-600', icon: <DollarSign />, connected: false },
    { id: '14', name: 'Daftra', category: 'Accounting', description: 'Arabic invoicing software.', color: 'bg-blue-600', icon: <FileText />, connected: false },
    { id: '15', name: 'Qoyod', category: 'Accounting', description: 'Easy accounting for KSA SMEs.', color: 'bg-cyan-600', icon: <FileText />, connected: false },
    { id: '201', name: 'Oracle NetSuite', category: 'ERP', description: 'Unified business management suite.', color: 'bg-blue-900', icon: <Database />, connected: false },
    { id: '202', name: 'SAP Business One', category: 'ERP', description: 'Enterprise resource planning.', color: 'bg-gray-700', icon: <Server />, connected: false },
    { id: '203', name: 'Microsoft Dynamics', category: 'ERP', description: 'Dynamics 365 Finance & Ops.', color: 'bg-indigo-700', icon: <Server />, connected: false },
    { id: '204', name: 'Odoo', category: 'ERP', description: 'Open source ERP and CRM.', color: 'bg-purple-500', icon: <Database />, connected: false },
    { id: '205', name: 'Wafeq', category: 'Accounting', description: 'Accounting built for MENA.', color: 'bg-teal-500', icon: <FileText />, connected: false },

    // --- Communication ---
    { id: '16', name: 'Slack', category: 'Communication', description: 'Team communication.', color: 'bg-fuchsia-700', icon: <MessageSquare />, connected: false },
    { id: '17', name: 'MS Teams', category: 'Communication', description: 'Collaborate and meet.', color: 'bg-indigo-600', icon: <MessageSquare />, connected: false },
    { id: '18', name: 'WhatsApp', category: 'Communication', description: 'Business API for alerts.', color: 'bg-green-500', icon: <Smartphone />, connected: false },
    { id: '19', name: 'Telegram', category: 'Communication', description: 'Bot integration for alerts.', color: 'bg-sky-500', icon: <Send />, connected: false },
    { id: '401', name: 'Zoom', category: 'Communication', description: 'Video conferencing.', color: 'bg-blue-500', icon: <Smartphone />, connected: false },
    { id: '402', name: 'Google Meet', category: 'Communication', description: 'Video meetings.', color: 'bg-green-600', icon: <Smartphone />, connected: false },
    { id: '403', name: 'Discord', category: 'Communication', description: 'Community chat server.', color: 'bg-indigo-500', icon: <MessageSquare />, connected: false },
    { id: '404', name: 'Intercom', category: 'Communication', description: 'Customer messaging platform.', color: 'bg-blue-600', icon: <MessageSquare />, connected: false },

    // --- CRM ---
    { id: '20', name: 'Salesforce', category: 'CRM', description: 'Customer relationship mgmt.', color: 'bg-blue-500', icon: <CloudLightning />, connected: false },
    { id: '21', name: 'HubSpot', category: 'CRM', description: 'Inbound marketing & sales.', color: 'bg-orange-500', icon: <Briefcase />, connected: false },
    { id: '22', name: 'Zoho CRM', category: 'CRM', description: 'Close deals smarter.', color: 'bg-yellow-500', icon: <Briefcase />, connected: false },
    { id: '501', name: 'Pipedrive', category: 'CRM', description: 'Sales CRM pipeline.', color: 'bg-green-700', icon: <BarChart2 />, connected: false },
    { id: '502', name: 'Zendesk', category: 'CRM', description: 'Customer service software.', color: 'bg-green-800', icon: <Headphones />, connected: false },

    // --- Marketing ---
    { id: '601', name: 'Mailchimp', category: 'Marketing', description: 'Email marketing automation.', color: 'bg-yellow-400', icon: <Megaphone />, connected: false },
    { id: '602', name: 'Google Ads', category: 'Marketing', description: 'Ad campaign tracking.', color: 'bg-blue-600', icon: <Globe />, connected: false },
    { id: '603', name: 'Facebook Ads', category: 'Marketing', description: 'Social media ad manager.', color: 'bg-blue-700', icon: <Megaphone />, connected: false },
    { id: '604', name: 'TikTok Ads', category: 'Marketing', description: 'Video ad campaigns.', color: 'bg-black', icon: <Smartphone />, connected: false },
    { id: '605', name: 'Snapchat Ads', category: 'Marketing', description: 'Snap pixel integration.', color: 'bg-yellow-300', icon: <Smartphone />, connected: false },
    { id: '606', name: 'Klaviyo', category: 'Marketing', description: 'Ecommerce marketing.', color: 'bg-green-900', icon: <Megaphone />, connected: false },

    // --- Productivity ---
    { id: '24', name: 'Google Sheets', category: 'Productivity', description: 'Export data to sheets.', color: 'bg-green-600', icon: <FileText />, connected: false },
    { id: '25', name: 'Trello', category: 'Productivity', description: 'Kanban boards.', color: 'bg-blue-600', icon: <LayoutGrid />, connected: false },
    { id: '701', name: 'Asana', category: 'Productivity', description: 'Work management.', color: 'bg-red-400', icon: <LayoutGrid />, connected: false },
    { id: '702', name: 'Monday.com', category: 'Productivity', description: 'Work OS.', color: 'bg-purple-500', icon: <LayoutGrid />, connected: false },
    { id: '703', name: 'Notion', category: 'Productivity', description: 'All-in-one workspace.', color: 'bg-black', icon: <FileText />, connected: false },
    { id: '704', name: 'ClickUp', category: 'Productivity', description: 'One app to replace them all.', color: 'bg-purple-600', icon: <LayoutGrid />, connected: false },
    { id: '705', name: 'Dropbox', category: 'Productivity', description: 'File storage & sharing.', color: 'bg-blue-500', icon: <Database />, connected: false },
    
    // --- Payment ---
    { id: '26', name: 'Tamara', category: 'Payment', description: 'Buy now pay later.', color: 'bg-pink-500', icon: <CreditCard />, connected: false },
    { id: '27', name: 'Tabby', category: 'Payment', description: 'Split payments.', color: 'bg-green-400', icon: <CreditCard />, connected: false },
    { id: '28', name: 'Stripe', category: 'Payment', description: 'Global payments.', color: 'bg-indigo-700', icon: <CreditCard />, connected: false },
    { id: '29', name: 'Moyasar', category: 'Payment', description: 'KSA Payment gateway.', color: 'bg-blue-800', icon: <CreditCard />, connected: false },
    { id: '30', name: 'HyperPay', category: 'Payment', description: 'MENA payment gateway.', color: 'bg-red-600', icon: <CreditCard />, connected: false },
    { id: '801', name: 'STC Pay', category: 'Payment', description: 'Digital wallet payments.', color: 'bg-purple-600', icon: <Smartphone />, connected: false },
    { id: '802', name: 'Urpay', category: 'Payment', description: 'Digital wallet.', color: 'bg-blue-500', icon: <Smartphone />, connected: false },
    { id: '803', name: 'Checkout.com', category: 'Payment', description: 'Enterprise payments.', color: 'bg-black', icon: <CreditCard />, connected: false },
    { id: '804', name: 'PayPal', category: 'Payment', description: 'Global wallet.', color: 'bg-blue-700', icon: <CreditCard />, connected: false },

    // --- Logistics Partners ---
    { id: '901', name: 'SMSA', category: 'Logistics', description: 'Domestic shipping.', color: 'bg-orange-600', icon: <Truck />, connected: false },
    { id: '902', name: 'Aramex', category: 'Logistics', description: 'Global logistics.', color: 'bg-red-600', icon: <Truck />, connected: false },
    { id: '903', name: 'DHL', category: 'Logistics', description: 'International courier.', color: 'bg-yellow-500', icon: <Truck />, connected: false },
    { id: '904', name: 'J&T Express', category: 'Logistics', description: 'Express delivery.', color: 'bg-red-500', icon: <Truck />, connected: false },
    { id: '905', name: 'Google Maps', category: 'Logistics', description: 'Mapping services.', color: 'bg-green-500', icon: <MapPin />, connected: false },
  ];

  const categories: Category[] = ['All', 'Government', 'E-commerce', 'Accounting', 'ERP', 'Communication', 'CRM', 'Marketing', 'Productivity', 'Payment', 'Logistics'];

  const filteredApps = apps.filter(app => {
    const matchesCategory = selectedCategory === 'All' || app.category === selectedCategory;
    const matchesSearch = app.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleConnect = (id: string) => {
    // Toggle connection status mock
    if (connectedApps.includes(id)) {
        if(confirm('Disconnect this app? Integration will stop working.')) {
            setConnectedApps(prev => prev.filter(appId => appId !== id));
        }
    } else {
        setShowModal(id);
    }
  };

  const confirmConnection = (id: string) => {
      setConnectedApps(prev => [...prev, id]);
      setShowModal(null);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <Header 
        title="App Marketplace" 
        description="Connect LogiMaster with 300+ applications to automate your workflow." 
        action={
            <div className="flex gap-2">
                <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 flex items-center gap-2">
                    <Zap size={16} className="text-orange-500" /> My Zaps
                </button>
            </div>
        }
      />

      <div className="flex-1 flex gap-6 overflow-hidden">
        {/* Sidebar Filters */}
        <div className="w-64 flex-shrink-0 bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col overflow-y-auto">
            <div className="p-4 border-b border-gray-200">
                <h3 className="font-semibold text-gray-900 mb-2">Categories</h3>
            </div>
            <div className="p-2 space-y-1">
                {categories.map(cat => (
                    <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className={`w-full text-left px-4 py-2 rounded-lg text-sm font-medium transition-colors flex justify-between items-center ${
                            selectedCategory === cat ? 'bg-blue-50 text-blue-700' : 'text-gray-600 hover:bg-gray-50'
                        }`}
                    >
                        {cat}
                        {selectedCategory === cat && <CheckCircle size={14} />}
                    </button>
                ))}
            </div>
            
            <div className="p-4 mt-auto border-t border-gray-200">
                <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-4 rounded-xl border border-orange-200 text-center">
                    <Zap size={24} className="mx-auto text-orange-600 mb-2" />
                    <h4 className="font-bold text-orange-900 text-sm">Zapier Integration</h4>
                    <p className="text-xs text-orange-700 mb-3 mt-1">Connect with 5000+ apps instantly via our official Zapier plugin.</p>
                    <button className="text-xs bg-orange-600 text-white px-3 py-1.5 rounded-lg hover:bg-orange-700 w-full">Configure Zapier</button>
                </div>
            </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col bg-gray-50 rounded-xl">
            {/* Search Bar */}
            <div className="mb-6 relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input 
                    type="text" 
                    placeholder="Search for apps (e.g. Absher, QuickBooks, Zid)..." 
                    className="w-full pl-12 pr-4 py-4 bg-white border border-gray-200 rounded-xl shadow-sm outline-none focus:ring-2 focus:ring-blue-500 text-lg"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
            </div>

            {/* Apps Grid */}
            <div className="flex-1 overflow-y-auto pr-2 pb-10">
                
                {/* Featured Section (Only shows when 'All' is selected and no search) */}
                {selectedCategory === 'All' && !searchQuery && (
                    <div className="mb-8">
                        <h3 className="font-bold text-gray-800 text-lg mb-4 flex items-center gap-2">
                            <Zap size={20} className="text-yellow-500" /> Featured Integrations
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                            {apps.filter(a => a.featured).map(app => (
                                <div key={app.id} className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow flex flex-col items-center text-center group relative overflow-hidden h-full">
                                    <div className={`absolute top-0 left-0 w-full h-1 ${app.color}`}></div>
                                    <AppLogo app={app} />
                                    <h4 className="font-bold text-gray-900 mb-1">{app.name}</h4>
                                    <span className="text-[10px] uppercase tracking-wider text-gray-400 font-semibold mb-3">{app.category}</span>
                                    <p className="text-sm text-gray-500 mb-4 line-clamp-2">{app.description}</p>
                                    <button 
                                        onClick={() => handleConnect(app.id)}
                                        className={`mt-auto px-6 py-2 rounded-full text-sm font-medium transition-all ${
                                            connectedApps.includes(app.id) 
                                            ? 'bg-green-100 text-green-700 border border-green-200' 
                                            : 'bg-gray-900 text-white hover:bg-gray-800'
                                        }`}
                                    >
                                        {connectedApps.includes(app.id) ? 'Connected' : 'Connect'}
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                <h3 className="font-bold text-gray-800 text-lg mb-4">
                    {searchQuery ? `Search Results for "${searchQuery}"` : `All ${selectedCategory} Apps (${filteredApps.length})`}
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {filteredApps.map(app => (
                        <div key={app.id} className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm hover:border-blue-300 transition-colors flex flex-col h-full">
                            <div className="flex items-start justify-between mb-4">
                                <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold text-sm ${app.color}`}>
                                    {app.icon || app.name.substring(0, 1)}
                                </div>
                                {connectedApps.includes(app.id) && <CheckCircle size={16} className="text-green-500" />}
                            </div>
                            <h4 className="font-bold text-gray-900">{app.name}</h4>
                            <span className="text-[10px] text-gray-400 font-semibold uppercase mb-2">{app.category}</span>
                            <p className="text-xs text-gray-500 mb-4 flex-1 line-clamp-2">{app.description}</p>
                            <button 
                                onClick={() => handleConnect(app.id)}
                                className={`w-full py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-colors ${
                                    connectedApps.includes(app.id)
                                    ? 'bg-white border border-gray-300 text-gray-500'
                                    : 'bg-blue-50 text-blue-600 hover:bg-blue-100'
                                }`}
                            >
                                {connectedApps.includes(app.id) ? 'Manage' : 'Connect'}
                            </button>
                        </div>
                    ))}
                    {filteredApps.length === 0 && (
                        <div className="col-span-full py-20 text-center text-gray-400">
                            <Search size={48} className="mx-auto mb-4 opacity-20" />
                            <p className="text-lg font-medium">No apps found matching your criteria.</p>
                            <p className="text-sm">Try checking your spelling or selecting a different category.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
      </div>

      {/* Connection Modal */}
      {showModal && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200">
                  <div className={`h-24 ${apps.find(a => a.id === showModal)?.color || 'bg-gray-500'} flex items-center justify-center`}>
                      <div className="w-16 h-16 bg-white rounded-xl shadow-lg flex items-center justify-center text-2xl font-bold">
                          {apps.find(a => a.id === showModal)?.icon || apps.find(a => a.id === showModal)?.name.substring(0, 1)}
                      </div>
                  </div>
                  <div className="p-6">
                      <div className="text-center mb-6">
                          <h3 className="text-xl font-bold text-gray-900">Connect {apps.find(a => a.id === showModal)?.name}</h3>
                          <p className="text-sm text-gray-500">Allow LogiMaster to access your {apps.find(a => a.id === showModal)?.name} account to sync data.</p>
                      </div>

                      <div className="space-y-4 mb-6">
                          <div>
                              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">API Key / Client ID</label>
                              <input type="text" className="w-full px-4 py-2 border border-gray-300 rounded-lg text-sm" placeholder="Paste key here..." />
                          </div>
                          <div>
                              <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Secret Key</label>
                              <input type="password" className="w-full px-4 py-2 border border-gray-300 rounded-lg text-sm" placeholder="••••••••••••••" />
                          </div>
                      </div>

                      <div className="flex gap-3">
                          <button onClick={() => setShowModal(null)} className="flex-1 py-2.5 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200">Cancel</button>
                          <button onClick={() => confirmConnection(showModal)} className="flex-1 py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700">Authorize Connection</button>
                      </div>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

// Helper components for icons that weren't imported but used in data
function DollarSign(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg> }
function Car(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/></svg> }
function CreditCard(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg> }
function Headphones(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"></path><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"></path></svg> }