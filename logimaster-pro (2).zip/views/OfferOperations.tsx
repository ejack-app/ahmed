
import React, { useState } from 'react';
import { Tags, Plus, Search, Gift, Percent, Calendar, Save } from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Bundle-Offers List
export const BundleOffersList: React.FC = () => {
    // In a real scenario, fetch this from API
    const [offers, setOffers] = useState([
        { name: 'Summer Sale Pack', items: ['T-Shirt White', 'Shorts Blue'], price: 'SAR 99', original: 'SAR 150', status: 'Active', expiry: '2024-06-30' },
        { name: 'Tech Starter Kit', items: ['Mouse', 'Keyboard', 'Mousepad'], price: 'SAR 250', original: 'SAR 320', status: 'Active', expiry: '2024-12-31' },
    ]);

    return (
        <div>
            <Header 
                title="Bundle Offers" 
                description="Manage active promotional bundles."
                action={
                     <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Plus size={16} /> Create Bundle
                    </button>
                }
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {offers.map((offer, i) => (
                    <div key={i} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 relative overflow-hidden group">
                        <div className={`absolute top-0 right-0 px-3 py-1 text-xs font-bold rounded-bl-lg ${offer.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                            {offer.status}
                        </div>
                        <div className="flex items-center gap-3 mb-4">
                            <div className="p-3 bg-pink-50 text-pink-600 rounded-lg">
                                <Gift size={24} />
                            </div>
                            <div>
                                <h3 className="font-bold text-gray-900">{offer.name}</h3>
                                <p className="text-xs text-gray-500">Expires: {offer.expiry}</p>
                            </div>
                        </div>
                        
                        <div className="space-y-2 mb-4">
                            {offer.items.map((item, idx) => (
                                <div key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                                    <div className="w-1.5 h-1.5 bg-gray-300 rounded-full"></div>
                                    {item}
                                </div>
                            ))}
                        </div>

                        <div className="pt-4 border-t border-gray-100 flex justify-between items-center">
                            <div>
                                <span className="text-lg font-bold text-gray-900">{offer.price}</span>
                                <span className="text-sm text-gray-400 line-through ml-2">{offer.original}</span>
                            </div>
                             <button className="text-sm font-medium text-blue-600 hover:underline">Edit</button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

// 2. Add New Bundle
export const AddBundle: React.FC = () => {
    const handleSave = () => {
        alert("Bundle Created Successfully");
        // In real app: api.post('/offers', formData)
    };

    return (
        <div className="max-w-3xl mx-auto pb-10">
            <Header title="Create New Bundle" description="Combine multiple items into a single promotional offer." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Bundle Name</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. Winter Essentials Pack" />
                    </div>
                    
                    <div className="md:col-span-2">
                         <label className="block text-sm font-medium text-gray-700 mb-1.5">Select Items</label>
                         <div className="border border-gray-300 rounded-lg p-2 flex flex-wrap gap-2 min-h-[50px] bg-gray-50">
                             <span className="bg-white border border-gray-200 px-2 py-1 rounded text-sm flex items-center gap-1">
                                 SKU-001 <button className="text-gray-400 hover:text-red-500">×</button>
                             </span>
                             <input type="text" className="bg-transparent outline-none flex-1 text-sm min-w-[100px]" placeholder="Type to search SKU..." />
                         </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Bundle Price (SAR)</label>
                        <input type="number" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="0.00" />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Original Price (Display Only)</label>
                        <input type="number" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="0.00" />
                    </div>

                    <div>
                         <label className="block text-sm font-medium text-gray-700 mb-1.5">Start Date</label>
                         <div className="relative">
                            <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                            <input type="date" className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg" />
                         </div>
                    </div>
                     <div>
                         <label className="block text-sm font-medium text-gray-700 mb-1.5">End Date</label>
                         <div className="relative">
                            <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                            <input type="date" className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg" />
                         </div>
                    </div>
                </div>
                 <div className="mt-8 flex justify-end gap-3">
                    <button className="px-5 py-2.5 text-gray-700 hover:bg-gray-100 rounded-lg font-medium">Cancel</button>
                    <button onClick={handleSave} className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                        <Save size={18} /> Save Bundle
                    </button>
                </div>
            </div>
        </div>
    );
};

// 3. Bundle - Orders List
export const BundleOrdersList: React.FC = () => {
    return (
        <div>
            <Header title="Bundle Orders" description="Orders that contain promotional bundles." />
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                     <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search Order ID..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Order ID</th>
                            <th className="px-6 py-4">Bundle Name</th>
                            <th className="px-6 py-4">Customer</th>
                            <th className="px-6 py-4">Date</th>
                            <th className="px-6 py-4">Amount</th>
                             <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        <tr className="hover:bg-gray-50">
                            <td className="px-6 py-4 font-mono font-medium text-blue-600">ORD-1092</td>
                            <td className="px-6 py-4"><span className="bg-pink-100 text-pink-700 px-2 py-1 rounded text-xs font-bold">Summer Sale Pack</span></td>
                            <td className="px-6 py-4">Mona Al-Sabah</td>
                            <td className="px-6 py-4">2024-02-21</td>
                            <td className="px-6 py-4">SAR 99</td>
                            <td className="px-6 py-4 text-right"><button className="text-gray-400 hover:text-gray-600">View</button></td>
                        </tr>
                        <tr className="hover:bg-gray-50">
                            <td className="px-6 py-4 font-mono font-medium text-blue-600">ORD-1095</td>
                            <td className="px-6 py-4"><span className="bg-pink-100 text-pink-700 px-2 py-1 rounded text-xs font-bold">Tech Starter Kit</span></td>
                            <td className="px-6 py-4">Khalid Bin Walid</td>
                            <td className="px-6 py-4">2024-02-21</td>
                            <td className="px-6 py-4">SAR 250</td>
                             <td className="px-6 py-4 text-right"><button className="text-gray-400 hover:text-gray-600">View</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
};
