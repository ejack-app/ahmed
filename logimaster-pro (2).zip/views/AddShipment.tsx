import React, { useState, useEffect } from 'react';
import { Save, User, MapPin, Package, CreditCard, Calendar, Truck, AlertCircle } from 'lucide-react';

const Header: React.FC<{ title: string; description: string }> = ({ title, description }) => (
  <div className="mb-6">
    <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
    <p className="text-sm text-gray-500">{description}</p>
  </div>
);

export const AddShipment: React.FC = () => {
  const [showForm, setShowForm] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  
  const [formData, setFormData] = useState({
    uniqueid: '',
    booking_id: '',
    schedule_date: new Date().toISOString().split('T')[0],
    time_slot: '10:00',
    nrd: 'Parcel', // Product Type
    booking_mode: 'COD',
    total_cod_amt: '',
    shippers_ac_no: '',
    
    // Sender
    sender_name: '',
    sender_country: '',
    sender_city: '',
    sender_zip: '',
    sender_address: '',
    sender_phone: '',
    sender_email: '',
    
    // Receiver
    reciever_name: '',
    reciever_country: '',
    reciever_city: '',
    reciever_zip: '',
    reciever_address: '',
    reciever_phone: '',
    reciever_email: '',
    
    // Service & Payment
    pieces: '1',
    service_id: '',
    declared_charge: '',
    status_describtion: '',
    sku: '',
    weight: '',
    service_charge: '',
    service_tax: '',
    other_charges: '',
    total_amt: ''
  });

  const checkUid = () => {
    // Mock logic for checking UID
    if (formData.uniqueid === '123') {
        setShowForm(true);
        setErrorMsg('');
        // Mock prefill sender data
        setFormData(prev => ({
            ...prev,
            sender_name: 'LogiMaster Store HQ',
            sender_country: 'SA',
            sender_city: 'Riyadh',
            sender_address: 'King Fahd Road, Olaya',
            sender_phone: '0501234567',
            sender_email: 'store@logimaster.sa',
            shippers_ac_no: 'ACC-8821'
        }));
    } else {
        setShowForm(false);
        setErrorMsg('No record found against this UID (Try "123")');
    }
  };

  const handleWeightChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const weight = parseFloat(e.target.value) || 0;
      // Mock calculation logic
      const baseCharge = 25;
      const ratePerKg = 2;
      const serviceCharge = baseCharge + (weight * ratePerKg);
      
      setFormData(prev => ({
          ...prev,
          weight: e.target.value,
          service_charge: serviceCharge.toFixed(2),
          total_amt: serviceCharge.toFixed(2)
      }));
  };

  return (
    <div className="max-w-6xl mx-auto pb-10">
      <Header title="Add Shipment" description="Create a new shipment manually." />

      {/* UID Search Section */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
        <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <User size={18} className="text-blue-600" /> Account Lookup
        </h3>
        <div className="flex flex-col md:flex-row gap-4 items-start">
            <div className="flex-1 w-full">
                <input 
                    type="text" 
                    placeholder="Enter UID / Account No. (Try '123')" 
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                    value={formData.uniqueid}
                    onChange={(e) => setFormData({...formData, uniqueid: e.target.value})}
                    onKeyDown={(e) => e.key === 'Enter' && checkUid()}
                />
                {errorMsg && (
                    <div className="mt-2 text-red-600 text-sm flex items-center gap-1">
                        <AlertCircle size={14} /> {errorMsg}
                    </div>
                )}
            </div>
            <button 
                onClick={checkUid}
                className="px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700"
            >
                Verify Account
            </button>
        </div>
      </div>

      {showForm && (
        <div className="space-y-6">
            
            {/* Row 1: Date & Type */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Date & Time */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                        <Calendar size={18} className="text-blue-600" /> Date & Time
                    </h3>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Reference ID</label>
                            <input 
                                type="text" 
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                                value={formData.booking_id}
                                onChange={(e) => setFormData({...formData, booking_id: e.target.value})}
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                                <input 
                                    type="date" 
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                                    value={formData.schedule_date}
                                    onChange={(e) => setFormData({...formData, schedule_date: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Time</label>
                                <input 
                                    type="time" 
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                                    value={formData.time_slot}
                                    onChange={(e) => setFormData({...formData, time_slot: e.target.value})}
                                />
                            </div>
                        </div>
                    </div>
                </div>

                {/* Shipment Type */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                        <Package size={18} className="text-blue-600" /> Shipment Details
                    </h3>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Product Type</label>
                            <div className="flex items-center gap-2 mt-2">
                                <input type="radio" checked readOnly className="text-blue-600" />
                                <span>Parcel</span>
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Payment Mode</label>
                                <select 
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                                    value={formData.booking_mode}
                                    onChange={(e) => setFormData({...formData, booking_mode: e.target.value})}
                                >
                                    <option value="CC">Credit Card</option>
                                    <option value="COD">Cash on Delivery</option>
                                </select>
                            </div>
                            {formData.booking_mode === 'COD' && (
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">COD Amount</label>
                                    <input 
                                        type="number" 
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                                        value={formData.total_cod_amt}
                                        onChange={(e) => setFormData({...formData, total_cod_amt: e.target.value})}
                                    />
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {/* Row 2: Location Info */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex justify-between items-center mb-6 border-b border-gray-100 pb-4">
                    <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                        <MapPin size={18} className="text-blue-600" /> Location Information
                    </h3>
                    <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-500">Shipper Ac No:</span>
                        <input 
                            type="text" 
                            className="border border-gray-300 rounded px-2 py-1 text-sm w-32"
                            value={formData.shippers_ac_no}
                            onChange={(e) => setFormData({...formData, shippers_ac_no: e.target.value})}
                        />
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Sender */}
                    <div className="space-y-4">
                        <h4 className="font-medium text-gray-800 border-b border-gray-100 pb-2">Sender Info</h4>
                        <div>
                            <label className="block text-sm text-gray-600 mb-1">Name <span className="text-red-500">*</span></label>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.sender_name} onChange={(e) => setFormData({...formData, sender_name: e.target.value})} />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm text-gray-600 mb-1">Country</label>
                                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.sender_country} onChange={(e) => setFormData({...formData, sender_country: e.target.value})}>
                                    <option value="">Select Country</option>
                                    <option value="SA">Saudi Arabia</option>
                                    <option value="AE">UAE</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm text-gray-600 mb-1">City</label>
                                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.sender_city} onChange={(e) => setFormData({...formData, sender_city: e.target.value})}>
                                    <option value="">Select City</option>
                                    <option value="Riyadh">Riyadh</option>
                                    <option value="Jeddah">Jeddah</option>
                                    <option value="Dammam">Dammam</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm text-gray-600 mb-1">Address</label>
                            <textarea rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg resize-none" value={formData.sender_address} onChange={(e) => setFormData({...formData, sender_address: e.target.value})}></textarea>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm text-gray-600 mb-1">Mobile</label>
                                <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.sender_phone} onChange={(e) => setFormData({...formData, sender_phone: e.target.value})} />
                            </div>
                            <div>
                                <label className="block text-sm text-gray-600 mb-1">Email</label>
                                <input type="email" className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.sender_email} onChange={(e) => setFormData({...formData, sender_email: e.target.value})} />
                            </div>
                        </div>
                    </div>

                    {/* Receiver */}
                    <div className="space-y-4">
                        <h4 className="font-medium text-gray-800 border-b border-gray-100 pb-2">Receiver Info</h4>
                        <div>
                            <label className="block text-sm text-gray-600 mb-1">Name <span className="text-red-500">*</span></label>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.reciever_name} onChange={(e) => setFormData({...formData, reciever_name: e.target.value})} />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm text-gray-600 mb-1">Country</label>
                                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.reciever_country} onChange={(e) => setFormData({...formData, reciever_country: e.target.value})}>
                                    <option value="">Select Country</option>
                                    <option value="SA">Saudi Arabia</option>
                                    <option value="AE">UAE</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm text-gray-600 mb-1">City</label>
                                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.reciever_city} onChange={(e) => setFormData({...formData, reciever_city: e.target.value})}>
                                    <option value="">Select City</option>
                                    <option value="Riyadh">Riyadh</option>
                                    <option value="Jeddah">Jeddah</option>
                                    <option value="Dammam">Dammam</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm text-gray-600 mb-1">Address</label>
                            <textarea rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg resize-none" value={formData.reciever_address} onChange={(e) => setFormData({...formData, reciever_address: e.target.value})}></textarea>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm text-gray-600 mb-1">Mobile</label>
                                <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.reciever_phone} onChange={(e) => setFormData({...formData, reciever_phone: e.target.value})} />
                            </div>
                            <div>
                                <label className="block text-sm text-gray-600 mb-1">Email</label>
                                <input type="email" className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.reciever_email} onChange={(e) => setFormData({...formData, reciever_email: e.target.value})} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Row 3: Service & Payment */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Services */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                        <Truck size={18} className="text-blue-600" /> Service Information
                    </h3>
                    <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Service Mode</label>
                                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.service_id} onChange={(e) => setFormData({...formData, service_id: e.target.value})}>
                                    <option value="">Select Service</option>
                                    <option value="1">Express Delivery</option>
                                    <option value="2">Standard Delivery</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Shipment Value</label>
                                <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.declared_charge} onChange={(e) => setFormData({...formData, declared_charge: e.target.value})} />
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                            <textarea rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg resize-none" value={formData.status_describtion} onChange={(e) => setFormData({...formData, status_describtion: e.target.value})}></textarea>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">No of Pieces</label>
                                <input type="number" className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.pieces} onChange={(e) => setFormData({...formData, pieces: e.target.value})} />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">SKU</label>
                                <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.sku} onChange={(e) => setFormData({...formData, sku: e.target.value})} />
                            </div>
                        </div>
                    </div>
                </div>

                {/* Payment Detail */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                        <CreditCard size={18} className="text-blue-600" /> Payment Details
                    </h3>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Total Weight (Kg)</label>
                            <input type="number" className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.weight} onChange={handleWeightChange} />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Charge (SAR)</label>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50" readOnly value={formData.service_charge} />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">COD Fees (SAR)</label>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.service_tax} onChange={(e) => setFormData({...formData, service_tax: e.target.value})} />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Additional Charge (SAR)</label>
                            <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg" value={formData.other_charges} onChange={(e) => setFormData({...formData, other_charges: e.target.value})} />
                        </div>
                        <div className="pt-2 border-t border-gray-100">
                            <label className="block text-lg font-bold text-gray-900 mb-1">Total Charge (SAR)</label>
                            <input type="text" className="w-full px-4 py-3 border border-blue-300 bg-blue-50 text-blue-900 font-bold rounded-lg text-lg" readOnly value={formData.total_amt} />
                        </div>
                    </div>
                </div>
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-6 border-t border-gray-200">
                <button className="px-6 py-3 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium">
                    Cancel
                </button>
                <button className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                    <Save size={18} /> Submit & Save Shipment
                </button>
            </div>

        </div>
      )}
    </div>
  );
};