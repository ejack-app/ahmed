
import React, { useState } from 'react';
import { Gift, Printer, Search, Box, Check, ArrowRight, X } from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Packaging (Standard)
export const PackagingView: React.FC = () => {
    const [scanInput, setScanInput] = useState('');
    const [scannedItems, setScannedItems] = useState<string[]>([]);
    const [currentOrder, setCurrentOrder] = useState<any>(null);

    const handleScan = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter' && scanInput.trim()) {
            // Mock: If scanning order ID, set order. If scanning item, add to list.
            if(scanInput.startsWith('ORD')) {
                setCurrentOrder({ id: scanInput, items: ['SKU-001', 'SKU-002'] });
                setScannedItems([]);
            } else if (currentOrder) {
                setScannedItems(prev => [...prev, scanInput]);
            }
            setScanInput('');
        }
    };

    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Packaging Station" description="Scan items and generate shipping labels." />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Left: Input */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Scan Order / Item</label>
                        <div className="flex gap-2">
                             <input 
                                type="text" 
                                className="flex-1 px-4 py-3 border border-gray-300 rounded-lg text-lg font-mono focus:ring-2 focus:ring-blue-500 outline-none" 
                                placeholder="Scan Barcode..." 
                                autoFocus 
                                value={scanInput}
                                onChange={e => setScanInput(e.target.value)}
                                onKeyDown={handleScan}
                             />
                        </div>
                        <p className="text-xs text-gray-400 mt-2">1. Scan Order ID (e.g., ORD-1001) <br/> 2. Scan Items individually.</p>
                    </div>
                    
                    {!currentOrder ? (
                        <div className="bg-gray-50 p-4 rounded-lg border border-dashed border-gray-300 text-center py-12">
                            <Box className="mx-auto text-gray-300 mb-2" size={48} />
                            <p className="text-gray-500">Scan an Order ID to start</p>
                        </div>
                    ) : (
                        <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                            <h3 className="font-bold text-blue-900 mb-2">Packing: {currentOrder.id}</h3>
                            <div className="space-y-2">
                                {currentOrder.items.map((item: string, idx: number) => {
                                    const isScanned = scannedItems.includes(item);
                                    return (
                                        <div key={idx} className={`flex justify-between items-center p-2 rounded ${isScanned ? 'bg-green-100' : 'bg-white'}`}>
                                            <span className="font-mono text-sm">{item}</span>
                                            {isScanned ? <Check size={16} className="text-green-600"/> : <span className="text-xs text-gray-400">Waiting...</span>}
                                        </div>
                                    )
                                })}
                            </div>
                            {scannedItems.length === currentOrder.items.length && (
                                <button className="w-full mt-4 py-2 bg-green-600 text-white rounded font-bold shadow-lg animate-pulse">
                                    Print Label & Finish
                                </button>
                            )}
                        </div>
                    )}
                </div>

                {/* Right: Info Placeholder or History */}
                 <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 flex flex-col h-full">
                     <h3 className="font-semibold text-gray-700 mb-4">Recent Packed</h3>
                     <div className="flex-1 overflow-y-auto">
                         <div className="text-center text-gray-400 py-10">No recent history in this session.</div>
                     </div>
                 </div>
            </div>
        </div>
    );
};

// 2. Packaging With Todd
export const PackagingWithToddView: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Todd Packaging" description="Process items from a specific Tote (Todd) container." />
            
             <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                 <label className="block text-sm font-medium text-gray-700 mb-1.5">Scan Todd ID</label>
                 <div className="flex gap-2">
                     <input type="text" className="flex-1 px-4 py-3 border border-gray-300 rounded-lg text-lg font-mono text-blue-600 font-bold focus:ring-2 focus:ring-blue-500 outline-none" placeholder="TODD-XXXX" />
                     <button className="px-6 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Open Todd</button>
                 </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 opacity-50 pointer-events-none">
                 {/* Mock items inside Todd */}
                 {[1, 2, 3].map(i => (
                     <div key={i} className="bg-white p-4 rounded-xl border border-gray-200">
                         <div className="flex justify-between items-start">
                             <div className="w-12 h-12 bg-gray-100 rounded-lg mb-2"></div>
                             <span className="text-xs font-mono bg-gray-100 px-2 py-1 rounded">x1</span>
                         </div>
                         <h4 className="font-semibold text-gray-800 text-sm">Product Item #{i}</h4>
                         <p className="text-xs text-gray-500">SKU: PROD-00{i}</p>
                     </div>
                 ))}
            </div>
        </div>
    );
};
