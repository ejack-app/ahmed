
import React, { useState, useEffect } from 'react';
import { Ticket, Search, Filter, MessageSquare, AlertCircle, CheckCircle, Clock, Loader, Plus, Save } from 'lucide-react';
import { api } from '../utils/api';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Create Ticket Modal/Form
const CreateTicketForm: React.FC<{ onClose: () => void, onSuccess: () => void }> = ({ onClose, onSuccess }) => {
    const [formData, setFormData] = useState({ subject: '', type: 'Shipment Issue', priority: 'Medium', related_awb: '', description: '' });
    const [loading, setLoading] = useState(false);

    const handleSubmit = async () => {
        if(!formData.subject) return alert("Subject is required");
        setLoading(true);
        try {
            await api.post('/tickets', formData);
            alert("Ticket Created Successfully");
            onSuccess();
            onClose();
        } catch(e: any) {
            alert(e.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in duration-200">
                <div className="p-6 border-b border-gray-100 flex justify-between items-center">
                    <h3 className="font-bold text-lg text-gray-900">Open New Ticket</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600">&times;</button>
                </div>
                <div className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Subject</label>
                        <input type="text" className="w-full px-4 py-2 border border-gray-300 rounded-lg" placeholder="Brief summary of the issue" value={formData.subject} onChange={e => setFormData({...formData, subject: e.target.value})} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                            <select className="w-full px-4 py-2 border border-gray-300 rounded-lg" value={formData.type} onChange={e => setFormData({...formData, type: e.target.value})}>
                                <option>Shipment Issue</option>
                                <option>Billing</option>
                                <option>Technical Support</option>
                                <option>Other</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
                            <select className="w-full px-4 py-2 border border-gray-300 rounded-lg" value={formData.priority} onChange={e => setFormData({...formData, priority: e.target.value})}>
                                <option>Low</option>
                                <option>Medium</option>
                                <option>High</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Related AWB (Optional)</label>
                        <input type="text" className="w-full px-4 py-2 border border-gray-300 rounded-lg" placeholder="Enter Tracking Number" value={formData.related_awb} onChange={e => setFormData({...formData, related_awb: e.target.value})} />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                        <textarea rows={4} className="w-full px-4 py-2 border border-gray-300 rounded-lg resize-none" placeholder="Details..." value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})}></textarea>
                    </div>
                </div>
                <div className="p-4 bg-gray-50 flex justify-end gap-3">
                    <button onClick={onClose} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">Cancel</button>
                    <button onClick={handleSubmit} disabled={loading} className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50">
                        {loading ? 'Submitting...' : 'Submit Ticket'}
                    </button>
                </div>
            </div>
        </div>
    );
};

// 2. Ticket List Table
const TicketTable: React.FC<{ refreshTrigger: number }> = ({ refreshTrigger }) => {
    const [tickets, setTickets] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchTickets = async () => {
            setLoading(true);
            try {
                const data = await api.get('/tickets');
                setTickets(data);
            } catch (e) { console.error(e); }
            finally { setLoading(false); }
        };
        fetchTickets();
    }, [refreshTrigger]);

    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
             <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                    <input type="text" placeholder="Search Tickets..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                </div>
            </div>
             <table className="w-full text-left text-sm text-gray-600">
                <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                    <tr>
                        <th className="px-6 py-4">Ticket No</th>
                        <th className="px-6 py-4">Subject</th>
                        <th className="px-6 py-4">Type</th>
                        <th className="px-6 py-4">Priority</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4">AWB Ref</th>
                        <th className="px-6 py-4">Date</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                    {loading ? (
                        <tr><td colSpan={7} className="text-center p-6"><Loader className="animate-spin mx-auto"/></td></tr>
                    ) : tickets.length === 0 ? (
                        <tr><td colSpan={7} className="text-center p-6 text-gray-400">No tickets found.</td></tr>
                    ) : (
                        tickets.map((t, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono font-medium text-blue-600">{t.ticket_no}</td>
                                <td className="px-6 py-4 font-medium text-gray-900">{t.subject}</td>
                                <td className="px-6 py-4">{t.type}</td>
                                <td className="px-6 py-4">
                                    <span className={`flex items-center gap-1 ${t.priority === 'High' ? 'text-red-600 font-bold' : 'text-gray-600'}`}>
                                        {t.priority === 'High' && <AlertCircle size={14} />} {t.priority}
                                    </span>
                                </td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded text-xs ${t.status === 'Open' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
                                        {t.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 font-mono text-xs">{t.related_awb || '-'}</td>
                                <td className="px-6 py-4 text-xs text-gray-500">{new Date(t.created_at).toLocaleDateString()}</td>
                            </tr>
                        ))
                    )}
                </tbody>
             </table>
        </div>
    );
}

export const AllTicketList: React.FC = () => {
    const [showCreate, setShowCreate] = useState(false);
    const [refresh, setRefresh] = useState(0);

    return (
        <div>
            <Header 
                title="Support Tickets" 
                description="Manage all internal and external support requests."
                action={
                    <button onClick={() => setShowCreate(true)} className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Plus size={16} /> New Ticket
                    </button>
                }
            />
            <TicketTable refreshTrigger={refresh} />
            {showCreate && <CreateTicketForm onClose={() => setShowCreate(false)} onSuccess={() => setRefresh(prev => prev + 1)} />}
        </div>
    );
};

export const ManifestTicketList: React.FC = () => <AllTicketList />;
