import React from 'react';
import { Box, Save, Search, Filter, Edit, Trash2 } from 'lucide-react';

// Reusable Header
const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Add Box
export const AddBox: React.FC = () => {
    return (
        <div className="max-w-3xl mx-auto pb-10">
            <Header title="Add New Box" description="Register standard packaging box sizes." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Box Name / Code</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. Small-A1" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Material Type</label>
                        <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                            <option>Corrugated Cardboard</option>
                            <option>Plastic Pouch</option>
                            <option>Wooden Crate</option>
                        </select>
                    </div>
                    
                    <div className="md:col-span-2">
                         <label className="block text-sm font-medium text-gray-700 mb-1.5">Dimensions (cm)</label>
                         <div className="grid grid-cols-3 gap-4">
                             <input type="number" className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" placeholder="Length" />
                             <input type="number" className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" placeholder="Width" />
                             <input type="number" className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" placeholder="Height" />
                         </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Max Weight Capacity (kg)</label>
                        <input type="number" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="0.0" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Cost Price (SAR)</label>
                        <input type="number" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="0.00" />
                    </div>
                </div>

                <div className="mt-8 flex justify-end gap-3">
                    <button className="px-5 py-2.5 text-gray-700 hover:bg-gray-100 rounded-lg font-medium">Cancel</button>
                    <button className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                        <Save size={18} /> Save Box
                    </button>
                </div>
            </div>
        </div>
    );
};

// 2. Box List
export const BoxList: React.FC = () => {
    // Mock Data
    const boxes = [
        { code: 'BOX-S', name: 'Standard Small', dims: '20x15x10 cm', weight: '2 kg', stock: 1500, cost: 'SAR 1.50' },
        { code: 'BOX-M', name: 'Medium Standard', dims: '30x25x15 cm', weight: '5 kg', stock: 800, cost: 'SAR 2.75' },
        { code: 'BOX-L', name: 'Large Heavy', dims: '50x40x30 cm', weight: '15 kg', stock: 200, cost: 'SAR 5.00' },
        { code: 'POUCH-A4', name: 'Document Pouch', dims: 'A4', weight: '0.5 kg', stock: 5000, cost: 'SAR 0.50' },
    ];

    return (
        <div>
            <Header 
                title="Box Inventory" 
                description="Manage packaging materials and stock levels."
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Box size={16} /> Add Box
                    </button>
                }
            />
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search Box Code..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                    <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 flex items-center gap-2">
                        <Filter size={16} /> Filter
                    </button>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Box Code</th>
                            <th className="px-6 py-4">Description</th>
                            <th className="px-6 py-4">Dimensions</th>
                            <th className="px-6 py-4">Max Load</th>
                            <th className="px-6 py-4">Inventory</th>
                            <th className="px-6 py-4">Unit Cost</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {boxes.map((box, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono font-medium text-blue-600">{box.code}</td>
                                <td className="px-6 py-4">{box.name}</td>
                                <td className="px-6 py-4">{box.dims}</td>
                                <td className="px-6 py-4">{box.weight}</td>
                                <td className="px-6 py-4">
                                    <span className={`font-bold ${box.stock < 500 ? 'text-orange-600' : 'text-green-600'}`}>
                                        {box.stock}
                                    </span>
                                </td>
                                <td className="px-6 py-4">{box.cost}</td>
                                <td className="px-6 py-4 text-right flex justify-end gap-2">
                                    <button className="p-1 hover:text-blue-600 text-gray-400"><Edit size={16} /></button>
                                    <button className="p-1 hover:text-red-600 text-gray-400"><Trash2 size={16} /></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
             </div>
        </div>
    );
};