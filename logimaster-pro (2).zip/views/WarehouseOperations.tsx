
import React, { useState, useEffect } from 'react';
import { 
    Warehouse, Plus, Search, Grid, MapPin, Printer, ScanLine, 
    Filter, FileText, CheckCircle, X, Download, Box, ArrowRight,
    ShieldCheck, Truck, Clock
} from 'lucide-react';
import { api } from '../utils/api';

// Reusable Header
const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// ... (Previous imports and components GenerateTods, ShowTodd, AddWarehouse, ViewWarehouse, ScanInBoundShipment, ScanShelveShipment, ScanOnHold, InventoryReportView remain unchanged) ...

// 1. Generate Tods
export const GenerateTods: React.FC = () => {
    const [prefix, setPrefix] = useState('TODD');
    const [quantity, setQuantity] = useState(10);
    const [start, setStart] = useState(1000);
    const [generated, setGenerated] = useState<string[]>([]);

    const handleGenerate = async () => {
        try {
            const res = await api.post('/warehouses/generate-tods', { prefix, quantity, start });
            setGenerated(res.codes);
        } catch (e: any) {
            alert(e.message);
        }
    };

    return (
        <div className="max-w-2xl mx-auto pb-10">
            <Header title="Generate Tods" description="Create new Tote (Todd) IDs for temporary storage containers." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="space-y-4">
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Prefix</label>
                        <input type="text" value={prefix} onChange={e => setPrefix(e.target.value)} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Quantity to Generate</label>
                        <input type="number" value={quantity} onChange={e => setQuantity(parseInt(e.target.value))} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Starting Number</label>
                        <input type="number" value={start} onChange={e => setStart(parseInt(e.target.value))} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                    </div>
                    
                    <button onClick={handleGenerate} className="w-full mt-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center justify-center gap-2">
                        <Grid size={18} /> Generate Codes
                    </button>
                </div>

                {generated.length > 0 && (
                    <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
                        <h4 className="font-bold text-gray-800 mb-2">Generated {generated.length} Codes:</h4>
                        <div className="flex flex-wrap gap-2">
                            {generated.map(code => (
                                <span key={code} className="bg-white border border-gray-300 px-2 py-1 rounded text-xs font-mono">{code}</span>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

// 2. Show Todd
export const ShowTodd: React.FC = () => {
    const tods = [
        { id: 'TODD-1001', status: 'In Use', location: 'Packing Station 3', items: 5 },
        { id: 'TODD-1002', status: 'Empty', location: 'Storage Rack A', items: 0 },
    ];

    return (
        <div>
            <Header 
                title="Todd (Tote) Inventory" 
                description="Manage active and empty container units."
                action={
                    <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg flex items-center gap-2 hover:bg-gray-50">
                        <Printer size={16} /> Print Labels
                    </button>
                }
            />
            
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search Todd ID..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Todd ID</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4">Current Location</th>
                            <th className="px-6 py-4">Items Count</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {tods.map((tod, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono font-medium text-blue-600">{tod.id}</td>
                                <td className="px-6 py-4">
                                     <span className={`px-2 py-1 rounded-full text-xs font-medium 
                                        ${tod.status === 'In Use' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'}`}>
                                        {tod.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4">{tod.location}</td>
                                <td className="px-6 py-4">{tod.items}</td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-blue-600 hover:underline text-xs">View Contents</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
             </div>
        </div>
    );
};

// 3. Add Warehouse
export const AddWarehouse: React.FC = () => {
    const [formData, setFormData] = useState({ name: '', code: '', city_id: '1', capacity_sqm: '' });

    const handleSubmit = async () => {
        try {
            await api.post('/warehouses', formData);
            alert('Warehouse Added Successfully');
            setFormData({ name: '', code: '', city_id: '1', capacity_sqm: '' });
        } catch (e: any) {
            alert(e.message);
        }
    };

     return (
        <div className="max-w-3xl mx-auto pb-10">
            <Header title="Add New Warehouse" description="Register a new physical facility." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Warehouse Name</label>
                        <input 
                            type="text" 
                            value={formData.name} 
                            onChange={e => setFormData({...formData, name: e.target.value})}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" 
                            placeholder="e.g. Riyadh Central Hub" 
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Warehouse Code</label>
                        <input 
                            type="text" 
                            value={formData.code}
                            onChange={e => setFormData({...formData, code: e.target.value})}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" 
                            placeholder="e.g. RUH-01" 
                        />
                    </div>
                    
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">City</label>
                        <select 
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg"
                            value={formData.city_id}
                            onChange={e => setFormData({...formData, city_id: e.target.value})}
                        >
                            <option value="1">Riyadh (ID: 1)</option>
                            <option value="2">Jeddah (ID: 2)</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Capacity (Sq. Meters)</label>
                        <input 
                            type="number" 
                            value={formData.capacity_sqm}
                            onChange={e => setFormData({...formData, capacity_sqm: e.target.value})}
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" 
                            placeholder="e.g. 5000" 
                        />
                    </div>
                </div>

                <div className="mt-8 flex justify-end gap-3">
                    <button className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2" onClick={handleSubmit}>
                        <Plus size={18} /> Add Facility
                    </button>
                </div>
            </div>
        </div>
    );
};

// 4. View Warehouse
export const ViewWarehouse: React.FC = () => {
    const [warehouses, setWarehouses] = useState<any[]>([]);

    useEffect(() => {
        const load = async () => {
            try {
                const data = await api.get('/warehouses');
                setWarehouses(data);
            } catch (e) { console.error(e); }
        }
        load();
    }, []);

    return (
        <div>
            <Header 
                title="Warehouse Facilities" 
                description="List of all managed warehouse locations."
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Warehouse size={16} /> Add Warehouse
                    </button>
                }
            />
            
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Code</th>
                            <th className="px-6 py-4">Facility Name</th>
                            <th className="px-6 py-4">City</th>
                            <th className="px-6 py-4">Size</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {warehouses.map((wh, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono font-medium text-blue-600">{wh.code}</td>
                                <td className="px-6 py-4 font-medium text-gray-900">{wh.name}</td>
                                <td className="px-6 py-4 flex items-center gap-1"><MapPin size={14} /> {wh.city}</td>
                                <td className="px-6 py-4">{wh.capacity_sqm} sqm</td>
                                <td className="px-6 py-4">
                                     <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">Active</span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-blue-600 hover:underline">Manage</button>
                                </td>
                            </tr>
                        ))}
                        {warehouses.length === 0 && <tr><td colSpan={6} className="text-center p-6 text-gray-400">No warehouses found</td></tr>}
                    </tbody>
                </table>
             </div>
        </div>
    );
};

// 5. Scan Inbound Shipment
export const ScanInBoundShipment: React.FC = () => {
    const [scanned, setScanned] = useState<string[]>([]);
    const [input, setInput] = useState('');

    const handleScan = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter' && input) {
            setScanned(prev => [...prev, input]);
            setInput('');
        }
    };

    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Inbound Scanning" description="Scan items arriving at the warehouse." />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Scan AWB / SKU</label>
                    <div className="relative">
                        <ScanLine className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                        <input 
                            type="text" 
                            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none font-mono text-lg" 
                            placeholder="Ready to scan..."
                            autoFocus
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyDown={handleScan}
                        />
                    </div>
                    <div className="mt-4 p-4 bg-blue-50 rounded-lg text-blue-800 text-sm">
                        <p className="font-semibold mb-1">Last Scanned:</p>
                        <p className="font-mono text-xl">{scanned[scanned.length - 1] || '-'}</p>
                    </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col overflow-hidden h-80">
                    <div className="p-3 bg-gray-50 border-b border-gray-200 font-semibold text-gray-700 flex justify-between">
                        <span>Scanned Items ({scanned.length})</span>
                        <button className="text-red-600 text-xs hover:underline" onClick={() => setScanned([])}>Clear All</button>
                    </div>
                    <div className="flex-1 overflow-y-auto p-2 space-y-1">
                        {scanned.map((code, i) => (
                            <div key={i} className="p-2 border-b border-gray-100 flex justify-between items-center last:border-0">
                                <span className="font-mono text-gray-600">{code}</span>
                                <CheckCircle size={14} className="text-green-500" />
                            </div>
                        ))}
                        {scanned.length === 0 && <div className="text-center text-gray-400 mt-10">Waiting for scans...</div>}
                    </div>
                    <div className="p-3 border-t border-gray-200 bg-gray-50">
                        <button className="w-full py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium">
                            Confirm Receipt
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

// 6. Scan Shelve Shipment (Putaway)
export const ScanShelveShipment: React.FC = () => {
    const [step, setStep] = useState(1);
    const [item, setItem] = useState('');
    const [shelf, setShelf] = useState('');

    const handleConfirm = () => {
        if(item && shelf) {
            alert(`Assigned ${item} to ${shelf}`);
            setItem('');
            setShelf('');
            setStep(1);
        }
    };

    return (
        <div className="max-w-2xl mx-auto pb-10">
            <Header title="Shelving (Putaway)" description="Assign items to warehouse shelves." />
            
            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200 text-center">
                <div className="flex justify-center items-center gap-4 mb-8">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold ${step >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-400'}`}>1</div>
                    <div className={`w-16 h-1 bg-gray-200 ${step >= 2 ? 'bg-blue-600' : ''}`}></div>
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold ${step >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-400'}`}>2</div>
                </div>

                {step === 1 && (
                    <div className="space-y-4 animate-in fade-in">
                        <Box size={48} className="mx-auto text-blue-500 mb-2" />
                        <h3 className="text-xl font-bold text-gray-900">Scan Item</h3>
                        <input 
                            type="text" 
                            className="w-full px-4 py-3 border-2 border-blue-500 rounded-lg text-center font-mono text-xl outline-none" 
                            placeholder="Scan Barcode..."
                            autoFocus
                            value={item}
                            onChange={(e) => setItem(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && item && setStep(2)}
                        />
                        <p className="text-sm text-gray-500">Scan the product or shipment label.</p>
                    </div>
                )}

                {step === 2 && (
                    <div className="space-y-4 animate-in fade-in">
                        <Grid size={48} className="mx-auto text-orange-500 mb-2" />
                        <h3 className="text-xl font-bold text-gray-900">Scan Shelf Location</h3>
                        <div className="bg-gray-100 p-2 rounded mb-2 inline-block font-mono text-sm">Item: {item}</div>
                        <input 
                            type="text" 
                            className="w-full px-4 py-3 border-2 border-orange-500 rounded-lg text-center font-mono text-xl outline-none" 
                            placeholder="Scan Shelf ID..."
                            autoFocus
                            value={shelf}
                            onChange={(e) => setShelf(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && shelf && handleConfirm()}
                        />
                        <button onClick={() => setStep(1)} className="text-sm text-gray-400 hover:text-gray-600 underline">Cancel</button>
                    </div>
                )}
            </div>
        </div>
    );
};

// 7. Scan On Hold
export const ScanOnHold: React.FC = () => {
    return (
        <div className="max-w-2xl mx-auto pb-10">
            <Header title="Move to On Hold" description="Scan items to move them to the holding area." />
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Reason Code</label>
                    <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                        <option>Address Issue</option>
                        <option>Customer Request</option>
                        <option>Damaged Packaging</option>
                        <option>Payment Pending</option>
                    </select>
                </div>
                <div className="relative">
                    <ScanLine className="absolute left-3 top-1/2 transform -translate-y-1/2 text-red-400" size={20} />
                    <input 
                        type="text" 
                        className="w-full pl-10 pr-4 py-3 border border-red-200 rounded-lg focus:ring-2 focus:ring-red-500 outline-none font-mono" 
                        placeholder="Scan Shipment..."
                    />
                </div>
                <div className="mt-4 p-4 bg-yellow-50 text-yellow-800 text-sm rounded-lg flex items-start gap-2">
                    <div className="mt-0.5"><Filter size={16}/></div>
                    <p>Items scanned here will be removed from active dispatch lists and marked as 'On Hold' in the system.</p>
                </div>
            </div>
        </div>
    );
};

// 8. Inventory Report
export const InventoryReportView: React.FC = () => {
    // Mock Data
    const report = [
        { sku: 'ITM-001', name: 'Wireless Mouse', shelf: 'A-01', systemQty: 50, counted: 50, status: 'Match' },
        { sku: 'ITM-002', name: 'Gaming Keyboard', shelf: 'A-02', systemQty: 20, counted: 18, status: 'Variance' },
        { sku: 'ITM-003', name: 'USB Cable 1m', shelf: 'B-05', systemQty: 100, counted: 100, status: 'Match' },
    ];

    return (
        <div>
            <Header 
                title="Inventory Count Report" 
                description="Reconcile system stock with physical counts."
                action={
                    <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 flex items-center gap-2">
                        <Download size={16} /> Export CSV
                    </button>
                }
            />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">SKU</th>
                            <th className="px-6 py-4">Product Name</th>
                            <th className="px-6 py-4">Shelf</th>
                            <th className="px-6 py-4">System Qty</th>
                            <th className="px-6 py-4">Physical Count</th>
                            <th className="px-6 py-4">Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {report.map((row, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono">{row.sku}</td>
                                <td className="px-6 py-4">{row.name}</td>
                                <td className="px-6 py-4">{row.shelf}</td>
                                <td className="px-6 py-4">{row.systemQty}</td>
                                <td className="px-6 py-4 font-bold">{row.counted}</td>
                                <td className="px-6 py-4">
                                    {row.status === 'Match' ? (
                                        <span className="text-green-600 font-medium flex items-center gap-1"><CheckCircle size={14}/> Match</span>
                                    ) : (
                                        <span className="text-red-600 font-medium flex items-center gap-1"><X size={14}/> Variance</span>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 9. Scan Scheduled Shipments
export const ScanScheduleShipment: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Scan & Sort (Schedule)" description="Sort shipments into their respective delivery routes." />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Route Destination</label>
                        <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                            <option>Riyadh North</option>
                            <option>Jeddah East</option>
                            <option>Dammam Express</option>
                        </select>
                    </div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Scan AWB</label>
                    <input 
                        type="text" 
                        className="w-full px-4 py-3 border border-blue-500 rounded-lg outline-none font-mono text-lg focus:ring-2 focus:ring-blue-200" 
                        placeholder="Scan..."
                        autoFocus
                    />
                    <p className="text-xs text-gray-500 mt-2">Scan shipment to assign to the selected route.</p>
                </div>

                <div className="bg-blue-50 p-6 rounded-xl border border-blue-100 flex flex-col items-center justify-center text-center">
                    <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mb-4 shadow-sm text-blue-600">
                        <Truck size={32} />
                    </div>
                    <h3 className="text-xl font-bold text-blue-900">Route: Riyadh North</h3>
                    <p className="text-blue-700 mt-1">24 Items Scanned</p>
                </div>
            </div>
        </div>
    );
};

// 10. Security Checkpoint
export const SecurityCheckView: React.FC = () => {
    return (
        <div className="max-w-3xl mx-auto pb-10">
            <Header title="Security Checkpoint" description="Verify driver manifest before warehouse exit." />
            
            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200 text-center">
                <ShieldCheck size={64} className="mx-auto text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-6">Scan Driver Badge or Manifest ID</h3>
                
                <input 
                    type="text" 
                    className="w-full max-w-md mx-auto px-4 py-3 border border-gray-300 rounded-lg text-center font-mono text-lg outline-none focus:border-green-500 focus:ring-2 focus:ring-green-200" 
                    placeholder="Scan ID..."
                    autoFocus
                />

                <div className="mt-8 pt-8 border-t border-gray-100 text-left">
                    <h4 className="font-semibold text-gray-700 mb-2">Recent Logs</h4>
                    <div className="space-y-2 text-sm text-gray-600">
                        <div className="flex justify-between p-2 bg-gray-50 rounded">
                            <span>Ahmed Ali (Van-102)</span>
                            <span className="flex items-center gap-1 text-green-600"><CheckCircle size={12}/> Checked Out 10:45 AM</span>
                        </div>
                        <div className="flex justify-between p-2 bg-gray-50 rounded">
                            <span>Mohammed S. (Bike-005)</span>
                            <span className="flex items-center gap-1 text-green-600"><CheckCircle size={12}/> Checked Out 10:30 AM</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
