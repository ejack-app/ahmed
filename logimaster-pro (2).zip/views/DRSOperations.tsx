
import React, { useState, useEffect } from 'react';
import { 
  FileSpreadsheet, Plus, Search, Filter, Printer, Eye, Truck, Barcode, 
  MoreHorizontal, FolderOpen, Trash2, Calendar, Loader
} from 'lucide-react';
import { api } from '../utils/api';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Add Delivery Run Sheet
export const AddDRS: React.FC = () => {
    const [drivers, setDrivers] = useState<any[]>([]);
    const [routes, setRoutes] = useState<any[]>([]);
    const [selectedDriver, setSelectedDriver] = useState('');
    const [selectedRoute, setSelectedRoute] = useState('');

    useEffect(() => {
        api.get('/drivers').then(setDrivers).catch(console.error);
        api.get('/routes').then(setRoutes).catch(console.error);
    }, []);

    const handleCreateDRS = async () => {
        if(!selectedDriver) return alert("Select a driver");
        try {
            await api.post('/drs', { driver_id: selectedDriver, route_id: selectedRoute, shipments: [] });
            alert("DRS Created Successfully");
        } catch(e: any) {
            alert(e.message);
        }
    };

    return (
        <div className="max-w-5xl mx-auto pb-10">
            <Header title="Add Delivery Run Sheet" description="Assign shipments to couriers for delivery." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Select Country</label>
                        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                            <option value="">Please Select</option>
                            <option value="SA">Saudi Arabia</option>
                            <option value="AE">UAE</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Select City</label>
                        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                            <option value="">Please Select</option>
                            <option value="Riyadh">Riyadh</option>
                            <option value="Jeddah">Jeddah</option>
                        </select>
                    </div>
                </div>
                <div className="flex justify-end mb-6">
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium">Get Shipment</button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-gray-100 pt-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Route Code</label>
                        <select 
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                            onChange={(e) => setSelectedRoute(e.target.value)}
                        >
                            <option value="">Select Route...</option>
                            {routes.map(r => <option key={r.id} value={r.id}>{r.name} ({r.route_code})</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Select Courier</label>
                        <select 
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                            onChange={(e) => setSelectedDriver(e.target.value)}
                        >
                            <option value="">Select Driver...</option>
                            {drivers.map(d => <option key={d.id} value={d.id}>{d.full_name}</option>)}
                        </select>
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4 w-10"><input type="checkbox" /></th>
                            <th className="px-6 py-4">AWB No.</th>
                            <th className="px-6 py-4">Sender</th>
                            <th className="px-6 py-4">Receiver</th>
                            <th className="px-6 py-4">Receiver Address</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4">Date</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        <tr>
                            <td colSpan={7} className="px-6 py-8 text-center text-gray-400">
                                Select criteria and click 'Get Shipment' to load orders.
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div className="mt-6 flex justify-end">
                <button onClick={handleCreateDRS} className="px-6 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium">Add DRS</button>
            </div>
        </div>
    );
};

// 2. Show DRS (List)
export const ShowDRS: React.FC = () => {
    const [drsList, setDrsList] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Simulating GET /drs since endpoint isn't explicitly defined in apiRoutes but assumed
        // In real app, create GET /drs in backend
        setTimeout(() => {
            setDrsList([
                { id: 'DRS-1001', uniqueId: 'XDYIJ9', date: '05-09-2024', city: 'Riyadh', route: 'RUH-110', driver: 'Ahmed Ali', delivered: 0, total: 10 },
                { id: 'DRS-1002', uniqueId: 'ABX992', date: '06-09-2024', city: 'Jeddah', route: 'JED-001', driver: 'Omar F.', delivered: 8, total: 8 },
            ]);
            setLoading(false);
        }, 500);
    }, []);

    return (
        <div>
            <Header title="Delivery Run Sheets" description="Manage active and past delivery sheets." />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50 flex flex-col md:flex-row gap-4 justify-between">
                    <div className="relative flex-1 max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="DRS ID / Route / Driver..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                    <div className="flex gap-2">
                        <input type="date" className="px-3 py-2 border border-gray-300 rounded-lg text-sm" />
                        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm">Search</button>
                    </div>
                </div>
                
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">#</th>
                            <th className="px-6 py-4">Unique ID</th>
                            <th className="px-6 py-4">Date</th>
                            <th className="px-6 py-4">City</th>
                            <th className="px-6 py-4">Route Code</th>
                            <th className="px-6 py-4">Driver</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {loading ? (
                            <tr><td colSpan={8} className="p-6 text-center"><Loader className="animate-spin mx-auto"/></td></tr>
                        ) : drsList.map((drs, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                <td className="px-6 py-4 font-mono font-medium text-blue-600">
                                    <div className="flex flex-col">
                                        <Barcode size={20} className="mb-1 opacity-50" />
                                        {drs.uniqueId}
                                    </div>
                                </td>
                                <td className="px-6 py-4">{drs.date}</td>
                                <td className="px-6 py-4">{drs.city}</td>
                                <td className="px-6 py-4"><span className="bg-gray-100 px-2 py-1 rounded text-xs">{drs.route}</span></td>
                                <td className="px-6 py-4">{drs.driver}</td>
                                <td className="px-6 py-4">
                                    {drs.delivered === drs.total ? (
                                        <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-bold">
                                            Success ({drs.delivered}/{drs.total})
                                        </span>
                                    ) : (
                                        <span className="bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs font-bold">
                                            Running ({drs.delivered}/{drs.total})
                                        </span>
                                    )}
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-gray-400 hover:text-gray-600">
                                        <MoreHorizontal size={20} />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 3. Scan New DRS
export const ScanNewDRS: React.FC = () => {
    return (
        <div className="max-w-6xl mx-auto pb-10">
            <Header title="Scan New DRS" description="Create a Delivery Run Sheet by scanning shipment barcodes." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
                            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"><option>Saudi Arabia</option></select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"><option>Riyadh</option></select>
                        </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Route</label>
                            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"><option>RUH-110</option></select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Messenger</label>
                            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"><option>Ahmed Ali</option></select>
                        </div>
                    </div>
                </div>
                
                <div className="flex gap-4 items-end border-t border-gray-100 pt-4">
                    <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Scan Barcode</label>
                        <input type="text" className="w-full px-4 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500" placeholder="Scan AWB here..." autoFocus />
                    </div>
                    <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">Make DRS</button>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">AWB No.</th>
                            <th className="px-6 py-4">Receiver</th>
                            <th className="px-6 py-4">Pieces</th>
                            <th className="px-6 py-4">Weight</th>
                            <th className="px-6 py-4">Address</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        <tr>
                            <td colSpan={5} className="px-6 py-8 text-center text-gray-400">
                                Scanned items will appear here.
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 4. DRS Details (View specific shipments in a DRS)
export const DRSDetails: React.FC = () => {
    // Mock Data for a specific DRS
    const shipments = [
        { id: '1', awb: 'AWB-1001', type: 'Parcel', address: 'King Fahd Rd, Riyadh', driver: 'Ahmed Ali', status: 'Delivered' },
        { id: '2', awb: 'AWB-1002', type: 'Document', address: 'Olaya St, Riyadh', driver: 'Ahmed Ali', status: 'Pending' },
    ];

    return (
        <div>
            <Header 
                title="DRS Detail View" 
                description="Shipments listed in DRS #XDYIJ9"
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700 font-medium">
                        <Printer size={16} /> Print
                    </button>
                }
            />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">#</th>
                            <th className="px-6 py-4">AWB No.</th>
                            <th className="px-6 py-4">Product Type</th>
                            <th className="px-6 py-4">Address</th>
                            <th className="px-6 py-4">Driver Name</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {shipments.map((s, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                <td className="px-6 py-4 font-mono text-blue-600">{s.awb}</td>
                                <td className="px-6 py-4">{s.type}</td>
                                <td className="px-6 py-4">{s.address}</td>
                                <td className="px-6 py-4">{s.driver}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium 
                                        ${s.status === 'Delivered' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                                        {s.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4">
                                    <div className="flex gap-2">
                                        {s.status === 'Delivered' && (
                                            <button className="text-gray-500 hover:text-blue-600" title="Open Shipment">
                                                <FolderOpen size={18} />
                                            </button>
                                        )}
                                        <button className="text-gray-500 hover:text-red-600" title="Delete">
                                            <Trash2 size={18} />
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 5. Delivered Shipment Details
export const DeliveredDetails: React.FC = () => {
    return (
        <div>
            <Header 
                title="Delivered Shipments" 
                description="Items successfully delivered from this run sheet."
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700 font-medium">
                        <Printer size={16} /> Print List
                    </button>
                }
            />
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center text-gray-500">
                <Truck size={48} className="mx-auto mb-4 opacity-30" />
                <p>No delivered shipments found for this selection.</p>
            </div>
        </div>
    );
};

// 6. Not Delivered Shipment Details
export const NotDeliveredDetails: React.FC = () => {
    return (
        <div>
            <Header 
                title="Undelivered Shipments" 
                description="Items that failed delivery or are pending."
                action={
                    <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg flex items-center gap-2 hover:bg-gray-50 font-medium">
                        <Printer size={16} /> Print List
                    </button>
                }
            />
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center text-gray-500">
                <Truck size={48} className="mx-auto mb-4 opacity-30" />
                <p>No undelivered shipments found for this selection.</p>
            </div>
        </div>
    );
};
