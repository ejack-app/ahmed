
import React, { useEffect, useState } from 'react';
import { Package, Grid, Plus, Upload, Loader } from 'lucide-react';
import { InventoryItem } from '../types';
import { api } from '../utils/api';

export const InventoryManager: React.FC = () => {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState({ totalSku: 0, lowStock: 0, value: 0 });

  useEffect(() => {
    const fetchInventory = async () => {
      setLoading(true);
      try {
        const data = await api.get('/inventory');
        
        // Map Backend Data
        const mappedItems: InventoryItem[] = data.map((item: any) => ({
            sku: item.sku,
            name: item.name,
            stock: item.quantity,
            shelf: item.shelf || 'Unassigned',
            client: item.category || 'General' // Mapping category to client for demo if client_id not populated
        }));

        setItems(mappedItems);

        // Calculate Summary
        setSummary({
            totalSku: mappedItems.length,
            lowStock: mappedItems.filter(i => i.stock < 10).length,
            value: mappedItems.reduce((acc, curr) => acc + (curr.stock * 10), 0) // Mock value calculation
        });

      } catch (error) {
        console.error("Failed to fetch inventory", error);
      } finally {
        setLoading(false);
      }
    };

    fetchInventory();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Inventory Management</h2>
          <p className="text-sm text-gray-500">Track items, shelves, and stock levels.</p>
        </div>
        <div className="flex gap-2">
            <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 flex items-center gap-2">
                <Upload size={16} /> Import
            </button>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2">
                <Plus size={16} /> Add Item
            </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center gap-4">
                <div className="p-3 bg-blue-100 text-blue-600 rounded-lg"><Package /></div>
                <div>
                    <p className="text-sm text-gray-500">Total SKUs</p>
                    <h3 className="text-2xl font-bold text-gray-900">{loading ? '...' : summary.totalSku}</h3>
                </div>
            </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center gap-4">
                <div className="p-3 bg-orange-100 text-orange-600 rounded-lg"><Grid /></div>
                <div>
                    <p className="text-sm text-gray-500">Low Stock Items</p>
                    <h3 className="text-2xl font-bold text-gray-900">{loading ? '...' : summary.lowStock}</h3>
                </div>
            </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center gap-4">
                <div className="p-3 bg-green-100 text-green-600 rounded-lg"><Package /></div>
                <div>
                    <p className="text-sm text-gray-500">Est. Valuation</p>
                    <h3 className="text-2xl font-bold text-gray-900">{loading ? '...' : `SAR ${summary.value.toLocaleString()}`}</h3>
                </div>
            </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        {loading ? (
             <div className="p-10 text-center text-gray-500">
                <Loader className="animate-spin mx-auto mb-2" /> Loading Inventory...
            </div>
        ) : (
            <table className="w-full text-left text-sm text-gray-600">
                <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                    <tr>
                        <th className="px-6 py-4">SKU</th>
                        <th className="px-6 py-4">Product Name</th>
                        <th className="px-6 py-4">Category/Client</th>
                        <th className="px-6 py-4">Shelf Location</th>
                        <th className="px-6 py-4">Stock Level</th>
                        <th className="px-6 py-4">Action</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                    {items.length > 0 ? items.map((item, idx) => (
                        <tr key={idx} className="hover:bg-gray-50">
                            <td className="px-6 py-4 font-mono text-gray-500">{item.sku}</td>
                            <td className="px-6 py-4 font-medium text-gray-900">{item.name}</td>
                            <td className="px-6 py-4">{item.client}</td>
                            <td className="px-6 py-4">
                                <span className="px-2 py-1 bg-gray-100 rounded text-xs border border-gray-200 font-mono">
                                    {item.shelf}
                                </span>
                            </td>
                            <td className="px-6 py-4">
                                <span className={`font-bold ${item.stock < 10 ? 'text-red-600' : 'text-green-600'}`}>
                                    {item.stock}
                                </span> units
                            </td>
                            <td className="px-6 py-4">
                                <button className="text-blue-600 hover:text-blue-800 text-xs font-medium">Edit</button>
                            </td>
                        </tr>
                    )) : (
                        <tr>
                            <td colSpan={6} className="px-6 py-8 text-center text-gray-400">
                                Inventory is empty. Add items to get started.
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        )}
      </div>
    </div>
  );
};
