
import React from 'react';
import { Truck, Map, FileText, Activity, Plus, Search, Filter, MapPin, ExternalLink } from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

export const ViewCourierCompany: React.FC = () => {
    return (
        <div>
            <Header title="Courier Partners" description="External logistics providers." />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {['SMSA Express', 'Aramex', 'DHL', 'J&T Express'].map((c, i) => (
                    <div key={i} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                        <div className="flex items-center gap-4 mb-4">
                            <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center font-bold text-gray-500">
                                {c.substring(0,2)}
                            </div>
                            <div>
                                <h3 className="font-bold text-gray-900">{c}</h3>
                                <p className="text-xs text-green-600">Active Integration</p>
                            </div>
                        </div>
                        <div className="text-sm text-gray-500 space-y-1">
                            <p>Service Level: Standard & Express</p>
                            <p>API Status: Connected</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export const AddZone: React.FC = () => {
    return (
        <div className="max-w-3xl mx-auto pb-10">
            <Header title="Add Service Zone" description="Define a new operational zone." />
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Zone Name</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. Riyadh Central" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Cities Included</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. Riyadh, Diriyah" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Zip Code Range (Start - End)</label>
                        <div className="flex gap-4">
                            <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="10000" />
                            <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="19999" />
                        </div>
                    </div>
                </div>
                <div className="mt-6 flex justify-end">
                    <button className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2">
                        <Plus size={18} /> Add Zone
                    </button>
                </div>
            </div>
        </div>
    );
};

export const ViewZone: React.FC = () => {
    const zones = [
        { id: 'ZN-001', name: 'Riyadh Central', cities: 2, zips: '10000-19999', status: 'Active' },
        { id: 'ZN-002', name: 'Jeddah Coastal', cities: 1, zips: '20000-29999', status: 'Active' },
        { id: 'ZN-003', name: 'Dammam Metro', cities: 3, zips: '30000-39999', status: 'Inactive' },
    ];

    return (
        <div>
            <Header 
                title="Service Zones" 
                description="List of defined zones covering operational areas." 
                action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700 font-medium">
                        <Plus size={16} /> New Zone
                    </button>
                }
            />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Zone ID</th>
                            <th className="px-6 py-4">Zone Name</th>
                            <th className="px-6 py-4">Cities</th>
                            <th className="px-6 py-4">Zip Range</th>
                            <th className="px-6 py-4">Status</th>
                            <th className="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {zones.map((zone, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 text-gray-400">{zone.id}</td>
                                <td className="px-6 py-4 font-medium text-gray-900 flex items-center gap-2">
                                    <Map size={16} className="text-blue-500" />
                                    {zone.name}
                                </td>
                                <td className="px-6 py-4">{zone.cities}</td>
                                <td className="px-6 py-4 font-mono">{zone.zips}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium 
                                        ${zone.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                                        {zone.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-blue-600 hover:underline">Edit</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export const ShipmentLog: React.FC = () => {
    return (
        <div>
            <Header title="Shipment Logs" description="Audit trail of shipment events." />
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 border-b">
                        <tr>
                            <th className="px-6 py-4">Timestamp</th>
                            <th className="px-6 py-4">Order ID</th>
                            <th className="px-6 py-4">Event</th>
                            <th className="px-6 py-4">User/System</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        <tr>
                            <td className="px-6 py-4">2024-02-28 10:30:00</td>
                            <td className="px-6 py-4 text-blue-600 font-mono">ORD-1002</td>
                            <td className="px-6 py-4">Status changed to Dispatched</td>
                            <td className="px-6 py-4">System (Auto)</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export const TrackingLog: React.FC = () => {
    const logs = [
        { time: '2024-02-28 14:30', awb: 'SMSA-9921', courier: 'SMSA Express', update: 'Out for Delivery - Driver: Mohammed' },
        { time: '2024-02-28 12:15', awb: 'ARX-10044', courier: 'Aramex', update: 'Arrived at Sorting Facility' },
        { time: '2024-02-28 09:00', awb: 'JNT-5521', courier: 'J&T Express', update: 'Pickup Successful' },
    ];

    return (
        <div>
            <Header title="Tracking Logs" description="External courier tracking updates via API webhooks." />
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50">
                    <div className="relative max-w-md">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input type="text" placeholder="Search AWB..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                    </div>
                </div>
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 border-b">
                        <tr>
                            <th className="px-6 py-4">Time</th>
                            <th className="px-6 py-4">AWB Number</th>
                            <th className="px-6 py-4">Courier</th>
                            <th className="px-6 py-4">Latest Update</th>
                            <th className="px-6 py-4 text-right">Raw Data</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {logs.map((log, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 text-gray-500 text-xs">{log.time}</td>
                                <td className="px-6 py-4 font-mono font-medium text-blue-600">{log.awb}</td>
                                <td className="px-6 py-4">{log.courier}</td>
                                <td className="px-6 py-4">{log.update}</td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-gray-400 hover:text-blue-600 flex items-center justify-end w-full gap-1">
                                        <ExternalLink size={14} /> View
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
