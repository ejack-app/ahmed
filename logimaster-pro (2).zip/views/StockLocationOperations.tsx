import React from 'react';
import { 
  MapPin, Printer, Filter, Search, Plus, ArrowRight, Layers, LayoutGrid
} from 'lucide-react';

// Reusable Header
const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Generate Stock Location
export const GenerateStockLocation: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Generate Stock Locations" description="Batch create location codes for your warehouse layout." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                        <h3 className="font-semibold text-gray-800 border-b pb-2 mb-4">Structure Configuration</h3>
                        
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Zone Prefix</label>
                            <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="e.g. A, B, C" />
                            <p className="text-xs text-gray-400 mt-1">Single letter representing the warehouse zone.</p>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-4">
                             <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1.5">Aisles</label>
                                <input type="number" className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" placeholder="10" />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1.5">Racks</label>
                                <input type="number" className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" placeholder="5" />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1.5">Levels</label>
                                <input type="number" className="w-full px-3 py-2.5 border border-gray-300 rounded-lg" placeholder="4" />
                            </div>
                        </div>

                         <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Separator</label>
                            <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                                <option value="-">Hyphen (-)</option>
                                <option value="/">Slash (/)</option>
                                <option value="">None</option>
                            </select>
                        </div>
                    </div>

                    <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 flex flex-col justify-center">
                        <h3 className="font-semibold text-gray-800 mb-4 text-center">Preview</h3>
                        <div className="space-y-2 mb-6">
                            <div className="p-3 bg-white border border-gray-300 rounded-lg text-center font-mono text-gray-600">A-01-01-01</div>
                            <div className="p-3 bg-white border border-gray-300 rounded-lg text-center font-mono text-gray-600">...</div>
                            <div className="p-3 bg-white border border-gray-300 rounded-lg text-center font-mono text-gray-600">A-10-05-04</div>
                        </div>
                        <div className="text-center text-sm text-gray-500 mb-6">
                            This will generate <span className="font-bold text-gray-900">200</span> unique locations.
                        </div>
                        <button className="w-full py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center justify-center gap-2">
                            <Plus size={18} /> Generate Locations
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

// 2. Stock Location List Component (Reusable)
interface LocationListProps {
    filterType?: 'all' | 'assigned' | 'unassigned';
}

const StockLocationList: React.FC<LocationListProps> = ({ filterType = 'all' }) => {
    // Mock Data
    const locations = [
        { id: 'A-01-01-01', zone: 'A', status: 'Occupied', item: 'ELEC-001', qty: 50 },
        { id: 'A-01-01-02', zone: 'A', status: 'Empty', item: '-', qty: 0 },
        { id: 'B-02-04-01', zone: 'B', status: 'Occupied', item: 'HOME-992', qty: 12 },
        { id: 'C-05-01-03', zone: 'C', status: 'Empty', item: '-', qty: 0 },
        { id: 'A-03-02-01', zone: 'A', status: 'Occupied', item: 'TOY-112', qty: 100 },
    ];

    const filteredData = locations.filter(loc => {
        if (filterType === 'assigned') return loc.status === 'Occupied';
        if (filterType === 'unassigned') return loc.status === 'Empty';
        return true;
    });

    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between gap-4">
                <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                    <input type="text" placeholder="Search Location ID..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                </div>
                <div className="flex gap-2">
                    <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 flex items-center gap-2">
                        <Filter size={16} /> Filter
                    </button>
                     <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 flex items-center gap-2">
                        <Printer size={16} /> Print
                    </button>
                </div>
            </div>
            <table className="w-full text-left text-sm text-gray-600">
                <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                    <tr>
                        <th className="px-6 py-4">Location ID</th>
                        <th className="px-6 py-4">Zone</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4">SKU</th>
                        <th className="px-6 py-4">Quantity</th>
                        <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                    {filteredData.map((loc) => (
                        <tr key={loc.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 font-mono font-medium text-blue-600">{loc.id}</td>
                            <td className="px-6 py-4">{loc.zone}</td>
                            <td className="px-6 py-4">
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${loc.status === 'Occupied' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
                                    {loc.status}
                                </span>
                            </td>
                            <td className="px-6 py-4 font-mono">{loc.item}</td>
                            <td className="px-6 py-4">{loc.qty}</td>
                            <td className="px-6 py-4 text-right">
                                <button className="text-blue-600 hover:text-blue-800 text-xs font-medium">Edit</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

// 3. All Stock Location
export const AllStockLocation: React.FC = () => {
    return (
        <div>
            <Header title="All Stock Locations" description="View and manage all generated warehouse locations." />
            <StockLocationList filterType="all" />
        </div>
    );
};

// 4. Assigned Stock Location
export const AssignedStockLocation: React.FC = () => {
     return (
        <div>
            <Header title="Assigned Locations" description="Locations currently holding inventory stock." />
            <StockLocationList filterType="assigned" />
        </div>
    );
};

// 5. Unassigned Stock Location
export const UnassignedStockLocation: React.FC = () => {
     return (
        <div>
            <Header title="Unassigned Locations" description="Empty locations available for new stock." />
            <StockLocationList filterType="unassigned" />
        </div>
    );
};

// 6. Bulk Print Stock Location
export const BulkPrintStockLocation: React.FC = () => {
    return (
        <div>
            <Header 
                title="Bulk Print Labels" 
                description="Print location barcodes for warehouse labeling." 
                 action={
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700">
                        <Printer size={16} /> Print Selected
                    </button>
                }
            />
            
            <div className="mb-6 flex gap-4 p-4 bg-white border border-gray-200 rounded-xl shadow-sm">
                <div className="flex-1">
                     <label className="block text-sm font-medium text-gray-700 mb-1.5">Filter by Zone</label>
                     <select className="w-full px-3 py-2 border border-gray-300 rounded-lg">
                         <option>All Zones</option>
                         <option>Zone A</option>
                         <option>Zone B</option>
                     </select>
                </div>
                 <div className="flex-1">
                     <label className="block text-sm font-medium text-gray-700 mb-1.5">Filter by Aisle</label>
                     <select className="w-full px-3 py-2 border border-gray-300 rounded-lg">
                         <option>All Aisles</option>
                         <option>Aisle 01</option>
                         <option>Aisle 02</option>
                     </select>
                </div>
                 <div className="flex-1 flex items-end">
                     <button className="w-full py-2 bg-gray-100 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-200">
                         Apply Filters
                     </button>
                </div>
            </div>

            <StockLocationList filterType="all" />
        </div>
    );
};