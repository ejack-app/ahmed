
import React, { useState, useEffect } from 'react';
import { ClipboardList, Plus, Search, Filter, Printer, Calendar, User, Truck, CheckSquare, MoreHorizontal, Loader } from 'lucide-react';
import { api } from '../utils/api';

// Reusable Header
const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// --- Shared Components ---

const ManifestTable: React.FC<{ isBeta?: boolean }> = ({ isBeta = false }) => {
    const [manifests, setManifests] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchManifests = async () => {
            try {
                const data = await api.get('/manifests');
                setManifests(data);
            } catch (e) {
                console.error(e);
            } finally {
                setLoading(false);
            }
        };
        fetchManifests();
    }, []);

    return (
        <div className={`bg-white rounded-xl shadow-sm border ${isBeta ? 'border-blue-200' : 'border-gray-200'} overflow-hidden`}>
            <div className={`p-4 border-b ${isBeta ? 'bg-blue-50 border-blue-200' : 'bg-gray-50 border-gray-200'} flex justify-between gap-4`}>
                <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                    <input type="text" placeholder="Search Manifest ID or Driver..." className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg outline-none" />
                </div>
                 <div className="flex gap-2">
                     <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 flex items-center gap-2">
                        <Filter size={16} /> Filter
                    </button>
                    <button className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 flex items-center gap-2">
                        <Printer size={16} /> Bulk Print
                    </button>
                </div>
            </div>
            <table className="w-full text-left text-sm text-gray-600">
                <thead className={`uppercase font-semibold text-gray-500 text-xs ${isBeta ? 'bg-blue-50' : 'bg-gray-50'}`}>
                    <tr>
                        <th className="px-6 py-4">Manifest ID</th>
                        <th className="px-6 py-4">Courier</th>
                        <th className="px-6 py-4">Driver</th>
                        <th className="px-6 py-4">Creation Date</th>
                        <th className="px-6 py-4">Orders</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                    {loading ? (
                        <tr><td colSpan={7} className="text-center p-6"><Loader className="animate-spin mx-auto"/></td></tr>
                    ) : manifests.length === 0 ? (
                        <tr><td colSpan={7} className="text-center p-6 text-gray-400">No manifests found.</td></tr>
                    ) : (
                        manifests.map((m, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono font-medium text-blue-600">{m.manifest_code}</td>
                                <td className="px-6 py-4">{m.courier}</td>
                                <td className="px-6 py-4 flex items-center gap-2">
                                    <User size={14} className="text-gray-400"/> {m.driver_name}
                                </td>
                                <td className="px-6 py-4">{new Date(m.created_at).toLocaleDateString()}</td>
                                <td className="px-6 py-4 font-semibold">{m.orders_count}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium 
                                        ${m.status === 'Completed' ? 'bg-green-100 text-green-700' : 
                                        m.status === 'Dispatched' ? 'bg-blue-100 text-blue-700' : 
                                        'bg-yellow-100 text-yellow-700'}`}>
                                        {m.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-gray-400 hover:text-gray-600">Details</button>
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
        </div>
    );
}

// --- STANDARD VIEWS ---

export const NewManifest: React.FC = () => {
    const [couriers, setCouriers] = useState<any[]>([]);
    const [shipments, setShipments] = useState<any[]>([]);
    const [selectedShipments, setSelectedShipments] = useState<string[]>([]);
    const [selectedCourier, setSelectedCourier] = useState('');
    const [driverName, setDriverName] = useState('');
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        // Fetch Suppliers/Couriers
        api.get('/suppliers').then(setCouriers).catch(console.error);
        // Fetch Eligible Shipments (Created status)
        api.get('/shipments?status=Created').then(setShipments).catch(console.error);
    }, []);

    const toggleShipment = (id: string) => {
        setSelectedShipments(prev => 
            prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
        );
    };

    const handleCreate = async () => {
        if(!selectedCourier || selectedShipments.length === 0) return alert("Select courier and orders");
        
        setLoading(true);
        try {
            await api.post('/manifests', {
                courier_id: selectedCourier,
                driver_name: driverName,
                shipments: selectedShipments
            });
            alert("Manifest Created Successfully");
            // Refresh list
            const updated = await api.get('/shipments?status=Created');
            setShipments(updated);
            setSelectedShipments([]);
        } catch (e: any) {
            alert(e.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Create New Manifest" description="Group orders and assign them to a courier for pickup." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Courier Company</label>
                        <select 
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg"
                            value={selectedCourier}
                            onChange={(e) => setSelectedCourier(e.target.value)}
                        >
                            <option value="">Select Courier...</option>
                            {couriers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Driver Name (Optional)</label>
                        <input 
                            type="text" 
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg"
                            value={driverName}
                            onChange={(e) => setDriverName(e.target.value)}
                            placeholder="e.g. Ahmed Ali"
                        />
                    </div>
                </div>

                <div className="border-t border-gray-100 pt-6">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="font-semibold text-gray-900">Select Orders ({selectedShipments.length})</h3>
                    </div>
                    
                    <div className="border border-gray-200 rounded-lg overflow-hidden max-h-96 overflow-y-auto">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-gray-50 text-gray-600 font-semibold">
                                <tr>
                                    <th className="p-3 w-10"><input type="checkbox" /></th>
                                    <th className="p-3">AWB</th>
                                    <th className="p-3">City</th>
                                    <th className="p-3">Date</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                                {shipments.map(s => (
                                    <tr key={s.id} className="hover:bg-gray-50">
                                        <td className="p-3">
                                            <input 
                                                type="checkbox" 
                                                checked={selectedShipments.includes(s.id)}
                                                onChange={() => toggleShipment(s.id)}
                                            />
                                        </td>
                                        <td className="p-3 font-mono text-blue-600">{s.awb_number}</td>
                                        <td className="p-3">{s.receiver_city}</td>
                                        <td className="p-3 text-gray-500">{new Date(s.created_at).toLocaleDateString()}</td>
                                    </tr>
                                ))}
                                {shipments.length === 0 && <tr><td colSpan={4} className="p-6 text-center text-gray-400">No pending shipments found</td></tr>}
                            </tbody>
                        </table>
                    </div>

                    <div className="mt-6 flex justify-end gap-3">
                        <button className="px-5 py-2.5 text-gray-700 hover:bg-gray-100 rounded-lg font-medium">Cancel</button>
                        <button 
                            onClick={handleCreate}
                            disabled={loading}
                            className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2 disabled:opacity-50"
                        >
                            {loading ? 'Creating...' : <><Plus size={18} /> Create Manifest</>}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export const PickupList: React.FC = () => {
    return (
        <div>
            <Header title="Pickup List" description="Orders ready and waiting for courier pickup." />
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-10 text-center text-gray-500">
                <Truck size={48} className="mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-medium text-gray-900">No Pending Pickups</h3>
                <p>All scheduled pickups have been processed or no orders are ready.</p>
            </div>
        </div>
    );
};

export const ManifestList: React.FC = () => {
    return (
        <div>
            <Header title="Manifest History" description="View past and active manifests." />
            <ManifestTable />
        </div>
    );
};

export const AssignedList: React.FC = () => {
     return (
        <div>
            <Header title="Assigned Orders" description="Orders currently assigned to a driver but not yet delivered." />
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">Order ID</th>
                            <th className="px-6 py-4">Driver</th>
                            <th className="px-6 py-4">Assigned Time</th>
                            <th className="px-6 py-4">Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                         {/* This would also be fetched from API in full version */}
                         <tr className="hover:bg-gray-50">
                            <td className="px-6 py-4 font-mono text-blue-600">ORD-9921</td>
                            <td className="px-6 py-4">Ahmed Ali</td>
                            <td className="px-6 py-4">2 hours ago</td>
                            <td className="px-6 py-4"><span className="text-yellow-600 bg-yellow-100 px-2 py-1 rounded text-xs">Out for Delivery</span></td>
                         </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// --- BETA VIEWS (UI Placeholders with reused logic) ---
export const NewManifestBeta: React.FC = () => <NewManifest />;
export const PickupListBeta: React.FC = () => <PickupList />; 
export const ManifestListBeta: React.FC = () => {
    return (
        <div>
             <Header 
                title="Manifest History (Beta)" 
                description="Enhanced view with analytics and batch operations." 
                action={<span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">Beta View</span>}
            />
            <ManifestTable isBeta={true} />
        </div>
    );
}
export const AssignedListBeta: React.FC = () => <AssignedList />;
