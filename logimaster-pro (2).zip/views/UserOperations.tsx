
import React, { useState, useEffect } from 'react';
import { Users, Plus, Search, Shield, MoreHorizontal, User, Mail, Phone, MapPin, Globe } from 'lucide-react';
import { api } from '../utils/api';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Add User
export const AddUser: React.FC = () => {
    const [formData, setFormData] = useState({
        full_name: '',
        email: '',
        phone: '',
        password: '',
        confirm_password: '',
        role_id: '1',
        branch_id: '1'
    });

    const handleSubmit = async () => {
        if(formData.password !== formData.confirm_password) return alert("Passwords do not match");
        try {
            await api.post('/users', formData);
            alert('User Created Successfully');
            // Reset form
            setFormData({ full_name: '', email: '', phone: '', password: '', confirm_password: '', role_id: '1', branch_id: '1' });
        } catch (e: any) {
            alert(e.message);
        }
    };

    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Add New User" description="Create a new staff member profile and assign system privileges." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="md:col-span-2">
                        <h3 className="font-semibold text-gray-800 mb-2 border-b pb-2">Basic Information</h3>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Full Name <span className="text-red-500">*</span></label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value={formData.full_name} onChange={e => setFormData({...formData, full_name: e.target.value})} />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Email Address <span className="text-red-500">*</span></label>
                        <input type="email" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone Number</label>
                        <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                    </div>
                    
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Role <span className="text-red-500">*</span></label>
                        <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value={formData.role_id} onChange={e => setFormData({...formData, role_id: e.target.value})}>
                            <option value="1">Admin</option>
                            <option value="2">Manager</option>
                            <option value="3">Driver</option>
                        </select>
                    </div>

                    <div className="md:col-span-2 mt-2">
                        <h3 className="font-semibold text-gray-800 mb-2 border-b pb-2">Security</h3>
                    </div>

                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Password <span className="text-red-500">*</span></label>
                        <input type="password" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">Confirm Password <span className="text-red-500">*</span></label>
                        <input type="password" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" value={formData.confirm_password} onChange={e => setFormData({...formData, confirm_password: e.target.value})} />
                    </div>
                </div>

                <div className="mt-8 flex justify-end gap-3 pt-4 border-t border-gray-100">
                    <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2" onClick={handleSubmit}>
                        <Plus size={18} /> Create Staff Account
                    </button>
                </div>
            </div>
        </div>
    );
};

// 2. View All Users
export const ViewAllUsers: React.FC = () => {
    const [users, setUsers] = useState<any[]>([]);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const data = await api.get('/users');
                setUsers(data);
            } catch (e) { console.error(e); }
        };
        fetchUsers();
    }, []);

    return (
        <div>
            <Header title="Staff Directory" description="Manage system access, roles, and user profiles." />
            
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4 w-10">#</th>
                            <th className="px-6 py-4">Name</th>
                            <th className="px-6 py-4">Email</th>
                            <th className="px-6 py-4">Phone</th>
                            <th className="px-6 py-4">Role</th>
                            <th className="px-6 py-4">Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {users.map((u, i) => (
                            <tr key={i} className="hover:bg-gray-50 transition-colors">
                                <td className="px-6 py-4 text-gray-400">{i + 1}</td>
                                <td className="px-6 py-4 font-medium text-gray-900">{u.full_name}</td>
                                <td className="px-6 py-4">{u.email}</td>
                                <td className="px-6 py-4">{u.phone}</td>
                                <td className="px-6 py-4">
                                    <span className="flex items-center gap-1.5 px-2.5 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-medium w-fit">
                                        <Shield size={12} /> {u.role}
                                    </span>
                                </td>
                                <td className="px-6 py-4">
                                     <span className={`px-2.5 py-1 rounded-full text-xs font-medium 
                                        ${u.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                        {u.status}
                                    </span>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
             </div>
        </div>
    );
};
