import React, { useState } from 'react';
import { 
  CalendarClock, Save, Search, Filter, RefreshCw, Upload, 
  MapPin, CheckCircle, AlertTriangle, FileText, Trash2
} from 'lucide-react';

const Header: React.FC<{ title: string; description: string; action?: React.ReactNode }> = ({ title, description, action }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
    <div>
      <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
    {action}
  </div>
);

// 1. Blind Schedule
export const BlindScheduleView: React.FC = () => {
    // Mock Data for listing
    const blindList = [
        { slip_no: 'AWB-9921', address: 'King Fahd Rd', city: 'Riyadh' },
        { slip_no: 'AWB-9922', address: 'Olaya St', city: 'Riyadh' },
    ];

    return (
        <div className="max-w-5xl mx-auto pb-10">
            <Header title="Blind Schedule" description="Schedule shipments with partial details." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">AWB Numbers</label>
                        <textarea rows={5} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg font-mono text-sm" placeholder="Enter AWB numbers, one per line..."></textarea>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Time Slot</label>
                            <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                                <option value="8:00 PM To 12:00 AM">8:00 PM - 12:00 AM</option>
                                <option value="10:00 AM - 4:00 PM">10:00 AM - 4:00 PM</option>
                                <option value="4:00 PM - 8:00 PM">4:00 PM - 8:00 PM</option>
                                <option value="Any Time">Any Time</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Schedule Date</label>
                            <input type="date" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                        </div>
                    </div>

                    <div className="flex justify-end pt-2">
                        <button className="px-6 py-2.5 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium">
                            Get List
                        </button>
                    </div>
                </div>
            </div>

            {/* List Section (Mock) */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left text-sm text-gray-600">
                    <thead className="bg-gray-50 uppercase font-semibold text-gray-500 text-xs">
                        <tr>
                            <th className="px-6 py-4">AWB No.</th>
                            <th className="px-6 py-4">Receiver Address</th>
                            <th className="px-6 py-4">Destination</th>
                            <th className="px-6 py-4">Area (Assign)</th>
                            <th className="px-6 py-4 text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {blindList.map((item, i) => (
                            <tr key={i} className="hover:bg-gray-50">
                                <td className="px-6 py-4 font-mono text-blue-600">{item.slip_no}</td>
                                <td className="px-6 py-4">{item.address}</td>
                                <td className="px-6 py-4">{item.city}</td>
                                <td className="px-6 py-4">
                                    <input type="text" className="px-3 py-1 border border-gray-300 rounded text-sm w-48" placeholder="Assign Area..." />
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button className="text-blue-600 hover:text-blue-800 font-medium text-xs">Save</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

// 2. Bulk On Hold
export const BulkOnHoldView: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Bulk On Hold" description="Change status of multiple shipments to/from 'On Hold'." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">AWB Numbers</label>
                        <textarea rows={8} className="w-full px-4 py-3 border border-gray-300 rounded-lg font-mono text-sm" placeholder="Paste AWB numbers here..."></textarea>
                    </div>
                    
                    <div className="flex flex-col md:flex-row gap-4 items-end">
                        <div className="w-full md:w-64">
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Action</label>
                            <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                                <option value="1">Hold Shipment</option>
                                <option value="0">Remove On Hold</option>
                            </select>
                        </div>
                        <div className="flex gap-2 w-full md:w-auto">
                             <button className="px-4 py-2.5 bg-gray-100 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-200">Count Rows</button>
                             <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex-1 md:flex-none">Submit Update</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

// 3. Bulk Reschedule
export const BulkRescheduleView: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Bulk Reschedule" description="Update delivery date and time for multiple orders." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">AWB Numbers</label>
                        <textarea rows={8} className="w-full px-4 py-3 border border-gray-300 rounded-lg font-mono text-sm" placeholder="Paste AWB numbers here..."></textarea>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">New Schedule Date</label>
                            <input type="date" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">New Time Slot</label>
                            <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                                <option>10:00 AM - 4:00 PM</option>
                                <option>4:00 PM - 8:00 PM</option>
                                <option>8:00 PM - 12:00 AM</option>
                                <option>Any Time</option>
                            </select>
                        </div>
                    </div>

                    <div className="flex justify-end pt-2">
                        <button className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
                            Reschedule All
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

// 4. CS Schedule
export const CSScheduleView: React.FC = () => {
    const [callStatus, setCallStatus] = useState('');
    const [channel, setChannel] = useState('');

    return (
        <div className="max-w-5xl mx-auto pb-10">
            <Header title="Customer Service Scheduling" description="Manage call outcomes and detailed scheduling." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                <div className="mb-6 w-full md:w-1/3">
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Call Status</label>
                    <select 
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg"
                        value={callStatus}
                        onChange={(e) => setCallStatus(e.target.value)}
                    >
                        <option value="">Select Status...</option>
                        <option value="YES">Schedule (Success)</option>
                        <option value="NO">Not Scheduled (Failed/Other)</option>
                    </select>
                </div>

                {/* Schedule: YES */}
                {callStatus === 'YES' && (
                    <div className="space-y-6 border-t border-gray-100 pt-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div className="md:col-span-3">
                                <label className="block text-sm font-medium text-gray-700 mb-1.5">AWB Number</label>
                                <textarea rows={2} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg font-mono text-sm" placeholder="Enter AWB..."></textarea>
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1.5">Channel</label>
                                <select 
                                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg"
                                    value={channel}
                                    onChange={(e) => setChannel(e.target.value)}
                                >
                                    <option value="">Select Channel</option>
                                    <option value="CSA">CSA (Standard)</option>
                                    <option value="BULK">Bulk</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1.5">Time Slot</label>
                                <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                                    <option>10:00 AM - 4:00 PM</option>
                                    <option>4:00 PM - 8:00 PM</option>
                                    <option>Any Time</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1.5">Schedule Date</label>
                                <input type="date" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" />
                            </div>
                        </div>

                        {channel === 'CSA' && (
                            <div className="p-4 bg-gray-50 rounded-lg border border-gray-200 grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="md:col-span-2">
                                    <h4 className="font-medium text-gray-800 mb-2">Location Details</h4>
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-500 mb-1">Area / District</label>
                                    <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg" placeholder="Search Area..." />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-500 mb-1">Street Address</label>
                                    <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg" />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-500 mb-1">Latitude, Longitude</label>
                                    <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg" placeholder="e.g. 24.713, 46.675" />
                                </div>
                            </div>
                        )}

                        {channel === 'BULK' && (
                            <div className="p-4 bg-blue-50 rounded-lg border border-blue-100 grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs font-medium text-blue-800 mb-1">Route Code</label>
                                    <input type="text" className="w-full px-3 py-2 border border-blue-200 rounded-lg" />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-blue-800 mb-1">Messenger Name</label>
                                    <input type="text" className="w-full px-3 py-2 border border-blue-200 rounded-lg" />
                                </div>
                            </div>
                        )}

                        <div className="flex justify-end pt-2">
                            <button className="px-6 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium">
                                Save Schedule
                            </button>
                        </div>
                    </div>
                )}

                {/* Schedule: NO */}
                {callStatus === 'NO' && (
                    <div className="space-y-6 border-t border-gray-100 pt-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">AWB Number</label>
                            <textarea rows={2} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg font-mono text-sm" placeholder="Enter AWB..."></textarea>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1.5">Reason</label>
                                <select className="w-full px-4 py-2.5 border border-gray-300 rounded-lg">
                                    <option>Customer Unreachable</option>
                                    <option>Wrong Number</option>
                                    <option>Customer Refused</option>
                                    <option>Future Delivery Requested</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1.5">Comment</label>
                                <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="CSA Comment..." />
                            </div>
                        </div>
                        <div className="flex justify-end pt-2">
                            <button className="px-6 py-2.5 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium">
                                Update Status
                            </button>
                        </div>
                    </div>
                )}
            </div>

            {/* Update Wrong Area (Upload) */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <MapPin size={18} className="text-blue-600" /> Update Wrong Area (Bulk)
                </h3>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 flex flex-col items-center justify-center text-center hover:bg-gray-50 transition-colors cursor-pointer">
                    <Upload size={32} className="text-gray-400 mb-2" />
                    <p className="text-sm font-medium text-gray-900">Upload Excel File</p>
                    <p className="text-xs text-gray-500 mt-1">Columns: AWB No, Area, Channel</p>
                </div>
            </div>
        </div>
    );
};

// 5. Bulk Schedule Remove
export const BulkScheduleRemoveView: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto pb-10">
            <Header title="Bulk Schedule Remove" description="Remove scheduling information from shipments." />
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1.5">AWB Numbers</label>
                        <textarea rows={8} className="w-full px-4 py-3 border border-gray-300 rounded-lg font-mono text-sm" placeholder="Paste AWB numbers here..."></textarea>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1.5">Reason / Comment</label>
                            <input type="text" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg" placeholder="Internal Note..." />
                        </div>
                        <button className="px-6 py-2.5 bg-orange-600 text-white rounded-lg hover:bg-orange-700 font-medium">
                            Remove Schedule
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};