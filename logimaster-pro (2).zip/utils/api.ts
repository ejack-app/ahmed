
// Base URL for the Backend API
// Defaults to relative path '/api' for production usage.
let API_BASE_URL = '/api';

try {
  // Safe check for development environment variable
  // @ts-ignore
  if (import.meta && import.meta.env && import.meta.env.MODE === 'development') {
    API_BASE_URL = 'http://localhost:5000/api';
  }
} catch (e) {
  // If access to import.meta fails, we stick to the production default '/api'
  console.warn('Running in production mode (fallback).');
}

export const api = {
  // Generic request handler
  request: async (endpoint: string, options: RequestInit = {}) => {
    const token = localStorage.getItem('token');
    
    const headers = {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      ...options.headers,
    };

    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers,
      });

      if (response.status === 401) {
        // Handle unauthorized (token expired)
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.reload();
        throw new Error('Session expired');
      }

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'API Request Failed');
      }

      return data;
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  },

  // HTTP Methods wrappers
  get: (endpoint: string) => api.request(endpoint, { method: 'GET' }),
  
  post: (endpoint: string, body: any) => api.request(endpoint, { 
    method: 'POST', 
    body: JSON.stringify(body) 
  }),
  
  put: (endpoint: string, body: any) => api.request(endpoint, { 
    method: 'PUT', 
    body: JSON.stringify(body) 
  }),
  
  delete: (endpoint: string) => api.request(endpoint, { method: 'DELETE' }),
};
